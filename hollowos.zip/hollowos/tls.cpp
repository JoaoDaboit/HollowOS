// tls.cpp - HollowOS: cliente TLS 1.2 minimo.
//   Suites: TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256 (C02F) e TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256 (C02B)
//   Grupo: x25519.  Sem retomada de sessao, sem certificado de cliente, SEM validacao do certificado do servidor.
// Todos os buffers sao estaticos (a pilha do kernel e pequena).
#include "tls.h"
#include "crypto.h"

static inline void cpy(void* d, const void* s, u32 n) { u8* a = (u8*)d; const u8* b = (const u8*)s; while (n--) *a++ = *b++; }

static const char* g_err = 0;
const char* tls_error() { return g_err ? g_err : "erro desconhecido"; }
static bool fail(const char* m) { g_err = m; return false; }

enum { CT_CCS = 20, CT_ALERT = 21, CT_HS = 22, CT_APP = 23 };

static struct {
    bool open, closed, enc_wr, enc_rd;
    Gcm wr, rd;
    u8  wr_salt[4], rd_salt[4];
    u32 wr_seq_hi, wr_seq_lo, rd_seq_hi, rd_seq_lo;
    int app_pos, app_len;
} T;
static u8 app_buf[16640];
static u8 rec_buf[16384 + 2048 + 8];
static u8 wbuf[5 + 8 + 16000 + 16 + 16];
static u8 hsbuf[40000];
static int hs_len = 0;
static Sha256 hs_hash;
static int g_timeout = 15000;

// ---------------------------------------------------------------- transporte
static bool rd_exact(u8* p, int n, int timeout_ms) {
    u32 t0 = net_ms();
    while (n > 0) {
        int left = timeout_ms - (int)(net_ms() - t0);
        if (left < 0) left = 0;
        int r = tcp_recv(p, n, left);
        if (r == 0)  return fail("conexao fechada pelo servidor");
        if (r < 0)   return fail("tempo esgotado (TLS)");
        p += r; n -= r;
    }
    return true;
}
static void put_seq(u8* o, u32 hi, u32 lo) {
    o[0] = (u8)(hi >> 24); o[1] = (u8)(hi >> 16); o[2] = (u8)(hi >> 8); o[3] = (u8)hi;
    o[4] = (u8)(lo >> 24); o[5] = (u8)(lo >> 16); o[6] = (u8)(lo >> 8); o[7] = (u8)lo;
}
static void inc_seq(u32& hi, u32& lo) { if (++lo == 0) hi++; }

static bool send_record(u8 type, const u8* d, int len) {
    int n = 0;
    wbuf[0] = type; wbuf[1] = 3; wbuf[2] = 3;
    if (!T.enc_wr) {
        wbuf[3] = (u8)(len >> 8); wbuf[4] = (u8)len;
        cpy(wbuf + 5, d, len); n = 5 + len;
    } else {
        u8 seq[8]; put_seq(seq, T.wr_seq_hi, T.wr_seq_lo);
        u8 iv[12]; cpy(iv, T.wr_salt, 4); cpy(iv + 4, seq, 8);
        u8 aad[13]; cpy(aad, seq, 8); aad[8] = type; aad[9] = 3; aad[10] = 3; aad[11] = (u8)(len >> 8); aad[12] = (u8)len;
        int bl = 8 + len + 16;
        wbuf[3] = (u8)(bl >> 8); wbuf[4] = (u8)bl;
        cpy(wbuf + 5, seq, 8);
        gcm_encrypt(&T.wr, iv, aad, 13, d, len, wbuf + 13, wbuf + 13 + len);
        inc_seq(T.wr_seq_hi, T.wr_seq_lo);
        n = 5 + bl;
    }
    if (tcp_send(wbuf, n) < 0) return fail("falha ao enviar (TCP)");
    return true;
}

// le um registro. Retorna tamanho do corpo (ja decifrado, em rec_buf) ou -1.
static int read_record(u8* type, int timeout_ms) {
    u8 h[5];
    // 1o byte com o tempo pedido: se estourar, nada foi consumido e a conexao continua valida (-2)
    { int r = tcp_recv(h, 1, timeout_ms); if (r < 0) { fail("tempo esgotado (TLS)"); return -2; } if (r == 0) { fail("conexao fechada pelo servidor"); return -1; } }
    if (!rd_exact(h + 1, 4, g_timeout)) return -1;
    int len = (h[3] << 8) | h[4];
    if (h[1] != 3) { fail("resposta nao e TLS"); return -1; }
    if (len > 16384 + 2048) { fail("registro TLS grande demais"); return -1; }
    if (!rd_exact(rec_buf, len, timeout_ms)) return -1;
    *type = h[0];
    if (!T.enc_rd || h[0] == CT_CCS) return len;
    if (len < 8 + 16) { fail("registro cifrado curto demais"); return -1; }
    int pl = len - 8 - 16;
    u8 seq[8]; put_seq(seq, T.rd_seq_hi, T.rd_seq_lo);
    u8 iv[12]; cpy(iv, T.rd_salt, 4); cpy(iv + 4, rec_buf, 8);
    u8 aad[13]; cpy(aad, seq, 8); aad[8] = h[0]; aad[9] = 3; aad[10] = 3; aad[11] = (u8)(pl >> 8); aad[12] = (u8)pl;
    // decifra em cima do proprio buffer (saida 8 bytes antes da entrada: seguro, a leitura vai a frente da escrita)
    if (!gcm_decrypt(&T.rd, iv, aad, 13, rec_buf + 8, pl, rec_buf, rec_buf + 8 + pl)) { fail("falha de autenticacao do registro TLS"); return -1; }
    inc_seq(T.rd_seq_hi, T.rd_seq_lo);
    return pl;
}
static const char* alert_text(int d) {
    switch (d) {
        case 0: return "close_notify"; case 40: return "alerta TLS: handshake_failure (servidor nao aceita nossas suites)";
        case 42: return "alerta TLS: bad_certificate"; case 47: return "alerta TLS: illegal_parameter";
        case 70: return "alerta TLS: protocol_version"; case 71: return "alerta TLS: insufficient_security";
        case 80: return "alerta TLS: internal_error"; case 112: return "alerta TLS: unrecognized_name";
        default: return "alerta TLS do servidor";
    }
}

// ---------------------------------------------------------------- handshake
static int get_msg(int* ccs) {           // 1 = mensagem completa em hsbuf, 2 = CCS recebido, -1 = erro
    *ccs = 0;
    for (;;) {
        if (hs_len >= 4) {
            int ml = (hsbuf[1] << 16) | (hsbuf[2] << 8) | hsbuf[3];
            if (ml + 4 > (int)sizeof(hsbuf)) { fail("mensagem de handshake grande demais"); return -1; }
            if (hs_len >= ml + 4) return 1;
        }
        u8 ty; int n = read_record(&ty, g_timeout);
        if (n < 0) return -1;
        if (ty == CT_ALERT) {
            if (n >= 2 && rec_buf[1] == 0) { fail("conexao encerrada pelo servidor"); return -1; }
            fail(n >= 2 ? alert_text(rec_buf[1]) : "alerta TLS"); return -1;
        }
        if (ty == CT_CCS) { if (hs_len) { fail("CCS no meio de uma mensagem"); return -1; } *ccs = 1; return 2; }
        if (ty != CT_HS) { fail("registro inesperado no handshake"); return -1; }
        if (hs_len + n > (int)sizeof(hsbuf)) { fail("handshake grande demais"); return -1; }
        cpy(hsbuf + hs_len, rec_buf, n); hs_len += n;
    }
}
static void eat_msg() {
    int ml = (hsbuf[1] << 16) | (hsbuf[2] << 8) | hsbuf[3];
    int tot = ml + 4;
    sha256_update(&hs_hash, hsbuf, tot);
    for (int i = 0; i + tot < hs_len; i++) hsbuf[i] = hsbuf[i + tot];
    hs_len -= tot;
}
static void hs_send(u8 type, const u8* body, int blen) {      // envia uma mensagem de handshake e a inclui no hash
    static u8 m[1100];
    m[0] = type; m[1] = (u8)(blen >> 16); m[2] = (u8)(blen >> 8); m[3] = (u8)blen;
    cpy(m + 4, body, blen);
    sha256_update(&hs_hash, m, 4 + blen);
    send_record(CT_HS, m, 4 + blen);
}

bool tls_connect(const char* host, const u8* ip, u16 port, int timeout_ms) {
    g_err = 0; g_timeout = timeout_ms < 5000 ? 15000 : timeout_ms;
    T.open = T.closed = T.enc_wr = T.enc_rd = false;
    T.wr_seq_hi = T.wr_seq_lo = T.rd_seq_hi = T.rd_seq_lo = 0; T.app_pos = T.app_len = 0;
    hs_len = 0; sha256_init(&hs_hash);
    if (!tcp_connect(ip, port, 5000)) return fail("nao foi possivel conectar (TCP)");

    // ---- ClientHello
    u8 priv[32], pub[32], crandom[32];
    rng_bytes(priv, 32); rng_bytes(crandom, 32);
    x25519_base(pub, priv);
    static u8 ch[400]; int o = 0;
    ch[o++] = 3; ch[o++] = 3;
    cpy(ch + o, crandom, 32); o += 32;
    ch[o++] = 0;                                           // session id vazio
    ch[o++] = 0; ch[o++] = 4; ch[o++] = 0xC0; ch[o++] = 0x2F; ch[o++] = 0xC0; ch[o++] = 0x2B;
    ch[o++] = 1; ch[o++] = 0;                              // compressao: nenhuma
    int hl = 0; while (host[hl]) hl++;
    if (hl > 120) { tcp_close(); return fail("nome do servidor longo demais"); }
    int ext_start = o; o += 2;
    // server_name
    ch[o++] = 0; ch[o++] = 0; int sl = hl + 5; ch[o++] = (u8)(sl >> 8); ch[o++] = (u8)sl;
    int ll = hl + 3; ch[o++] = (u8)(ll >> 8); ch[o++] = (u8)ll; ch[o++] = 0; ch[o++] = (u8)(hl >> 8); ch[o++] = (u8)hl;
    cpy(ch + o, host, hl); o += hl;
    // supported_groups
    // x25519 (a unica que sabemos fazer) e, so para o servidor aceitar certificados ECDSA P-256, secp256r1 em 2o lugar
    static const u8 e1[] = { 0x00,0x0a, 0x00,0x06, 0x00,0x04, 0x00,0x1d, 0x00,0x17 };
    cpy(ch + o, e1, sizeof e1); o += sizeof e1;
    // ec_point_formats: uncompressed
    static const u8 e2[] = { 0x00,0x0b, 0x00,0x02, 0x01,0x00 };
    cpy(ch + o, e2, sizeof e2); o += sizeof e2;
    // signature_algorithms
    static const u8 e3[] = { 0x00,0x0d, 0x00,0x0c, 0x00,0x0a, 0x04,0x03, 0x08,0x04, 0x04,0x01, 0x05,0x01, 0x06,0x01 };
    cpy(ch + o, e3, sizeof e3); o += sizeof e3;
    // renegotiation_info (vazio)
    static const u8 e4[] = { 0xff,0x01, 0x00,0x01, 0x00 };
    cpy(ch + o, e4, sizeof e4); o += sizeof e4;
    int el = o - ext_start - 2; ch[ext_start] = (u8)(el >> 8); ch[ext_start + 1] = (u8)el;
    hs_send(1, ch, o);

    // ---- ServerHello ... ServerHelloDone
    u8 srandom[32], spub[32]; bool got_sh = false, got_ske = false, cert_req = false, done = false;
    u16 suite = 0;
    while (!done) {
        int ccs; int r = get_msg(&ccs);
        if (r < 0) { tcp_close(); return false; }
        if (r == 2) { tcp_close(); return fail("CCS antes da hora"); }
        u8 ty = hsbuf[0]; int ml = (hsbuf[1] << 16) | (hsbuf[2] << 8) | hsbuf[3]; const u8* b = hsbuf + 4;
        if (ty == 2) {                                                  // ServerHello
            if (ml < 38 || b[0] != 3 || b[1] != 3) { tcp_close(); return fail("servidor nao fala TLS 1.2"); }
            cpy(srandom, b + 2, 32);
            int sid = b[34];
            if (35 + sid + 3 > ml) { tcp_close(); return fail("ServerHello invalido"); }
            suite = (u16)((b[35 + sid] << 8) | b[36 + sid]);
            if (b[37 + sid] != 0) { tcp_close(); return fail("compressao nao suportada"); }
            if (suite != 0xC02F && suite != 0xC02B) { tcp_close(); return fail("servidor escolheu uma suite que nao suportamos"); }
            got_sh = true;
        } else if (ty == 12) {                                          // ServerKeyExchange
            if (ml < 4 + 32 || b[0] != 3 || b[1] != 0 || b[2] != 0x1d || b[3] != 32) { tcp_close(); return fail("curva do servidor nao suportada (so x25519)"); }
            cpy(spub, b + 4, 32); got_ske = true;
        } else if (ty == 13) cert_req = true;
        else if (ty == 14) done = true;
        eat_msg();
    }
    if (!got_sh || !got_ske) { tcp_close(); return fail("handshake incompleto"); }

    // ---- chaves
    u8 pms[32]; x25519(pms, priv, spub);
    u8 z = 0; for (int i = 0; i < 32; i++) z |= pms[i];
    if (!z) { tcp_close(); return fail("chave publica do servidor invalida"); }
    u8 seed[64]; cpy(seed, crandom, 32); cpy(seed + 32, srandom, 32);
    u8 master[48]; tls_prf(pms, 32, "master secret", seed, 64, master, 48);
    u8 seed2[64]; cpy(seed2, srandom, 32); cpy(seed2 + 32, crandom, 32);
    u8 kb[40]; tls_prf(master, 48, "key expansion", seed2, 64, kb, 40);
    gcm_init(&T.wr, kb); gcm_init(&T.rd, kb + 16);
    cpy(T.wr_salt, kb + 32, 4); cpy(T.rd_salt, kb + 36, 4);

    // ---- ClientKeyExchange, CCS, Finished
    if (cert_req) { static const u8 empty[3] = { 0, 0, 0 }; hs_send(11, empty, 3); }
    u8 cke[33]; cke[0] = 32; cpy(cke + 1, pub, 32);
    hs_send(16, cke, 33);
    static const u8 one = 1;
    if (!send_record(CT_CCS, &one, 1)) { tcp_close(); return false; }
    T.enc_wr = true;
    u8 hash[32]; sha256_final(&hs_hash, hash);
    u8 vd[12]; tls_prf(master, 48, "client finished", hash, 32, vd, 12);
    hs_send(20, vd, 12);

    // ---- servidor: [NewSessionTicket] CCS Finished
    bool got_ccs = false;
    for (;;) {
        int ccs; int r = get_msg(&ccs);
        if (r < 0) { tcp_close(); return false; }
        if (r == 2) { T.enc_rd = true; T.rd_seq_hi = T.rd_seq_lo = 0; got_ccs = true; continue; }
        if (hsbuf[0] == 20) {
            if (!got_ccs) { tcp_close(); return fail("Finished sem CCS"); }
            u8 h2[32]; sha256_final(&hs_hash, h2);
            u8 exp[12]; tls_prf(master, 48, "server finished", h2, 32, exp, 12);
            int ml = (hsbuf[1] << 16) | (hsbuf[2] << 8) | hsbuf[3];
            u8 diff = (ml != 12); for (int i = 0; i < 12 && ml == 12; i++) diff |= (u8)(exp[i] ^ hsbuf[4 + i]);
            if (diff) { tcp_close(); return fail("Finished do servidor nao confere"); }
            eat_msg();
            break;
        }
        eat_msg();                                                       // NewSessionTicket etc.
    }
    T.open = true;
    return true;
}

int tls_send(const u8* data, int len) {
    if (!T.open) return -1;
    int sent = 0;
    while (sent < len) {
        int n = len - sent; if (n > 16000) n = 16000;
        if (!send_record(CT_APP, data + sent, n)) { T.open = false; return -1; }
        sent += n;
    }
    return sent;
}
int tls_recv(u8* buf, int max, int timeout_ms) {
    if (!T.open && T.app_pos >= T.app_len) return 0;
    for (;;) {
        if (T.app_pos < T.app_len) {
            int n = T.app_len - T.app_pos; if (n > max) n = max;
            cpy(buf, app_buf + T.app_pos, n); T.app_pos += n;
            return n;
        }
        if (T.closed || !T.open) return 0;
        u8 ty; int n = read_record(&ty, timeout_ms);
        if (n == -2) return -1;                       // so tempo esgotado: a conexao continua valida
        if (n < 0) { T.open = false; return 0; }
        if (ty == CT_APP) { cpy(app_buf, rec_buf, n); T.app_len = n; T.app_pos = 0; continue; }
        if (ty == CT_ALERT) { T.closed = true; T.open = false; if (n >= 2 && rec_buf[1] != 0) fail(alert_text(rec_buf[1])); return 0; }
        // handshake pos-conexao (NewSessionTicket, HelloRequest): ignora
    }
}
void tls_close() {
    if (T.open) { static const u8 al[2] = { 1, 0 }; send_record(CT_ALERT, al, 2); }
    T.open = false; T.closed = true;
    tcp_close();
}

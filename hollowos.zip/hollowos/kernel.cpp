// kernel.cpp - HollowOS v0.5
// Desktop roxo: janelas, mouse absoluto (vmmouse), teclado, terminal, gerenciador de Arquivos,
// DuckDuckGo (app oficial, HTTPS direto dentro do OS), barra de tarefas com rede e relogio,
// sistema de arquivos HFS (RAM + disco ATA) e execucao de programas Linux i386.
//
// Sem texto com acentos: a fonte embutida e ASCII puro.

#include "font.h"
#include "net.h"
#include "userland.h"
#include "hello_elf.h"
#include "vfs.h"
#include "disk.h"
#include "crypto.h"
#include "web.h"
#include "html.h"

typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned int   u32;
typedef unsigned int   usize;

// ============================================================
//  Funcoes que o compilador pode exigir (nao ha libc aqui)
// ============================================================
extern "C" {
void* memcpy(void* d, const void* s, usize n) {
    u8* dd = (u8*)d; const u8* ss = (const u8*)s;
    while (n--) *dd++ = *ss++;
    return d;
}
void* memset(void* d, int v, usize n) {
    u8* dd = (u8*)d;
    while (n--) *dd++ = (u8)v;
    return d;
}
void* memmove(void* d, const void* s, usize n) {
    u8* dd = (u8*)d; const u8* ss = (const u8*)s;
    if (dd < ss) { while (n--) *dd++ = *ss++; }
    else { dd += n; ss += n; while (n--) *--dd = *--ss; }
    return d;
}
}

static bool have_net() { return true; }

// ============================================================
//  Portas de I/O
// ============================================================
static inline u8  inb(u16 p)         { u8 r;  asm volatile("inb %1,%0"  : "=a"(r) : "Nd"(p)); return r; }
static inline u16 inw(u16 p)         { u16 r; asm volatile("inw %1,%0"  : "=a"(r) : "Nd"(p)); return r; }
static inline u32 inl(u16 p)         { u32 r; asm volatile("inl %1,%0"  : "=a"(r) : "Nd"(p)); return r; }
static inline void outb(u16 p, u8 v)  { asm volatile("outb %0,%1" :: "a"(v), "Nd"(p)); }
static inline void outw(u16 p, u16 v) { asm volatile("outw %0,%1" :: "a"(v), "Nd"(p)); }
static inline void outl(u16 p, u32 v) { asm volatile("outl %0,%1" :: "a"(v), "Nd"(p)); }

static inline void copy32(void* d, const void* s, u32 n) {
    asm volatile("cld; rep movsl" : "+D"(d), "+S"(s), "+c"(n) :: "memory");
}
static inline u32 rdtsc32() { u32 lo, hi; asm volatile("rdtsc" : "=a"(lo), "=d"(hi)); return lo ^ hi; }

// ============================================================
//  Strings
// ============================================================
static int str_len(const char* s) { int n = 0; while (s[n]) n++; return n; }
static bool str_eq(const char* a, const char* b) {
    while (*a && *a == *b) { a++; b++; }
    return *a == *b;
}
static bool str_starts(const char* s, const char* p) { while (*p) { if (*s != *p) return false; s++; p++; } return true; }
static void str_cpy(char* d, const char* s, int max) {
    int i = 0;
    for (; s[i] && i < max - 1; i++) d[i] = s[i];
    d[i] = 0;
}
static void str_cat(char* d, const char* s, int max) {
    int n = str_len(d), i = 0;
    for (; s[i] && n + i < max - 1; i++) d[n + i] = s[i];
    d[n + i] = 0;
}
static void int_str(char* o, int v) {
    char t[12]; int n = 0;
    if (v <= 0) { o[0] = '0'; o[1] = 0; return; }
    while (v > 0 && n < 11) { t[n++] = (char)('0' + v % 10); v /= 10; }
    for (int i = 0; i < n; i++) o[i] = t[n - 1 - i];
    o[n] = 0;
}
static void put2(char* out, int v) { out[0] = '0' + (v / 10) % 10; out[1] = '0' + v % 10; }
static bool looks_like_url(const char* q) {
    if (str_starts(q, "http://") || str_starts(q, "https://")) return true;
    bool dot = false;
    for (int i = 0; q[i]; i++) { if (q[i] == ' ') return false; if (q[i] == '.') dot = true; }
    return dot;
}

// ============================================================
//  Video: modo grafico 1024x768x32 via Bochs VBE (QEMU -vga std)
// ============================================================
static const int SW = 1024, SH = 768;
static const int TASKBAR_H = 36, TITLE_H = 24;

static u32 back[SW * SH];   // cena sem o cursor
static u32 wall[SW * SH];   // papel de parede pre-renderizado
static volatile u32* fb;    // framebuffer real
static u32* target;         // onde as funcoes de desenho escrevem

static void vbe_write(u16 idx, u16 val) { outw(0x1CE, idx); outw(0x1CF, val); }

static u32 pci_read(u8 bus, u8 dev, u8 fn, u8 off) {
    u32 addr = 0x80000000u | ((u32)bus << 16) | ((u32)dev << 11) | ((u32)fn << 8) | (off & 0xFC);
    outl(0xCF8, addr);
    return inl(0xCFC);
}

static bool init_video() {
    outw(0x1CE, 0);
    if (inw(0x1CF) < 0xB0C0) return false;        // nao e a placa VGA do QEMU

    vbe_write(4, 0);                               // desliga
    vbe_write(1, SW);
    vbe_write(2, SH);
    vbe_write(3, 32);
    vbe_write(4, 0x41);                            // liga + framebuffer linear

    u32 addr = 0xFD000000u;                        // valor padrao se nao achar
    for (u8 dev = 0; dev < 32; dev++) {
        if (pci_read(0, dev, 0, 0) == 0x11111234u) {   // vendor 1234, device 1111
            u32 bar = pci_read(0, dev, 0, 0x10) & 0xFFFFFFF0u;
            if (bar) addr = bar;
            break;
        }
    }
    fb = (volatile u32*)addr;
    return true;
}

// ============================================================
//  Primitivas de desenho
// ============================================================
static void fill_rect(int x, int y, int w, int h, u32 c) {
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x + w > SW) w = SW - x;
    if (y + h > SH) h = SH - y;
    if (w <= 0 || h <= 0) return;
    for (int j = 0; j < h; j++) {
        u32* p = target + (y + j) * SW + x;
        for (int i = 0; i < w; i++) p[i] = c;
    }
}
static void draw_rect(int x, int y, int w, int h, u32 c) {
    fill_rect(x, y, w, 1, c);
    fill_rect(x, y + h - 1, w, 1, c);
    fill_rect(x, y, 1, h, c);
    fill_rect(x + w - 1, y, 1, h, c);
}
static void put_px(int x, int y, u32 c) {
    if ((unsigned)x < (unsigned)SW && (unsigned)y < (unsigned)SH) target[y * SW + x] = c;
}
static void draw_char(int x, int y, char ch, u32 c, int s = 1) {
    if (ch < 32 || ch > 126) return;
    const unsigned char* g = FONT[ch - 32];
    for (int r = 0; r < 8; r++) {
        u8 bits = g[r];
        for (int b = 0; b < 8; b++) {
            if (!(bits & (1 << b))) continue;
            if (s == 1) put_px(x + b, y + r, c);
            else fill_rect(x + b * s, y + r * s, s, s, c);
        }
    }
}
static void draw_text(int x, int y, const char* t, u32 c, int s = 1) {
    for (; *t; t++) { draw_char(x, y, *t, c, s); x += 8 * s; }
}
static void draw_text_n(int x, int y, const char* t, int maxc, u32 c) {
    for (int i = 0; t[i] && i < maxc; i++) draw_char(x + i * 8, y, t[i], c);
}
static int text_w(const char* t, int s = 1) { return str_len(t) * 8 * s; }
static bool inside(int px, int py, int x, int y, int w, int h) {
    return px >= x && py >= y && px < x + w && py < y + h;
}

// Cores (paleta inspirada no Linux Mint)
static const u32 MINT_GREEN = 0x9B59D0;   // cor de destaque (roxo)
static const u32 PANEL_BG   = 0x241638;
static const u32 DDG_ORANGE = 0xDE5833;

static void build_wallpaper() {
    target = wall;
    for (int y = 0; y < SH; y++) {
        int t = y * 255 / SH;
        int r = 0x6A - (0x6A - 0x1C) * t / 255;
        int g = 0x2C - (0x2C - 0x08) * t / 255;
        int b = 0xA8 - (0xA8 - 0x3A) * t / 255;
        u32 c = ((u32)r << 16) | ((u32)g << 8) | (u32)b;
        for (int x = 0; x < SW; x++) wall[y * SW + x] = c;
    }
    draw_text(SW - 8 * 8 * 5 - 40, SH - TASKBAR_H - 110, "HollowOS", 0x8A5BC0, 5);
}

// ============================================================
//  Cursor do mouse (desenhado direto no framebuffer)
// ============================================================
static const char* const CURSOR[19] = {
    "#           ", "##          ", "#.#         ", "#..#        ",
    "#...#       ", "#....#      ", "#.....#     ", "#......#    ",
    "#.......#   ", "#........#  ", "#.....#####", "#..#..#     ",
    "#.# #..#    ", "##  #..#    ", "#    #..#   ", "     #..#   ",
    "      #..#  ", "      #..#  ", "       ##   "
};
static const int CUR_W = 12, CUR_H = 19;

static void cursor_restore(int x, int y) {
    for (int j = 0; j < CUR_H; j++) {
        int yy = y + j; if (yy < 0 || yy >= SH) continue;
        for (int i = 0; i < CUR_W; i++) {
            int xx = x + i; if (xx < 0 || xx >= SW) continue;
            fb[yy * SW + xx] = back[yy * SW + xx];
        }
    }
}
static void cursor_draw(int x, int y) {
    for (int j = 0; j < CUR_H; j++) {
        const char* row = CURSOR[j];
        int yy = y + j; if (yy < 0 || yy >= SH) continue;
        for (int i = 0; row[i]; i++) {
            int xx = x + i; if (xx < 0 || xx >= SW) continue;
            if (row[i] == '#') fb[yy * SW + xx] = 0x000000;
            else if (row[i] == '.') fb[yy * SW + xx] = 0xFFFFFF;
        }
    }
}


// ============================================================
//  Relogio (RTC)
// ============================================================
struct Time { int h, m, s, d, mo, y; };
static Time now;

static u8 cmos(u8 reg) { outb(0x70, reg); return inb(0x71); }
static int bcd(int v) { return (v & 0x0F) + (v >> 4) * 10; }
static void read_time(Time& t) {
    u8 b = cmos(0x0B);
    int s = cmos(0), m = cmos(2), h = cmos(4), d = cmos(7), mo = cmos(8), y = cmos(9);
    if (!(b & 4)) { s = bcd(s); m = bcd(m); h = bcd(h & 0x7F); d = bcd(d); mo = bcd(mo); y = bcd(y); }
    t.s = s; t.m = m; t.h = h; t.d = d; t.mo = mo; t.y = y;
}
static u32 unix_from(const Time& t) {
    int y = 2000 + t.y, m = t.mo, d = t.d;
    y -= m <= 2;
    int era = y / 400, yoe = y - era * 400;
    int doy = (153 * (m + (m > 2 ? -3 : 9)) + 2) / 5 + d - 1;
    int doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    u32 days = (u32)(era * 146097 + doe - 719468);
    return days * 86400u + (u32)t.h * 3600u + (u32)t.m * 60u + (u32)t.s;
}
extern "C" u32 k_unix_time() { Time t; read_time(t); return unix_from(t); }
static u32 clock_cb() { return k_unix_time(); }

// ============================================================
//  Janelas
// ============================================================
enum { W_NONE = 0, W_TERM, W_BROWSER, W_ABOUT, W_FILES };
static const int MAXW = 8;
static const int TCOLS = 78, TROWS = 34;

struct Window {
    bool open, minimized, busy;
    int type, x, y, w, h;
    char title[24];
    // terminal
    char cell[TROWS][TCOLS];
    u8   attr[TROWS][TCOLS];
    int  cr, cc;
    char line[160];
    int  llen;
    int  cwd;
    // navegador (o texto da pagina fica em 'page', global)
    char query[128];
    int  qlen;
    bool qfresh;
    char status[2][100];
    int  scroll;
    // arquivos
    int  fdir, fsel, fscroll;
};

static Window win[MAXW];
static int zo[MAXW], zn = 0;     // ordem de empilhamento (ultimo = topo)
static bool dirty = true;
static bool menu_open = false;
static int  drag = -1, drag_dx = 0, drag_dy = 0;
static int  mx = SW / 2, my = SH / 2, mbtn = 0;
static int  topw = -1;

static void z_remove(int i) {
    int k = 0;
    for (; k < zn; k++) if (zo[k] == i) break;
    if (k == zn) return;
    for (; k < zn - 1; k++) zo[k] = zo[k + 1];
    zn--;
}
static void win_focus(int i) {
    z_remove(i);
    zo[zn++] = i;
    win[i].minimized = false;
    dirty = true;
}
static void win_close(int i) {
    win[i].open = false;
    z_remove(i);
    dirty = true;
}
static int top_window() {
    for (int k = zn - 1; k >= 0; k--)
        if (win[zo[k]].open && !win[zo[k]].minimized) return zo[k];
    return -1;
}
static int find_type(int type) {
    for (int i = 0; i < MAXW; i++) if (win[i].open && win[i].type == type) return i;
    return -1;
}
static int win_create(int type, const char* title, int x, int y, int w, int h) {
    for (int i = 0; i < MAXW; i++) {
        if (win[i].open) continue;
        memset(&win[i], 0, sizeof(Window));
        Window& W = win[i];
        W.open = true; W.type = type;
        W.x = x; W.y = y; W.w = w; W.h = h;
        str_cpy(W.title, title, sizeof(W.title));
        zo[zn++] = i;
        return i;
    }
    return -1;
}

// ============================================================
//  Terminal: celulas, captura de saida (>, >>) e console dos programas Linux
// ============================================================
static char capbuf[65536];
static int  cap_len = 0;
static bool cap_on = false;

static void term_newline(Window& w) {
    w.cc = 0;
    if (++w.cr >= TROWS) {
        for (int r = 1; r < TROWS; r++)
            for (int c = 0; c < TCOLS; c++) {
                w.cell[r - 1][c] = w.cell[r][c];
                w.attr[r - 1][c] = w.attr[r][c];
            }
        for (int c = 0; c < TCOLS; c++) { w.cell[TROWS - 1][c] = 0; w.attr[TROWS - 1][c] = 0; }
        w.cr = TROWS - 1;
    }
}
static void term_putc(Window& w, char c, u8 a) {
    if (cap_on) { if (cap_len < (int)sizeof(capbuf)) capbuf[cap_len++] = c; return; }
    if (c == '\n') { term_newline(w); return; }
    w.cell[w.cr][w.cc] = c;
    w.attr[w.cr][w.cc] = a;
    if (++w.cc >= TCOLS) term_newline(w);
}
static void term_print(Window& w, const char* s, u8 a = 0) { for (; *s; s++) term_putc(w, *s, a); }
static void term_line(Window& w, const char* s, u8 a = 0) { term_print(w, s, a); term_putc(w, '\n', a); }
static void term_clear(Window& w) {
    memset(w.cell, 0, sizeof(w.cell));
    memset(w.attr, 0, sizeof(w.attr));
    w.cr = w.cc = 0;
}
static void term_prompt(Window& w) {
    char p[96] = "hollow@os:";
    char path[80]; vfs_path(w.cwd, path, sizeof path);
    str_cat(p, path, sizeof p); str_cat(p, "$ ", sizeof p);
    term_print(w, p, 1);
}

static int  run_wi = -1;               // terminal que recebe a saida do programa Linux em execucao
static bool user_ready = false;
static bool abort_flag = false;
static bool stdin_wait = false, sin_ready = false, sin_eof = false;
static char sin_buf[200]; static int sin_len = 0;
static int  esc_state = 0;             // 0 normal, 1 viu ESC, 2 dentro de CSI

static void ui_tick();

extern "C" void k_console_write(const char* s, int n) {
    if (run_wi < 0 && !cap_on) return;
    Window& w = win[run_wi < 0 ? 0 : run_wi];
    for (int i = 0; i < n; i++) {
        char c = s[i];
        if (esc_state == 1) { esc_state = (c == '[') ? 2 : 0; continue; }      // ignora sequencias ANSI (cores etc.)
        if (esc_state == 2) { if (c >= 0x40 && c <= 0x7E) esc_state = 0; continue; }
        if (c == 27) { esc_state = 1; continue; }
        if (c == '\n' || (c >= 32 && c < 127)) term_putc(w, c, 0);
        else if (c == '\t') term_print(w, "    ");
        else if (c == '\b' && !cap_on && w.cc > 0) { w.cc--; w.cell[w.cr][w.cc] = 0; }
    }
    dirty = true;
}
extern "C" bool k_abort() { return abort_flag; }
extern "C" void k_yield() { ui_tick(); }

// leitura de linha (stdin) para o programa Linux
extern "C" int k_console_read(char* buf, int max) {
    if (run_wi < 0 || sin_eof) return 0;
    stdin_wait = true; sin_ready = false; sin_len = 0;
    dirty = true;
    while (!sin_ready && !abort_flag && win[run_wi].open) { ui_tick(); asm volatile("pause"); }
    stdin_wait = false;
    if (abort_flag || !win[run_wi].open) return 0;
    if (sin_eof && sin_len == 0) return 0;
    int n = sin_len < max ? sin_len : max;
    memcpy(buf, sin_buf, n);
    return n;
}

// ============================================================
//  Rede: busca, paginas e downloads (tudo dentro do OS, via TLS 1.2)
// ============================================================
static bool net_busy = false;
static char netbuf[400 * 1024];
static int  netlen = 0;
static TextPage page;
static bool page_ok = false;                    // ha uma pagina carregada?
static char page_url[PG_URLLEN + 200];
static int  last_status = 0;

static const char* net_why() {
    if (!have_net())  return "Sem rede.";
    if (!net.present) return "Placa e1000 nao encontrada. Rode com: make run";
    if (!net.has_ip)  return "Conectando... aguardando DHCP, tente de novo.";
    if (net_busy)     return "A rede esta ocupada com outra operacao.";
    return 0;
}
static bool sink_buf(const u8* d, int n, void*) {
    int room = (int)sizeof(netbuf) - 1 - netlen;
    if (n > room) { memcpy(netbuf + netlen, d, room); netlen += room; return false; }
    memcpy(netbuf + netlen, d, n); netlen += n; return true;
}
static bool contains(const char* s, const char* p) {
    int pl = str_len(p);
    for (int i = 0; s[i]; i++) { int k = 0; while (k < pl && s[i + k] == p[k]) k++; if (k == pl) return true; }
    return false;
}
// Baixa url (GET) ou envia post (POST) e converte para texto em 'page'. ddgq != 0: formata como resultados do DuckDuckGo.
static bool fetch_page(const char* url, const char* post, const char* ddgq, char* err, int emax) {
    net_busy = true; net_cancel = false; netlen = 0;
    WebResult r;
    bool ok = web_request(post ? "POST" : "GET", url, post, sink_buf, 0, &r, 15000);
    net_busy = false;
    if (!ok) { str_cpy(err, r.error ? r.error : "Falha de rede.", emax); if (net_cancel) str_cpy(err, "Cancelado.", emax); return false; }
    netbuf[netlen] = 0;
    last_status = r.status;
    Url base; if (!url_parse(r.final_url, &base)) url_parse(url, &base);
    int p0 = 0; while (netbuf[p0] == ' ' || netbuf[p0] == '\n' || netbuf[p0] == '\r' || netbuf[p0] == '\t') p0++;
    if (ddgq) page_from_ddg(&page, netbuf, netlen, ddgq);
    else if (contains(r.ctype, "html") || netbuf[p0] == '<') page_from_html(&page, netbuf, netlen, &base);
    else if (contains(r.ctype, "text") || contains(r.ctype, "json") || contains(r.ctype, "xml") || contains(r.ctype, "javascript")) page_from_text(&page, netbuf, netlen);
    else {
        page_reset(&page);
        char m[100] = "Arquivo binario ("; char n[12]; int_str(n, netlen); str_cat(m, n, sizeof m); str_cat(m, " bytes, ", sizeof m); str_cat(m, r.ctype, sizeof m); str_cat(m, ")", sizeof m);
        page_add_line(&page, m, -1);
        page_add_line(&page, "Para guardar no disco, use no terminal:", -1);
        char c[300] = "   wget "; str_cat(c, r.final_url, sizeof c); page_add_line(&page, c, -1);
    }
    str_cpy(page_url, r.final_url, sizeof page_url);
    page_ok = true;
    return true;
}

struct DlCtx { int ino; u32 off; bool full; };
static bool sink_file(const u8* d, int n, void* c) {
    DlCtx* x = (DlCtx*)c;
    int w = vfs_write(x->ino, x->off, d, (u32)n);
    if (w < n) { x->full = true; return false; }
    x->off += (u32)n; return true;
}
static const char* vfs_err_text(int e) {
    switch (e) {
        case VE_NOENT: return "nao encontrado"; case VE_EXIST: return "ja existe"; case VE_NOTDIR: return "nao e uma pasta";
        case VE_ISDIR: return "e uma pasta"; case VE_NOSPC: return "sem espaco (disco cheio)"; case VE_NOTEMPTY: return "pasta nao esta vazia";
        case VE_NAMETOOLONG: return "nome longo demais (max 27)"; case VE_INVAL: return "nome ou operacao invalida"; case VE_FBIG: return "arquivo grande demais";
        default: return "erro no sistema de arquivos";
    }
}

// ============================================================
//  Sistema de arquivos: conteudo inicial e registro de aplicativos
// ============================================================
static void ensure_file(const char* p, const char* text) { if (vfs_resolve(p, 0) < 0) vfs_write_file(p, text, (u32)str_len(text)); }
static void ensure_dir(const char* p) {
    if (vfs_resolve(p, 0) >= 0) return;
    char leaf[VFS_NAME + 1]; int d = vfs_parent_of(p, 0, leaf);
    if (d >= 0 && leaf[0]) vfs_create(d, leaf, VT_DIR);
}
static void populate_defaults() {
    ensure_dir("/bin"); ensure_dir("/usr"); ensure_dir("/usr/bin"); ensure_dir("/usr/lib"); ensure_dir("/lib"); ensure_dir("/tmp");
    ensure_dir("/dev"); ensure_dir("/proc"); ensure_dir("/home"); ensure_dir("/home/hollow"); ensure_dir("/apps"); ensure_dir("/etc");
    if (vfs_resolve("/bin/hello", 0) < 0) vfs_write_file("/bin/hello", HELLO_ELF, sizeof(HELLO_ELF));
    ensure_file("/apps/duckduckgo.app", "[App]\nName=DuckDuckGo\nExec=builtin:browser\nOfficial=true\nCategory=Internet\nDescription=Navegador e busca privada do HollowOS (HTTPS direto, sem ponte)\n");
    ensure_file("/apps/terminal.app", "[App]\nName=Terminal\nExec=builtin:term\nCategory=Sistema\n");
    ensure_file("/apps/arquivos.app", "[App]\nName=Arquivos\nExec=builtin:files\nCategory=Sistema\n");
    ensure_file("/apps/hello.app", "[App]\nName=Hello\nExec=/bin/hello\nCategory=Teste\nDescription=Programa Linux de teste\n");
    ensure_file("/etc/hostname", "hollowos\n");
    ensure_file("/etc/os-release", "NAME=\"HollowOS\"\nID=hollowos\nVERSION=\"0.5\"\nPRETTY_NAME=\"HollowOS 0.5\"\n");
    ensure_file("/etc/passwd", "root:x:0:0:root:/home/hollow:/bin/sh\n");
    ensure_file("/etc/group", "root:x:0:\n");
    ensure_file("/etc/hosts", "127.0.0.1 localhost\n");
    ensure_file("/etc/resolv.conf", "nameserver 10.0.2.3\n");
    ensure_file("/home/hollow/leiame.txt", "Bem-vindo ao HollowOS!\nSistema operacional feito do zero em C++ e assembly.\nDuckDuckGo e o aplicativo oficial. Tudo que voce salvar fica no disco (hollow.img).\n");
    ensure_file("/home/hollow/roadmap.txt", "Veja ROADMAP.md no projeto.\n");
    ensure_file("/home/hollow/licenca.txt", "Projeto de estudo. Use, mude e aprenda.\n");
}
static bool manifest_get(const char* t, int n, const char* key, char* out, int max) {
    int kl = str_len(key);
    for (int i = 0; i < n;) {
        if ((i == 0 || t[i - 1] == '\n') && i + kl < n && str_starts(t + i, key) && t[i + kl] == '=') {
            int j = i + kl + 1, o = 0; while (j < n && t[j] != '\n' && o < max - 1) out[o++] = t[j++];
            out[o] = 0; return true;
        }
        while (i < n && t[i] != '\n') i++;
        i++;
    }
    return false;
}
static char lcase(char c) { return (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c; }
static bool eq_ci(const char* a, const char* b) { while (*a && lcase(*a) == lcase(*b)) { a++; b++; } return lcase(*a) == lcase(*b); }

static void do_reboot() {
    vfs_sync();
    for (int i = 0; i < 100000; i++) if (!(inb(0x64) & 2)) break;
    outb(0x64, 0xFE);
    for (;;) asm volatile("hlt");
}
static void do_poweroff() {
    vfs_sync();
    outw(0x604, 0x2000);     // QEMU recente
    outw(0xB004, 0x2000);    // QEMU/Bochs antigo
    for (;;) asm volatile("hlt");
}

// ============================================================
//  Terminal: comandos
// ============================================================
static int  launch(int type);
static void render();
static void present();
static void refresh() { dirty = true; render(); present(); }

static const int MAXARG = 16;
static char tokbuf[200];
static char* av[MAXARG];
static int ac;

static void tokenize(const char* line) {
    ac = 0; int o = 0; const char* p = line;
    while (*p) {
        while (*p == ' ') p++;
        if (!*p || ac >= MAXARG - 1) break;
        av[ac++] = &tokbuf[o];
        char q = 0;
        while (*p && (q || *p != ' ')) {
            if (!q && (*p == '"' || *p == '\'')) { q = *p++; continue; }
            if (q && *p == q) { q = 0; p++; continue; }
            if (o < (int)sizeof(tokbuf) - 2) tokbuf[o++] = *p;
            p++;
        }
        tokbuf[o++] = 0;
    }
    av[ac] = 0;
}

static void say_size(Window& w, u32 v, int width) {
    char b[16]; int_str(b, (int)v);
    for (int i = str_len(b); i < width; i++) term_putc(w, ' ', 0);
    term_print(w, b);
}
static int find_exec(Window& w, const char* name) {
    int ino = -1;
    bool slash = false; for (int i = 0; name[i]; i++) if (name[i] == '/') slash = true;
    if (slash) ino = vfs_resolve(name, w.cwd);
    else {
        static const char* const dirs[] = { "/bin/", "/usr/bin/", "/usr/local/bin/" };
        for (int d = 0; d < 3 && ino < 0; d++) { char p[96]; str_cpy(p, dirs[d], sizeof p); str_cat(p, name, sizeof p); int r = vfs_resolve(p, 0); if (r >= 0) ino = r; }
    }
    if (ino < 0 || vfs_type(ino) != VT_FILE) return -1;
    u8 m[4]; if (vfs_read(ino, 0, m, 4) != 4 || m[0] != 0x7F || m[1] != 'E' || m[2] != 'L' || m[3] != 'F') return -1;
    return ino;
}
static void run_program(int wi, int ino, int argc, const char* const* argv) {
    Window& w = win[wi];
    if (!user_ready) { user_init(); user_ready = true; }
    run_wi = wi; abort_flag = false; esc_state = 0; sin_eof = false; net_cancel = false;
    int rc = user_run(ino, argc, argv, w.cwd);
    run_wi = -1; esc_state = 0; stdin_wait = false;
    if (!w.open) return;
    if (!cap_on && w.cc != 0) term_putc(w, '\n', 0);
    if (cap_on) return;
    if (rc <= -1000) term_line(w, "[programa encerrado por erro]", 2);
    else if (rc < 0) term_line(w, user_err(rc), 2);
    else if (abort_flag) term_line(w, "[interrompido com Ctrl+C]", 2);
    else { char b[12]; int_str(b, rc); term_print(w, "[saiu com codigo "); term_print(w, b); term_line(w, "]"); }
    abort_flag = false;
}
static int rm_tree(int ino) {
    if (vfs_type(ino) == VT_DIR) { for (;;) { int c = vfs_nth_child(ino, 0); if (c < 0) break; int r = rm_tree(c); if (r < 0) return r; } }
    return vfs_unlink(ino);
}
static const char* url_filename(const char* url, char* out, int max) {
    const char* nm = url;
    const char* s = url; if (str_starts(s, "https://")) s += 8; else if (str_starts(s, "http://")) s += 7;
    const char* slash = 0; for (const char* p = s; *p && *p != '?' && *p != '#'; p++) if (*p == '/') slash = p;
    if (slash && slash[1] && slash[1] != '?' && slash[1] != '#') nm = slash + 1; else nm = 0;
    int k = 0;
    if (nm) for (; nm[k] && nm[k] != '?' && nm[k] != '#' && k < VFS_NAME - 1; k++) out[k] = nm[k];
    out[k] = 0;
    if (!k) str_cpy(out, "index.html", max);
    return out;
}
static void print_page(Window& w, int maxlines) {
    for (int i = 0; i < page.nlines && i < maxlines; i++) term_line(w, page.lines[i]);
    if (page.nlines > maxlines) term_line(w, "(...cortado)");
}

static int open_app(int wi, const char* name);

static void cmd_ls(Window& w) {
    bool lf = false; const char* path = ".";
    for (int i = 1; i < ac; i++) { if (av[i][0] == '-') { for (int k = 1; av[i][k]; k++) if (av[i][k] == 'l') lf = true; } else path = av[i]; }
    int d = vfs_resolve(path, w.cwd);
    if (d < 0) { term_print(w, "ls: ", 2); term_print(w, path, 2); term_print(w, ": ", 2); term_line(w, vfs_err_text(d), 2); return; }
    if (vfs_type(d) == VT_FILE) { if (lf) { term_print(w, "-"); say_size(w, vfs_size(d), 9); term_putc(w, ' ', 0); } term_line(w, vfs_name(d)); return; }
    int n = 0;
    for (int c = vfs_nth_child(d, 0), k = 0; c >= 0; c = vfs_nth_child(d, ++k)) {
        bool dir = vfs_type(c) == VT_DIR; n++;
        if (lf) { term_print(w, dir ? "d" : "-"); say_size(w, dir ? 0 : vfs_size(c), 9); term_putc(w, ' ', 0); }
        term_print(w, vfs_name(c), dir ? 1 : 0); if (dir) term_putc(w, '/', 1);
        term_putc(w, '\n', 0);
    }
    if (!n) term_line(w, "(vazio)");
}

// Executa a linha de comando de um terminal. Retorna false se a janela foi fechada.
static bool term_exec(int wi) {
    Window& w = win[wi];
    tokenize(w.line);
    // redirecionamento: cmd ... > arquivo   ou   >> arquivo
    char redir[100]; redir[0] = 0; bool append = false;
    for (int i = 0; i < ac; i++) {
        if (av[i][0] == '>') {
            const char* f = 0; int skip = 1;
            if (av[i][1] == '>') { append = true; if (av[i][2]) f = av[i] + 2; else if (i + 1 < ac) { f = av[i + 1]; skip = 2; } }
            else { if (av[i][1]) f = av[i] + 1; else if (i + 1 < ac) { f = av[i + 1]; skip = 2; } }
            if (!f) { term_line(w, "erro: faltou o nome do arquivo depois de >", 2); return true; }
            str_cpy(redir, f, sizeof redir);
            for (int k = i; k + skip <= ac; k++) av[k] = av[k + skip];
            ac -= skip; break;
        }
    }
    if (ac == 0) return true;
    const char* cmd = av[0];
    if (redir[0]) { cap_on = true; cap_len = 0; }
    bool alive = true;

    if (str_eq(cmd, "help")) {
        term_line(w, "Arquivos:");
        term_line(w, "  ls [-l] [pasta]   pwd   cd <pasta>   cat <arq>   mkdir <p>   touch <arq>");
        term_line(w, "  cp <a> <b>   mv <a> <b>   rm [-r] <p>   df   sync   format sim");
        term_line(w, "  comando > arq  /  comando >> arq   (grava a saida num arquivo)");
        term_line(w, "Internet (HTTPS direto no OS):");
        term_line(w, "  ddg <busca>   curl <url>   wget [-O nome] <url>   net   ping <host>");
        term_line(w, "Programas e apps:");
        term_line(w, "  apps   open <app>   run <prog> [args]   ./prog   (Ctrl+C interrompe)");
        term_line(w, "Sistema:");
        term_line(w, "  clear  echo  date  time  ver  neofetch  exit  reboot  shutdown");
    } else if (str_eq(cmd, "clear")) {
        term_clear(w);
    } else if (str_eq(cmd, "echo")) {
        for (int i = 1; i < ac; i++) { if (i > 1) term_putc(w, ' ', 0); term_print(w, av[i]); }
        term_putc(w, '\n', 0);
    } else if (str_eq(cmd, "date")) {
        read_time(now); char b[16] = "00/00/2000"; put2(b, now.d); put2(b + 3, now.mo); put2(b + 8, now.y); term_line(w, b);
    } else if (str_eq(cmd, "time")) {
        read_time(now); char b[16] = "00:00:00"; put2(b, now.h); put2(b + 3, now.m); put2(b + 6, now.s); term_line(w, b);
    } else if (str_eq(cmd, "ver") || str_eq(cmd, "uname")) {
        term_line(w, "HollowOS hollow-kernel 0.5 i686");
    } else if (str_eq(cmd, "neofetch")) {
        term_line(w, "  HollowOS v0.5", 1);
        term_line(w, "  Kernel : hollow-kernel (C++ e assembly, 32 bits)");
        term_line(w, "  Video  : 1024x768x32 (Bochs VBE)");
        term_line(w, "  Disco  : HFS (arvore de pastas, RAM + disco ATA)");
        term_line(w, "  Rede   : e1000, TCP/IP, TLS 1.2 (HTTPS dentro do OS)");
        term_line(w, "  Apps   : DuckDuckGo (oficial), Arquivos, Terminal, ELF Linux i386");
    } else if (str_eq(cmd, "pwd")) {
        char p[100]; vfs_path(w.cwd, p, sizeof p); term_line(w, p);
    } else if (str_eq(cmd, "cd")) {
        const char* t = ac > 1 ? av[1] : "/home/hollow";
        int d = vfs_resolve(t, w.cwd);
        if (d < 0) { term_print(w, "cd: ", 2); term_line(w, vfs_err_text(d), 2); }
        else if (vfs_type(d) != VT_DIR) term_line(w, "cd: nao e uma pasta", 2);
        else w.cwd = d;
    } else if (str_eq(cmd, "ls") || str_eq(cmd, "dir")) {
        cmd_ls(w);
    } else if (str_eq(cmd, "cat")) {
        if (ac < 2) term_line(w, "uso: cat <arquivo>");
        for (int i = 1; i < ac; i++) {
            int f = vfs_resolve(av[i], w.cwd);
            if (f < 0 || vfs_type(f) != VT_FILE) { term_print(w, "cat: ", 2); term_print(w, av[i], 2); term_print(w, ": ", 2); term_line(w, f < 0 ? vfs_err_text(f) : "e uma pasta", 2); continue; }
            u32 off = 0; char buf[256]; int r;
            while ((r = vfs_read(f, off, buf, sizeof buf)) > 0) {
                for (int k = 0; k < r; k++) { char c = buf[k]; if (c == '\n' || (c >= 32 && c < 127)) term_putc(w, c, 0); else if (c == '\t') term_print(w, "    "); else if (c != '\r') term_putc(w, '.', 0); }
                off += (u32)r; if (off > 200000) break;
            }
            if (!cap_on && w.cc != 0) term_putc(w, '\n', 0);
        }
    } else if (str_eq(cmd, "mkdir")) {
        if (ac < 2) term_line(w, "uso: mkdir <pasta>");
        for (int i = 1; i < ac; i++) {
            char leaf[VFS_NAME + 1]; int d = vfs_parent_of(av[i], w.cwd, leaf);
            int r = d < 0 ? d : (leaf[0] ? vfs_create(d, leaf, VT_DIR) : VE_EXIST);
            if (r < 0) { term_print(w, "mkdir: ", 2); term_print(w, av[i], 2); term_print(w, ": ", 2); term_line(w, vfs_err_text(r), 2); }
        }
    } else if (str_eq(cmd, "touch")) {
        if (ac < 2) term_line(w, "uso: touch <arquivo>");
        for (int i = 1; i < ac; i++) {
            if (vfs_resolve(av[i], w.cwd) >= 0) continue;
            char leaf[VFS_NAME + 1]; int d = vfs_parent_of(av[i], w.cwd, leaf);
            int r = d < 0 ? d : (leaf[0] ? vfs_create(d, leaf, VT_FILE) : VE_INVAL);
            if (r < 0) { term_print(w, "touch: ", 2); term_line(w, vfs_err_text(r), 2); }
        }
    } else if (str_eq(cmd, "rm") || str_eq(cmd, "rmdir")) {
        bool rec = false; int first = 1;
        if (ac > 1 && str_eq(av[1], "-r")) { rec = true; first = 2; }
        if (ac <= first) term_line(w, "uso: rm [-r] <arquivo ou pasta>");
        for (int i = first; i < ac; i++) {
            int f = vfs_resolve(av[i], w.cwd);
            int r = f < 0 ? f : (f == w.cwd ? VE_INVAL : (vfs_type(f) == VT_DIR && !rec && str_eq(cmd, "rm") ? VE_ISDIR : (rec ? rm_tree(f) : vfs_unlink(f))));
            if (r < 0) { term_print(w, "rm: ", 2); term_print(w, av[i], 2); term_print(w, ": ", 2); term_line(w, r == VE_ISDIR ? "e uma pasta (use rm -r)" : vfs_err_text(r), 2); }
        }
    } else if (str_eq(cmd, "cp") || str_eq(cmd, "mv")) {
        if (ac < 3) { term_line(w, "uso: cp|mv <origem> <destino>"); }
        else {
            bool mv = str_eq(cmd, "mv");
            int s = vfs_resolve(av[1], w.cwd);
            if (s < 0) { term_print(w, cmd, 2); term_print(w, ": ", 2); term_line(w, vfs_err_text(s), 2); }
            else {
                int dd = vfs_resolve(av[2], w.cwd); int dir; char leaf[VFS_NAME + 1];
                if (dd >= 0 && vfs_type(dd) == VT_DIR) { dir = dd; str_cpy(leaf, vfs_name(s), sizeof leaf); }
                else dir = vfs_parent_of(av[2], w.cwd, leaf);
                int r;
                if (dir < 0) r = dir;
                else if (!leaf[0]) r = VE_INVAL;
                else if (mv) { int ex = vfs_lookup(dir, leaf); if (ex >= 0 && ex != s && vfs_type(ex) == VT_FILE) vfs_unlink(ex); r = vfs_rename(s, dir, leaf); }
                else if (vfs_type(s) == VT_DIR) r = VE_ISDIR;
                else r = vfs_copy(s, dir, leaf);
                if (r < 0) { term_print(w, cmd, 2); term_print(w, ": ", 2); term_line(w, vfs_err_text(r), 2); }
            }
        }
    } else if (str_eq(cmd, "df")) {
        u32 f, d, u, t; vfs_stats(&f, &d, &u, &t);
        char b[16];
        term_print(w, "Usado : "); int_str(b, (int)(u * 4)); term_print(w, b); term_print(w, " KB de "); int_str(b, (int)(t * 4)); term_print(w, b); term_line(w, " KB");
        term_print(w, "Arquivos: "); int_str(b, (int)f); term_print(w, b); term_print(w, "   Pastas: "); int_str(b, (int)d); term_line(w, b);
        term_line(w, vfs_disk_ok() ? "Disco  : ATA conectado - as mudancas sao gravadas (comando sync grava agora)" : "Disco  : nenhum - tudo se perde ao desligar (rode com make run)");
    } else if (str_eq(cmd, "sync")) {
        vfs_sync(); term_line(w, vfs_disk_ok() ? "gravado no disco." : "sem disco: nada a gravar.");
    } else if (str_eq(cmd, "format")) {
        if (ac < 2 || !str_eq(av[1], "sim")) term_line(w, "Isto APAGA todo o disco. Digite: format sim", 2);
        else { vfs_init(); bool ok = vfs_format_disk(); populate_defaults(); vfs_sync(); for (int i = 0; i < MAXW; i++) if (win[i].type == W_TERM) win[i].cwd = 0; term_line(w, ok ? "disco formatado." : "sem disco: so a RAM foi limpa."); }
    } else if (str_eq(cmd, "net")) {
        const char* why = net_why();
        if (why && !net.present) term_line(w, why, 2);
        else {
            char b[20];
            net_mac_str(net.mac, b);       term_print(w, "MAC : "); term_line(w, b);
            if (!net.has_ip) term_line(w, "IP  : (sem DHCP ainda)", 2);
            else {
                net_ip_str(net.ip, b);   term_print(w, "IP  : "); term_line(w, b);
                net_ip_str(net.gw, b);   term_print(w, "GW  : "); term_line(w, b);
                net_ip_str(net.dns, b);  term_print(w, "DNS : "); term_line(w, b);
            }
            char r[12], t[12]; int_str(r, (int)net.rx_packets); int_str(t, (int)net.tx_packets);
            term_print(w, "pacotes rx/tx: "); term_print(w, r); term_print(w, " / "); term_line(w, t);
        }
    } else if (str_eq(cmd, "ping")) {
        const char* why = net_why(); u8 ip[4];
        if (why) term_line(w, why, 2);
        else if (ac < 2) term_line(w, "uso: ping <host>");
        else if (!net_resolve(av[1], ip)) term_line(w, "ping: nome nao resolvido", 2);
        else {
            char b[16]; net_ip_str(ip, b);
            for (int k = 0; k < 3; k++) {
                int ms = net_ping(ip, 2000);
                term_print(w, "resposta de "); term_print(w, b); term_print(w, ": ");
                if (ms < 0) term_line(w, "sem resposta", 2); else { char m[12]; int_str(m, ms); term_print(w, m); term_line(w, " ms"); }
            }
        }
    } else if (str_eq(cmd, "ddg") || str_eq(cmd, "curl")) {
        const char* why = net_why();
        if (why) term_line(w, why, 2);
        else if (ac < 2) term_line(w, str_eq(cmd, "ddg") ? "uso: ddg <o que pesquisar>" : "uso: curl <url>");
        else {
            char err[100]; bool ok;
            if (!cap_on) { term_line(w, "buscando... (Esc cancela)"); refresh(); }
            if (str_eq(cmd, "ddg")) {
                char q[200] = ""; for (int i = 1; i < ac; i++) { if (i > 1) str_cat(q, " ", sizeof q); str_cat(q, av[i], sizeof q); }
                char body[260] = "q="; url_encode(q, body + 2, (int)sizeof(body) - 2); str_cat(body, "&kl=wt-wt", sizeof body);
                ok = fetch_page("https://html.duckduckgo.com/html/", body, q, err, sizeof err);
            } else ok = fetch_page(av[1], 0, 0, err, sizeof err);
            if (!ok) term_line(w, err, 2); else print_page(w, 400);
        }
    } else if (str_eq(cmd, "wget")) {
        const char* why = net_why(); const char* url = 0; const char* outname = 0;
        for (int i = 1; i < ac; i++) { if (str_eq(av[i], "-O") && i + 1 < ac) outname = av[++i]; else url = av[i]; }
        if (why) term_line(w, why, 2);
        else if (!url) term_line(w, "uso: wget [-O nome] <url>");
        else {
            char fname[VFS_NAME + 1]; if (!outname) { url_filename(url, fname, sizeof fname); outname = fname; }
            char leaf[VFS_NAME + 1]; int dir = vfs_parent_of(outname, w.cwd, leaf);
            int ino = dir < 0 ? dir : (leaf[0] ? vfs_lookup(dir, leaf) : VE_INVAL);
            if (dir >= 0 && leaf[0] && ino == VE_NOENT) ino = vfs_create(dir, leaf, VT_FILE);
            else if (ino >= 0 && vfs_type(ino) == VT_FILE) vfs_truncate(ino, 0);
            else if (ino >= 0) ino = VE_ISDIR;
            if (ino < 0) { term_print(w, "wget: ", 2); term_line(w, vfs_err_text(ino), 2); }
            else {
                term_print(w, "baixando para "); term_print(w, outname); term_line(w, " ... (Esc cancela)"); refresh();
                DlCtx ctx = { ino, 0, false }; WebResult r;
                net_busy = true; net_cancel = false;
                bool ok = web_request("GET", url, 0, sink_file, &ctx, &r, 20000);
                net_busy = false;
                if (!ok) { term_print(w, "erro: ", 2); term_line(w, net_cancel ? "cancelado" : (r.error ? r.error : "falha"), 2); vfs_unlink(ino); }
                else if (ctx.full) { term_line(w, "erro: sem espaco no disco do HollowOS (limite 3 MB)", 2); vfs_unlink(ino); }
                else if (r.status < 200 || r.status >= 300) { char b[12]; int_str(b, r.status); term_print(w, "erro: o servidor respondeu HTTP ", 2); term_line(w, b, 2); vfs_unlink(ino); }
                else { char b[12]; int_str(b, (int)ctx.off); term_print(w, "ok: "); term_print(w, b); term_line(w, " bytes gravados"); vfs_sync(); }
            }
        }
    } else if (str_eq(cmd, "apps")) {
        int n = vfs_resolve("/apps", 0);
        for (int c = vfs_nth_child(n, 0), k = 0; c >= 0; c = vfs_nth_child(n, ++k)) {
            char t[400]; int tl = vfs_read(c, 0, t, sizeof t - 1); if (tl < 0) continue; t[tl] = 0;
            char nm[40], ex[80], of[8]; if (!manifest_get(t, tl, "Name", nm, sizeof nm)) continue;
            if (!manifest_get(t, tl, "Exec", ex, sizeof ex)) ex[0] = 0;
            bool official = manifest_get(t, tl, "Official", of, sizeof of) && str_eq(of, "true");
            term_print(w, nm, 1); if (official) term_print(w, "  [app oficial]", 1);
            term_print(w, "   "); term_line(w, ex);
        }
    } else if (str_eq(cmd, "open")) {
        if (ac < 2) term_line(w, "uso: open <app>   (veja: apps)");
        else if (!open_app(wi, av[1])) term_line(w, "app nao encontrado (veja: apps)", 2);
    } else if (str_eq(cmd, "run") || find_exec(w, cmd) >= 0) {
        int base = str_eq(cmd, "run") ? 1 : 0;
        if (ac <= base) term_line(w, "uso: run <programa> [argumentos]");
        else {
            int ino = find_exec(w, av[base]);
            if (ino < 0) { term_print(w, av[base], 2); term_line(w, ": nao e um programa Linux (ELF) valido", 2); }
            else run_program(wi, ino, ac - base, (const char* const*)(av + base));
        }
    } else if (str_eq(cmd, "exit")) {
        win_close(wi);
        alive = false;
    } else if (str_eq(cmd, "reboot")) {
        do_reboot();
    } else if (str_eq(cmd, "shutdown")) {
        do_poweroff();
    } else {
        term_print(w, "comando nao encontrado: ", 2);
        term_line(w, cmd, 2);
    }

    if (redir[0]) {
        cap_on = false;
        if (alive) {
            int r;
            if (append) { char leaf[VFS_NAME + 1]; int d = vfs_parent_of(redir, w.cwd, leaf); int f = d < 0 ? d : vfs_lookup(d, leaf); if (f == VE_NOENT) f = vfs_create(d, leaf, VT_FILE);
                r = f < 0 ? f : vfs_write(f, vfs_size(f), capbuf, (u32)cap_len); }
            else { char leaf[VFS_NAME + 1]; int d = vfs_parent_of(redir, w.cwd, leaf); int f = d < 0 ? d : (leaf[0] ? vfs_lookup(d, leaf) : VE_INVAL);
                if (f == VE_NOENT) f = vfs_create(d, leaf, VT_FILE); else if (f >= 0 && vfs_type(f) == VT_FILE) vfs_truncate(f, 0); else if (f >= 0) f = VE_ISDIR;
                r = f < 0 ? f : vfs_write(f, 0, capbuf, (u32)cap_len); }
            if (r < 0) { term_print(w, "erro ao gravar: ", 2); term_line(w, vfs_err_text(r), 2); }
        }
    }
    return alive;
}

static int cmd_running = 0;
static void term_enter(int wi) {
    Window& W = win[wi];
    term_putc(W, '\n', 0);
    if (cmd_running) { term_line(W, "(ocupado: outro comando ainda esta rodando)", 2); W.llen = 0; term_prompt(W); return; }
    W.line[W.llen] = 0;
    W.busy = true; cmd_running++;
    bool alive = term_exec(wi);
    cmd_running--;
    if (alive) { W.busy = false; W.llen = 0; term_prompt(W); }
}

// ============================================================
//  Abrir aplicativos
// ============================================================
static int launch(int type) {
    if (type == W_TERM) {
        int n = 0, last = -1; for (int i = 0; i < MAXW; i++) if (win[i].open && win[i].type == W_TERM) { n++; last = i; }
        if (n >= 3) { win_focus(last); return last; }
    } else {
        int e = find_type(type);
        if (e >= 0) { win_focus(e); return e; }
    }
    int cnt = 0;
    for (int i = 0; i < MAXW; i++) if (win[i].open) cnt++;
    int ox = 100 + (cnt % 5) * 28, oy = 24 + (cnt % 5) * 28;
    int i = -1;
    switch (type) {
        case W_TERM:    i = win_create(type, "Terminal",   ox, oy, 640, 400); break;
        case W_BROWSER: i = win_create(type, "DuckDuckGo", ox, oy, 800, 540); break;
        case W_ABOUT:   i = win_create(type, "Sobre",      ox, oy, 420, 280); break;
        case W_FILES:   i = win_create(type, "Arquivos",   ox, oy, 700, 430); break;
    }
    if (i < 0) return -1;
    win[i].cwd = 0;
    if (type == W_TERM) {
        win[i].cwd = vfs_resolve("/home/hollow", 0); if (win[i].cwd < 0) win[i].cwd = 0;
        term_line(win[i], "HollowOS v0.5 - terminal", 1);
        term_line(win[i], "Digite 'help' para ver os comandos.");
        term_prompt(win[i]);
    } else if (type == W_BROWSER) {
        str_cpy(win[i].status[0], "Digite uma busca ou um endereco e pressione Enter.", 100);
    } else if (type == W_FILES) {
        win[i].fdir = vfs_resolve("/home/hollow", 0); if (win[i].fdir < 0) win[i].fdir = 0;
        win[i].fsel = -1;
    }
    dirty = true;
    return i;
}
static void term_submit(int t, const char* text) {
    Window& W = win[t];
    W.llen = 0; for (int k = 0; text[k] && k < 150; k++) W.line[W.llen++] = text[k];
    term_print(W, text);
    term_enter(t);
}
static int open_app(int wi, const char* name) {
    int dir = vfs_resolve("/apps", 0);
    for (int c = vfs_nth_child(dir, 0), k = 0; c >= 0; c = vfs_nth_child(dir, ++k)) {
        char t[400]; int tl = vfs_read(c, 0, t, sizeof t - 1); if (tl < 0) continue; t[tl] = 0;
        char nm[40], ex[100];
        if (!manifest_get(t, tl, "Name", nm, sizeof nm) || !manifest_get(t, tl, "Exec", ex, sizeof ex)) continue;
        char stem[VFS_NAME + 1]; str_cpy(stem, vfs_name(c), sizeof stem); int sl = str_len(stem); if (sl > 4 && str_eq(stem + sl - 4, ".app")) stem[sl - 4] = 0;
        if (!eq_ci(nm, name) && !eq_ci(stem, name)) continue;
        if (str_eq(ex, "builtin:browser")) launch(W_BROWSER);
        else if (str_eq(ex, "builtin:term")) launch(W_TERM);
        else if (str_eq(ex, "builtin:files")) launch(W_FILES);
        else if (str_eq(ex, "builtin:about")) launch(W_ABOUT);
        else if (wi >= 0) { Window& w = win[wi]; int ino = find_exec(w, ex); if (ino < 0) { term_line(w, "o executavel do app nao foi encontrado", 2); } else { const char* a[1] = { ex }; run_program(wi, ino, 1, a); } }
        return 1;
    }
    return 0;
}

// ============================================================
//  Navegador DuckDuckGo
// ============================================================
static const u32 LINK_BLUE = 0x1A55CC;
static const int BR_TOP = TITLE_H + 52;                 // onde comeca o texto da pagina (dentro da janela)

static char hist[12][PG_URLLEN + 8];                    // historico (URLs ou "?busca")
static int  hn = 0, hi = -1;

static void br_geom(const Window&, int& bx, int& by, int& bw);
static void br_geom(const Window& W, int& bx, int& by, int& bw) {
    if (!page_ok) { bx = (W.w - 440) / 2; by = TITLE_H + 190; bw = 360; }
    else          { bx = 112; by = TITLE_H + 8; bw = W.w - 124 - 80; }
}
static int br_rows(const Window& W) { return (W.h - BR_TOP - 22) / 10; }

static void hist_push(const char* e) {
    if (hi >= 0 && str_eq(hist[hi], e)) return;
    hn = hi + 1;                                          // descarta o "futuro"
    if (hn >= 12) { for (int i = 1; i < 12; i++) str_cpy(hist[i - 1], hist[i], sizeof hist[0]); hn = 11; }
    str_cpy(hist[hn], e, sizeof hist[0]); hi = hn; hn++;
}
// carrega uma entrada ("?termos" = busca, senao URL)
static void br_load(Window& W, const char* entry, bool push) {
    if (net_busy) return;
    const char* why = net_why();
    W.status[0][0] = 0; W.status[1][0] = 0;
    if (why) { str_cpy(W.status[0], why, 100); dirty = true; return; }
    char err[100];
    bool ok;
    str_cpy(W.status[0], entry[0] == '?' ? "Pesquisando no DuckDuckGo... (Esc cancela)" : "Abrindo pagina... (Esc cancela)", 100);
    refresh();
    if (entry[0] == '?') {
        char body[300] = "q="; url_encode(entry + 1, body + 2, (int)sizeof(body) - 2); str_cat(body, "&kl=wt-wt", sizeof body);
        ok = fetch_page("https://html.duckduckgo.com/html/", body, entry + 1, err, sizeof err);
    } else ok = fetch_page(entry, 0, 0, err, sizeof err);
    W.status[0][0] = 0;
    if (!ok) { str_cpy(W.status[0], "ERRO:", 100); str_cpy(W.status[1], err, 100); dirty = true; return; }
    W.scroll = 0;
    if (push) hist_push(entry);
    if (entry[0] == '?') { str_cpy(W.query, entry + 1, sizeof W.query); }
    else { str_cpy(W.query, page_url, sizeof W.query); }
    W.qlen = str_len(W.query); W.qfresh = true;
    dirty = true;
}
static void br_go(Window& W) {
    if (W.qlen == 0) { str_cpy(W.status[0], "Digite algo para pesquisar.", 100); return; }
    char e[PG_URLLEN + 8];
    if (looks_like_url(W.query)) str_cpy(e, W.query, sizeof e);
    else { e[0] = '?'; str_cpy(e + 1, W.query, sizeof e - 1); }
    br_load(W, e, true);
}

static void draw_browser(const Window& W, bool focused) {
    int x = W.x, cy = W.y + TITLE_H;
    fill_rect(x, cy, W.w, W.h - TITLE_H, 0xFFFFFF);
    fill_rect(x, cy, W.w, 40, 0xE9E9E9);
    fill_rect(x, cy + 40, W.w, 1, 0xC8C8C8);
    const char gl[3] = { '<', '>', 'R' };
    for (int k = 0; k < 3; k++) {
        bool en = (k == 0 && hi > 0) || (k == 1 && hi >= 0 && hi < hn - 1) || (k == 2 && hi >= 0);
        fill_rect(x + 10 + k * 34, cy + 8, 28, 24, en ? 0xD0D0D0 : 0xE2E2E2);
        draw_char(x + 10 + k * 34 + 10, cy + 16, gl[k], en ? 0x333333 : 0xAAAAAA);
    }
    if (!page_ok) {
        fill_rect(x + 112, cy + 8, W.w - 124, 24, 0xFFFFFF);
        draw_rect(x + 112, cy + 8, W.w - 124, 24, 0xAAAAAA);
        draw_text(x + 120, cy + 16, "https://duckduckgo.com", 0x333333);
    }
    int bx, by, bw; br_geom(W, bx, by, bw); bx += x; by += W.y;
    if (!page_ok) {
        draw_text(x + (W.w - 320) / 2, cy + 100, "DuckDuckGo", DDG_ORANGE, 4);
        draw_text(x + (W.w - 208) / 2, cy + 148, "Pesquise sem ser rastreado", 0x777777);
    }
    int bh = page_ok ? 24 : 36;
    fill_rect(bx, by, bw, bh, 0xFFFFFF);
    draw_rect(bx, by, bw, bh, focused ? DDG_ORANGE : 0xAAAAAA);
    int maxc = (bw - 20) / 8;
    int first = W.qlen > maxc ? W.qlen - maxc : 0;
    int ty = by + (page_ok ? 8 : 14);
    draw_text_n(bx + 10, ty, W.query + first, maxc, 0x222222);
    if (focused) fill_rect(bx + 10 + (W.qlen - first) * 8, ty - 4, 2, 16, 0x222222);
    fill_rect(bx + bw, by, 80, bh, DDG_ORANGE);
    draw_text(bx + bw + 16, ty, "Buscar", 0xFFFFFF);

    if (!page_ok) {
        draw_text(x + 24, cy + 250, W.status[0], net_busy ? DDG_ORANGE : 0x444444);
        draw_text(x + 24, cy + 266, W.status[1], 0x9A3030);
        draw_text(x + 12, W.y + W.h - 18, "HTTPS direto no HollowOS (TLS 1.2). Sem ponte, sem proxy.", 0x888888);
    } else {
        int rows = br_rows(W), ry = W.y + BR_TOP;
        int cols = (W.w - 24) / 8;
        if (W.status[0][0]) draw_text(x + 12, W.y + TITLE_H + 42, W.status[0], DDG_ORANGE);
        else if (W.status[1][0]) draw_text(x + 12, W.y + TITLE_H + 42, W.status[1], 0x9A3030);
        for (int r = 0; r < rows && W.scroll + r < page.nlines; r++) {
            int li = W.scroll + r;
            draw_text_n(x + 12, ry + r * 10, page.lines[li], cols, page.link_of[li] >= 0 ? LINK_BLUE : 0x222222);
        }
        char a[12], b[12], line[80] = "linha ";
        int_str(a, W.scroll + 1); int_str(b, page.nlines);
        str_cat(line, a, 80); str_cat(line, " de ", 80); str_cat(line, b, 80);
        str_cat(line, "  (setas e PgUp/PgDn rolam; clique nos links azuis)", 80);
        draw_text(x + 12, W.y + W.h - 16, line, 0x888888);
    }
}

// ============================================================
//  Gerenciador de arquivos
// ============================================================
static int  fl_list[VFS_NINO + 2];
static int  fl_n = 0;
static char fprev[1100]; static int fprev_len = 0;
static const int FL_ROW = 14, FL_X = 8, FL_Y = 56, FL_W = 330;

static void files_build(const Window& W) {
    fl_n = 0;
    if (W.fdir != VFS_ROOT) fl_list[fl_n++] = -2;
    for (int c = vfs_nth_child(W.fdir, 0), k = 0; c >= 0 && fl_n < VFS_NINO; c = vfs_nth_child(W.fdir, ++k)) fl_list[fl_n++] = c;
}
static int files_rows(const Window& W) { return (W.h - TITLE_H - FL_Y - 24) / FL_ROW; }
static void files_preview(int ino) {
    fprev_len = 0; if (ino < 0 || vfs_type(ino) != VT_FILE) return;
    int r = vfs_read(ino, 0, fprev, sizeof fprev - 1); fprev_len = r < 0 ? 0 : r; fprev[fprev_len] = 0;
}
static bool is_elf_ino(int ino) { u8 m[4]; return ino >= 0 && vfs_type(ino) == VT_FILE && vfs_read(ino, 0, m, 4) == 4 && m[0] == 0x7F && m[1] == 'E' && m[2] == 'L' && m[3] == 'F'; }

static void files_btn(int x, int y, int w, const char* t, bool en) {
    fill_rect(x, y, w, 22, en ? 0x6B3FA0 : 0xBBBBBB);
    draw_text(x + (w - text_w(t)) / 2, y + 7, t, 0xFFFFFF);
}
static void draw_files(const Window& W, bool) {
    int x = W.x, cy = W.y + TITLE_H;
    fill_rect(x, cy, W.w, W.h - TITLE_H, 0xF4F1F8);
    fill_rect(x, cy, W.w, 32, 0xE2D9EE);
    files_btn(x + 8, cy + 5, 60, "Subir", W.fdir != VFS_ROOT);
    files_btn(x + 74, cy + 5, 104, "Nova pasta", true);
    files_btn(x + 184, cy + 5, 70, "Apagar", W.fsel >= 0);
    files_btn(x + 260, cy + 5, 90, "Executar", is_elf_ino(W.fsel));
    char p[100]; vfs_path(W.fdir, p, sizeof p);
    draw_text(x + 8, cy + 38, p, 0x4A2F70);
    files_build(W);
    int rows = files_rows(W);
    fill_rect(x + FL_X, cy + FL_Y, FL_W, rows * FL_ROW, 0xFFFFFF);
    draw_rect(x + FL_X - 1, cy + FL_Y - 1, FL_W + 2, rows * FL_ROW + 2, 0xC0B8D0);
    for (int r = 0; r < rows && W.fscroll + r < fl_n; r++) {
        int e = fl_list[W.fscroll + r]; int ry = cy + FL_Y + r * FL_ROW;
        if (e == W.fsel && e >= 0) fill_rect(x + FL_X, ry, FL_W, FL_ROW, 0xD7C4F0);
        if (e == -2) { draw_text(x + FL_X + 6, ry + 3, "[..]  (pasta de cima)", 0x4A2F70); continue; }
        bool dir = vfs_type(e) == VT_DIR;
        draw_text(x + FL_X + 6, ry + 3, dir ? "[D]" : "[F]", dir ? 0x9B59D0 : 0x888888);
        draw_text_n(x + FL_X + 36, ry + 3, vfs_name(e), 28, dir ? 0x4A2F70 : 0x222222);
        if (!dir) { char b[16]; u32 s = vfs_size(e); if (s >= 1024) { int_str(b, (int)(s / 1024)); str_cat(b, " KB", 16); } else { int_str(b, (int)s); str_cat(b, " B", 16); } draw_text(x + FL_X + FL_W - 8 - text_w(b), ry + 3, b, 0x777777); }
    }
    // pre-visualizacao
    int px = x + FL_X + FL_W + 14, pw = W.w - (FL_X + FL_W + 14) - 8;
    fill_rect(px, cy + FL_Y, pw, rows * FL_ROW, 0xFFFFFF);
    draw_rect(px - 1, cy + FL_Y - 1, pw + 2, rows * FL_ROW + 2, 0xC0B8D0);
    if (W.fsel >= 0) {
        draw_text_n(px + 6, cy + FL_Y + 4, vfs_name(W.fsel), pw / 8 - 1, 0x4A2F70);
        int cols = (pw - 12) / 8, lr = 0, cc = 0, maxr = rows * FL_ROW / 10 - 3;
        int ly = cy + FL_Y + 22;
        for (int i = 0; i < fprev_len && lr < maxr; i++) {
            char c = fprev[i];
            if (c == '\n' || cc >= cols) { lr++; cc = 0; if (c == '\n') continue; }
            if (c == '\t') c = ' ';
            if ((u8)c < 32 || (u8)c > 126) c = '.';
            draw_char(px + 6 + cc * 8, ly + lr * 10, c, 0x333333); cc++;
        }
    } else draw_text(px + 6, cy + FL_Y + 6, "Selecione um arquivo", 0x999999);
    u32 f, d, u, t; vfs_stats(&f, &d, &u, &t);
    char s[90] = "Usado: "; char n[12]; int_str(n, (int)(u * 4)); str_cat(s, n, 90); str_cat(s, " KB de ", 90); int_str(n, (int)(t * 4)); str_cat(s, n, 90);
    str_cat(s, vfs_disk_ok() ? " KB  | disco ATA: gravando" : " KB  | SEM disco (so RAM)", 90);
    draw_text(x + 8, W.y + W.h - 16, W.status[0][0] ? W.status[0] : s, W.status[0][0] ? 0x9A3030 : 0x777777);
}
static void files_click(int wi, int rx, int ry) {
    Window& W = win[wi]; W.status[0][0] = 0;
    int cy = TITLE_H;
    if (ry >= cy + 5 && ry < cy + 27) {
        if (rx >= 8 && rx < 68) { if (W.fdir != VFS_ROOT) { W.fdir = vfs_parent(W.fdir); W.fsel = -1; W.fscroll = 0; fprev_len = 0; } }
        else if (rx >= 74 && rx < 178) {
            char nm[VFS_NAME + 1];
            for (int k = 1; k < 50; k++) { str_cpy(nm, "nova_pasta", sizeof nm); if (k > 1) { char b[8]; int_str(b, k); str_cat(nm, b, sizeof nm); } if (vfs_lookup(W.fdir, nm) < 0) break; }
            int r = vfs_create(W.fdir, nm, VT_DIR); if (r < 0) str_cpy(W.status[0], vfs_err_text(r), 100); else W.fsel = r;
        } else if (rx >= 184 && rx < 254 && W.fsel >= 0) {
            int r = vfs_unlink(W.fsel); if (r < 0) str_cpy(W.status[0], r == VE_NOTEMPTY ? "A pasta nao esta vazia (use rm -r no terminal)." : vfs_err_text(r), 100); else { W.fsel = -1; fprev_len = 0; }
        } else if (rx >= 260 && rx < 350 && is_elf_ino(W.fsel)) {
            int t = -1; for (int i = 0; i < MAXW; i++) if (win[i].open && win[i].type == W_TERM) { t = i; break; }
            if (t < 0) t = launch(W_TERM);
            if (t >= 0) { win[t].cwd = W.fdir; win_focus(t); char cmd[60] = "./"; str_cat(cmd, vfs_name(W.fsel), sizeof cmd); if (!win[t].busy && !stdin_wait) term_submit(t, cmd); }
        }
        return;
    }
    if (rx >= FL_X && rx < FL_X + FL_W && ry >= cy + FL_Y) {
        files_build(W);
        int idx = W.fscroll + (ry - cy - FL_Y) / FL_ROW;
        if (idx < 0 || idx >= fl_n || (ry - cy - FL_Y) / FL_ROW >= files_rows(W)) return;
        int e = fl_list[idx];
        if (e == -2) { W.fdir = vfs_parent(W.fdir); W.fsel = -1; W.fscroll = 0; fprev_len = 0; }
        else if (vfs_type(e) == VT_DIR) { W.fdir = e; W.fsel = -1; W.fscroll = 0; fprev_len = 0; }
        else { W.fsel = e; files_preview(e); }
    }
}

static void draw_term(const Window& W, bool focused) {
    int cx = W.x, cy = W.y + TITLE_H;
    fill_rect(cx, cy, W.w, W.h - TITLE_H, 0x1E1E1E);
    for (int r = 0; r < TROWS; r++)
        for (int c = 0; c < TCOLS; c++) {
            char ch = W.cell[r][c];
            if (!ch || ch == ' ') continue;
            u8 a = W.attr[r][c];
            u32 col = a == 1 ? MINT_GREEN : (a == 2 ? 0xE06C6C : 0xDDDDDD);
            draw_char(cx + 6 + c * 8, cy + 6 + r * 10, ch, col);
        }
    if (focused) fill_rect(cx + 6 + W.cc * 8, cy + 6 + W.cr * 10 + 8, 8, 2, 0xDDDDDD);
}
static void draw_about(const Window& W) {
    int x = W.x, cy = W.y + TITLE_H;
    fill_rect(x, cy, W.w, W.h - TITLE_H, 0xEFEFEF);
    fill_rect(x + 20, cy + 20, 64, 64, MINT_GREEN);
    draw_char(x + 32, cy + 32, 'H', 0xFFFFFF, 5);
    draw_text(x + 100, cy + 22, "HollowOS", 0x2B2B2B, 3);
    draw_text(x + 100, cy + 56, "versao 0.5 (alpha)", 0x555555);
    draw_text(x + 20, cy + 104, "Kernel proprio em C++ e assembly", 0x333333);
    draw_text(x + 20, cy + 124, "DuckDuckGo: aplicativo oficial (HTTPS no OS)", 0x333333);
    draw_text(x + 20, cy + 144, "Sistema de arquivos HFS com disco ATA", 0x333333);
    draw_text(x + 20, cy + 164, "Programas Linux i386 (ELF estatico/dinamico)", 0x333333);
    draw_text(x + 20, cy + 184, "Rede: e1000, TCP/IP, TLS 1.2 (sem validar CA)", 0x333333);
    draw_text(x + 20, cy + 204, "Roda no QEMU (x86, 32 bits, -m 256)", 0x333333);
}
static void draw_window(int i) {
    const Window& W = win[i];
    bool focused = (i == topw);
    draw_rect(W.x - 1, W.y - 1, W.w + 2, W.h + 2, 0x101010);
    fill_rect(W.x, W.y, W.w, TITLE_H, focused ? 0x333333 : 0x4D4D4D);
    if (focused) fill_rect(W.x, W.y + TITLE_H - 2, W.w, 2, MINT_GREEN);
    draw_text(W.x + 10, W.y + 8, W.title, focused ? 0xFFFFFF : 0xAAAAAA);
    fill_rect(W.x + W.w - 44, W.y + 3, 18, 18, 0x555555);
    draw_char(W.x + W.w - 44 + 5, W.y + 8, '-', 0xFFFFFF);
    fill_rect(W.x + W.w - 22, W.y + 3, 18, 18, focused ? 0xB04040 : 0x555555);
    draw_char(W.x + W.w - 22 + 5, W.y + 8, 'x', 0xFFFFFF);
    switch (W.type) {
        case W_TERM:    draw_term(W, focused); break;
        case W_BROWSER: draw_browser(W, focused); break;
        case W_ABOUT:   draw_about(W); break;
        case W_FILES:   draw_files(W, focused); break;
    }
}

// ============================================================
//  Area de trabalho, barra de tarefas e menu
// ============================================================
struct IconEntry { const char* label; int type; u32 color; char glyph; };
static const int NICONS = 3;
static const IconEntry ICONS[NICONS] = {
    { "DuckDuckGo", W_BROWSER, DDG_ORANGE, 'D' },
    { "Terminal",   W_TERM,    0x303030, '>' },
    { "Arquivos",   W_FILES,   0x6B3FA0, 'F' },
};
static const int ICON_X = 28, ICON_Y0 = 28, ICON_STEP = 104;

static const int NMENU = 6;
static const char* const MENU_ITEMS[NMENU] = {
    "DuckDuckGo (app oficial)", "Terminal", "Arquivos",
    "Sobre o HollowOS", "Reiniciar", "Desligar"
};
static const int MENU_W = 280, MENU_HEAD = 44, MENU_ITEM_H = 30;
static const int MENU_H = MENU_HEAD + NMENU * MENU_ITEM_H;
static const int MENU_X = 0, MENU_Y = SH - TASKBAR_H - MENU_H;

static void draw_icons() {
    for (int i = 0; i < NICONS; i++) {
        int x = ICON_X, y = ICON_Y0 + i * ICON_STEP;
        fill_rect(x, y, 64, 64, ICONS[i].color);
        draw_rect(x, y, 64, 64, 0x101010);
        draw_char(x + 16, y + 16, ICONS[i].glyph, 0xFFFFFF, 4);
        int tx = x + 32 - text_w(ICONS[i].label) / 2;
        draw_text(tx + 1, y + 73, ICONS[i].label, 0x000000);
        draw_text(tx, y + 72, ICONS[i].label, 0xFFFFFF);
    }
}

// Barra: apps fixados (DuckDuckGo, Terminal, Arquivos) + outros terminais e janelas abertas
struct TbEntry { int type; int wi; const char* label; };
static const int TB_X0 = 108, TB_W = 112, TB_GAP = 4, TB_MAX = 6;
static int tb_build(TbEntry* e) {
    static const int pin[3] = { W_BROWSER, W_TERM, W_FILES };
    static const char* const lab[3] = { "DuckDuckGo", "Terminal", "Arquivos" };
    int n = 0;
    int first_term = -1;
    for (int k = 0; k < 3; k++) { e[n].type = pin[k]; e[n].wi = find_type(pin[k]); e[n].label = lab[k]; if (pin[k] == W_TERM) first_term = e[n].wi; n++; }
    for (int i = 0; i < MAXW && n < TB_MAX; i++)
        if (win[i].open && win[i].type == W_TERM && i != first_term) { e[n].type = W_TERM; e[n].wi = i; e[n].label = "Terminal"; n++; }
    for (int i = 0; i < MAXW && n < TB_MAX; i++)
        if (win[i].open && win[i].type == W_ABOUT) { e[n].type = W_ABOUT; e[n].wi = i; e[n].label = "Sobre"; n++; }
    return n;
}
static void draw_taskbar() {
    int ty = SH - TASKBAR_H;
    fill_rect(0, ty, SW, TASKBAR_H, PANEL_BG);
    fill_rect(0, ty, SW, 1, 0x4A2F70);
    fill_rect(0, ty + 1, 100, TASKBAR_H - 1, menu_open ? 0x4A2F70 : PANEL_BG);
    fill_rect(8, ty + 6, 24, 24, MINT_GREEN);
    draw_char(12, ty + 10, 'H', 0xFFFFFF, 2);
    draw_text(40, ty + 14, "Menu", 0xFFFFFF);
    TbEntry e[8]; int n = tb_build(e);
    for (int k = 0; k < n; k++) {
        int bx = TB_X0 + k * (TB_W + TB_GAP);
        bool open = e[k].wi >= 0;
        bool act = open && e[k].wi == topw;
        fill_rect(bx, ty + 4, TB_W, 28, act ? 0x5B3A8C : (open ? 0x3D2760 : 0x2F1D4A));
        if (e[k].type == W_BROWSER) fill_rect(bx, ty + 4, 4, 28, DDG_ORANGE);       // app oficial
        if (open) fill_rect(bx, ty + 30, TB_W, 2, act ? 0xD7B8FF : MINT_GREEN);
        u32 tc = !open ? 0x9A88B8 : (win[e[k].wi].minimized ? 0xB8A8D0 : 0xFFFFFF);
        draw_text(bx + 10, ty + 14, e[k].label, tc);
        if (open) {
            fill_rect(bx + TB_W - 22, ty + 8, 16, 16, 0x7A3A5A);
            draw_char(bx + TB_W - 22 + 4, ty + 12, 'x', 0xFFFFFF);
        }
    }
    // bandeja: rede + disco + relogio
    int tx = 770;
    u32 nc = !net.present ? 0xD04040 : (net.has_ip ? 0x40C060 : 0xE0B040);
    fill_rect(tx, ty + 14, 8, 8, nc);
    char ip[20] = "sem rede";
    if (net.present && net.has_ip) net_ip_str(net.ip, ip); else if (net.present) str_cpy(ip, "DHCP...", sizeof ip);
    draw_text(tx + 14, ty + 14, ip, 0xDDDDDD);
    fill_rect(tx - 40, ty + 14, 8, 8, vfs_disk_ok() ? 0x40C060 : 0x777777);
    draw_text(tx - 28, ty + 14, "HD", 0xBBBBBB);
    char t[8] = "00:00";
    put2(t, now.h); put2(t + 3, now.m);
    draw_text(SW - 92, ty + 10, t, 0xFFFFFF, 2);
}
static void draw_menu() {
    fill_rect(MENU_X - 1, MENU_Y - 1, MENU_W + 2, MENU_H + 2, 0x101010);
    fill_rect(MENU_X, MENU_Y, MENU_W, MENU_H, PANEL_BG);
    fill_rect(MENU_X, MENU_Y, MENU_W, MENU_HEAD, MINT_GREEN);
    draw_text(MENU_X + 16, MENU_Y + 14, "HollowOS", 0xFFFFFF, 2);
    for (int i = 0; i < NMENU; i++) {
        int iy = MENU_Y + MENU_HEAD + i * MENU_ITEM_H;
        bool hov = inside(mx, my, MENU_X, iy, MENU_W, MENU_ITEM_H);
        if (hov) fill_rect(MENU_X, iy, MENU_W, MENU_ITEM_H, 0x6B3FA0);
        if (i == 0) fill_rect(MENU_X + 8, iy + 9, 4, 12, DDG_ORANGE);
        draw_text(MENU_X + 20, iy + 11, MENU_ITEMS[i], 0xEEEEEE);
    }
}

static void render() {
    target = back;
    copy32(back, wall, SW * SH);
    topw = top_window();
    draw_icons();
    for (int k = 0; k < zn; k++) {
        int i = zo[k];
        if (win[i].open && !win[i].minimized) draw_window(i);
    }
    draw_taskbar();
    if (menu_open) draw_menu();
}

static int cur_x = 0, cur_y = 0;
static void present() {
    copy32((void*)fb, back, SW * SH);
    cursor_draw(mx, my);
    cur_x = mx; cur_y = my;
}
// ============================================================
//  Teclado (PS/2, scancode set 1, layout US)
// ============================================================
static const char KMAP[58] = {
    0, 27, '1','2','3','4','5','6','7','8','9','0','-','=', '\b',
    '\t','q','w','e','r','t','y','u','i','o','p','[',']','\n',
    0, 'a','s','d','f','g','h','j','k','l',';','\'','`',
    0, '\\','z','x','c','v','b','n','m',',','.','/', 0,
    '*', 0, ' '
};
static const char KMAP_SHIFT[58] = {
    0, 27, '!','@','#','$','%','^','&','*','(',')','_','+', '\b',
    '\t','Q','W','E','R','T','Y','U','I','O','P','{','}','\n',
    0, 'A','S','D','F','G','H','J','K','L',':','"','~',
    0, '|','Z','X','C','V','B','N','M','<','>','?', 0,
    '*', 0, ' '
};
static bool shift = false, caps = false, ext = false;

// ============================================================
//  Mouse (PS/2)
// ============================================================
static bool kbc_wait_out() { for (int i = 0; i < 100000; i++) if (inb(0x64) & 1) return true; return false; }
static void kbc_wait_in()  { for (int i = 0; i < 100000; i++) if (!(inb(0x64) & 2)) return; }

static void mouse_write(u8 v) {
    kbc_wait_in(); outb(0x64, 0xD4);
    kbc_wait_in(); outb(0x60, v);
    if (kbc_wait_out()) inb(0x60);                    // le o ACK (0xFA)
}

static void mouse_init() {
    while (inb(0x64) & 1) inb(0x60);                  // limpa buffer
    kbc_wait_in(); outb(0x64, 0xA8);                  // habilita porta do mouse
    kbc_wait_in(); outb(0x64, 0x20);                  // le byte de configuracao
    u8 cfg = kbc_wait_out() ? inb(0x60) : 0;
    cfg |= 2; cfg &= ~0x20;
    kbc_wait_in(); outb(0x64, 0x60);
    kbc_wait_in(); outb(0x60, cfg);
    mouse_write(0xF6);                                // padroes
    mouse_write(0xF4);                                // liga envio de dados
}

// ---- vmmouse: posicao ABSOLUTA do mouse do host (QEMU). Da o 1:1 com o cursor. ----
static bool vmm_on = false;
static void vmm_cmd(u32 cmd, u32 arg, u32* o) {
    u32 a = 0x564D5868u, b = arg, c = cmd, d = 0x5658;
    asm volatile("inl %%dx, %%eax" : "+a"(a), "+b"(b), "+c"(c), "+d"(d) :: "memory");
    o[0] = a; o[1] = b; o[2] = c; o[3] = d;
}
static void vmm_init() {
    u32 r[4];
    vmm_cmd(10, 0, r);                       // GETVERSION
    if (r[1] != 0x564D5868u) return;         // sem vmport: fica no PS/2 relativo
    vmm_cmd(41, 0x45414552u, r);             // ENABLE
    vmm_cmd(40, 0, r);                       // STATUS
    if ((r[0] & 0xFFFF) == 0 || r[0] == 0xFFFF0000u) {
        // fila vazia e normal; so aborta se deu erro
        if (r[0] == 0xFFFF0000u) return;
    }
    vmm_cmd(39, 1, r);                       // le versao/ID
    vmm_cmd(41, 0x53424152u, r);             // REQUEST_ABSOLUTE
    vmm_on = true;
}
static void handle_mouse(int nb);
static void vmm_poll() {
    if (!vmm_on) return;
    for (int guard = 0; guard < 16; guard++) {
        u32 r[4];
        vmm_cmd(40, 0, r);
        if (r[0] == 0xFFFF0000u) {           // erro: reabilita
            vmm_cmd(41, 0x45414552u, r); vmm_cmd(41, 0x53424152u, r);
            return;
        }
        if ((r[0] & 0xFFFF) < 4) return;
        vmm_cmd(39, 4, r);                   // 1 pacote: status, x, y, z
        int nx = (int)(((unsigned long long)(r[1] & 0xFFFF) * SW) >> 16);
        int ny = (int)(((unsigned long long)(r[2] & 0xFFFF) * SH) >> 16);
        if (nx > SW - 1) nx = SW - 1;
        if (ny > SH - 1) ny = SH - 1;
        mx = nx; my = ny;
        int btn = ((r[0] & 0x20) ? 1 : 0) | ((r[0] & 0x10) ? 2 : 0) | ((r[0] & 0x08) ? 4 : 0);
        handle_mouse(btn);
    }
}


// ============================================================
//  Teclado: Ctrl, setas, digitacao
// ============================================================
static bool ctrl = false;

static void on_key(char c) {
    rng_add_u32(rdtsc32());
    if (c == 27) { if (menu_open) { menu_open = false; dirty = true; } if (net_busy) net_cancel = true; return; }
    int wi = top_window();
    if (wi < 0) return;
    Window& W = win[wi];
    dirty = true;

    if (W.type == W_TERM) {
        if (stdin_wait && wi == run_wi) {                 // o programa Linux pediu uma linha (stdin)
            if (c == 4) { if (sin_len == 0) sin_eof = true; sin_ready = true; }
            else if (c == '\n') { term_putc(W, '\n', 0); if (sin_len < (int)sizeof(sin_buf) - 1) sin_buf[sin_len++] = '\n'; sin_ready = true; }
            else if (c == '\b') { if (sin_len > 0) { sin_len--; if (W.cc > 0) { W.cc--; W.cell[W.cr][W.cc] = 0; } } }
            else if (c >= ' ' && sin_len < (int)sizeof(sin_buf) - 2) { sin_buf[sin_len++] = c; term_putc(W, c, 0); }
            return;
        }
        if (W.busy || run_wi == wi) return;               // comando em andamento: ignora teclas
        if (c == '\n') {
            term_enter(wi);
        } else if (c == '\b') {
            if (W.llen > 0) {
                W.llen--;
                if (W.cc == 0 && W.cr > 0) { W.cr--; W.cc = TCOLS; }
                W.cc--; W.cell[W.cr][W.cc] = 0;
            }
        } else if (c >= ' ' && W.llen < 150) {
            W.line[W.llen++] = c;
            term_putc(W, c, 0);
        }
    } else if (W.type == W_BROWSER) {
        if (c == '\n') br_go(W);
        else if (c == '\b') { if (W.qfresh) { W.qlen = 0; W.query[0] = 0; W.qfresh = false; } else if (W.qlen > 0) W.query[--W.qlen] = 0; }
        else if (c >= ' ') {
            if (W.qfresh) { W.qlen = 0; W.qfresh = false; }
            if (W.qlen < 120) { W.query[W.qlen++] = c; W.query[W.qlen] = 0; }
        }
    }
}

static void on_scancode(u8 sc) {
    if (sc == 0xE0) { ext = true; return; }
    if (ext) {                                        // teclas estendidas: setas e PgUp/PgDn
        ext = false;
        if (sc & 0x80) return;
        int wi = top_window();
        if (wi < 0) return;
        Window& W = win[wi];
        int d = sc == 0x48 ? -1 : sc == 0x50 ? 1 : sc == 0x49 ? -8 : sc == 0x51 ? 8 : 0;
        if (!d) return;
        if (W.type == W_BROWSER && page_ok) {
            if (sc == 0x49 || sc == 0x51) d = d < 0 ? -(br_rows(W) - 1) : (br_rows(W) - 1);
            int mxs = page.nlines - br_rows(W); if (mxs < 0) mxs = 0;
            W.scroll += d; if (W.scroll < 0) W.scroll = 0; if (W.scroll > mxs) W.scroll = mxs;
            dirty = true;
        } else if (W.type == W_FILES) {
            files_build(W);
            int mxs = fl_n - files_rows(W); if (mxs < 0) mxs = 0;
            W.fscroll += d; if (W.fscroll < 0) W.fscroll = 0; if (W.fscroll > mxs) W.fscroll = mxs;
            dirty = true;
        }
        return;
    }
    if (sc == 0x1D) { ctrl = true; return; }
    if (sc == 0x9D) { ctrl = false; return; }
    if (sc & 0x80) {                                  // tecla solta
        u8 k = sc & 0x7F;
        if (k == 0x2A || k == 0x36) shift = false;
        return;
    }
    if (sc == 0x2A || sc == 0x36) { shift = true; return; }
    if (sc == 0x3A) { caps = !caps; return; }
    if (sc >= 58) return;
    char c = shift ? KMAP_SHIFT[sc] : KMAP[sc];
    if (caps && c >= 'a' && c <= 'z') c -= 32;
    else if (caps && c >= 'A' && c <= 'Z' && shift) c += 32;
    if (!c) return;
    if (ctrl) {
        if (c == 'c' || c == 'C') { abort_flag = true; if (net_busy) net_cancel = true; dirty = true; return; }
        if (c == 'd' || c == 'D') c = 4; else return;
    }
    on_key(c);
}


static void br_nav(Window& W, int dir) {
    if (dir < 0 && hi > 0) { hi--; br_load(W, hist[hi], false); }
    else if (dir > 0 && hi >= 0 && hi < hn - 1) { hi++; br_load(W, hist[hi], false); }
    else if (dir == 0 && hi >= 0) br_load(W, hist[hi], false);
}

static void on_press() {
    rng_add_u32(rdtsc32() ^ (u32)(mx * 7 + my));
    if (menu_open) {
        menu_open = false; dirty = true;
        if (inside(mx, my, MENU_X, MENU_Y + MENU_HEAD, MENU_W, NMENU * MENU_ITEM_H)) {
            int idx = (my - (MENU_Y + MENU_HEAD)) / MENU_ITEM_H;
            switch (idx) {
                case 0: launch(W_BROWSER); break;
                case 1: launch(W_TERM); break;
                case 2: launch(W_FILES); break;
                case 3: launch(W_ABOUT); break;
                case 4: do_reboot(); break;
                case 5: do_poweroff(); break;
            }
            return;
        }
        if (inside(mx, my, 0, SH - TASKBAR_H, 100, TASKBAR_H)) return;
    }

    if (my >= SH - TASKBAR_H) {
        dirty = true;
        if (mx < 100) { menu_open = true; return; }
        TbEntry e[8]; int n = tb_build(e);
        for (int k = 0; k < n; k++) {
            int bx = TB_X0 + k * (TB_W + TB_GAP);
            int ty = SH - TASKBAR_H;
            if (!inside(mx, my, bx, ty + 4, TB_W, 28)) continue;
            int wi = e[k].wi;
            if (wi < 0)                                   launch(e[k].type);
            else if (inside(mx, my, bx + TB_W - 22, ty + 8, 16, 16)) win_close(wi);
            else if (win[wi].minimized)                   win_focus(wi);
            else if (wi == topw)                          win[wi].minimized = true;
            else                                          win_focus(wi);
            return;
        }
        return;
    }

    for (int k = zn - 1; k >= 0; k--) {
        int i = zo[k];
        Window& W = win[i];
        if (!W.open || W.minimized) continue;
        if (!inside(mx, my, W.x, W.y, W.w, W.h)) continue;

        win_focus(i);
        int rx = mx - W.x, ry = my - W.y;
        if (ry < TITLE_H) {
            if (inside(rx, ry, W.w - 22, 3, 18, 18)) { win_close(i); return; }
            if (inside(rx, ry, W.w - 44, 3, 18, 18)) { W.minimized = true; return; }
            drag = i; drag_dx = rx; drag_dy = ry;
            return;
        }
        if (W.type == W_BROWSER) {
            int bx, by, bw; br_geom(W, bx, by, bw);
            int bh = page_ok ? 24 : 36;
            if (inside(rx, ry, bx + bw, by, 80, bh)) br_go(W);
            else if (ry >= TITLE_H + 8 && ry < TITLE_H + 32 && rx >= 10 && rx < 10 + 3 * 34 && (rx - 10) % 34 < 28) br_nav(W, (rx - 10) / 34 == 0 ? -1 : ((rx - 10) / 34 == 1 ? 1 : 0));
            else if (page_ok && ry >= BR_TOP) {
                int row = (ry - BR_TOP) / 10, li = W.scroll + row;
                if (row < br_rows(W) && li < page.nlines && page.link_of[li] >= 0) {
                    static char target[PG_URLLEN + 8]; str_cpy(target, page.links[page.link_of[li]], sizeof target);
                    br_load(W, target, true);
                }
            }
        } else if (W.type == W_FILES) files_click(i, rx, ry);
        return;
    }

    for (int i = 0; i < NICONS; i++) {
        if (inside(mx, my, ICON_X - 8, ICON_Y0 + i * ICON_STEP - 8, 80, 96)) {
            launch(ICONS[i].type);
            return;
        }
    }
}

static void handle_mouse(int nb) {
    bool press   = (nb & 1) && !(mbtn & 1);
    bool release = !(nb & 1) && (mbtn & 1);
    mbtn = nb;

    if (drag >= 0 && (nb & 1)) {
        Window& W = win[drag];
        int nx = mx - drag_dx, ny = my - drag_dy;
        if (ny < 0) ny = 0;
        if (ny > SH - TASKBAR_H - TITLE_H) ny = SH - TASKBAR_H - TITLE_H;
        if (nx < -(W.w - 100)) nx = -(W.w - 100);
        if (nx > SW - 100) nx = SW - 100;
        W.x = nx; W.y = ny;
        dirty = true;
    }
    if (release) drag = -1;
    if (press) on_press();
    if (menu_open) dirty = true;
}

static u8 mpkt[3];
static int midx = 0;
static void on_mouse_byte(u8 d) {
    if (midx == 0 && !(d & 8)) return;
    mpkt[midx++] = d;
    if (midx < 3) return;
    midx = 0;
    if (vmm_on) return;
    if (mpkt[0] & 0xC0) return;
    int dx = (int)mpkt[1] - (((int)mpkt[0] << 4) & 0x100);
    int dy = (int)mpkt[2] - (((int)mpkt[0] << 3) & 0x100);
    mx += dx; my -= dy;
    if (mx < 0) mx = 0;
    if (my < 0) my = 0;
    if (mx > SW - 1) mx = SW - 1;
    if (my > SH - 1) my = SH - 1;
    handle_mouse(mpkt[0] & 7);
}

static void input_poll() {
    for (;;) {
        u8 st = inb(0x64);
        if (!(st & 1)) break;
        u8 d = inb(0x60);
        if (st & 0x20) on_mouse_byte(d);
        else           on_scancode(d);
    }
    vmm_poll();
}

static bool in_tick = false;
static u32  last_draw = 0;
static void ui_tick() {
    if (in_tick) return;
    in_tick = true;
    input_poll();
    net_poll();
    u32 t = net_ms();
    if (dirty && (u32)(t - last_draw) >= 30) { render(); present(); dirty = false; last_draw = t; }
    else if (mx != cur_x || my != cur_y) { cursor_restore(cur_x, cur_y); cursor_draw(mx, my); cur_x = mx; cur_y = my; }
    in_tick = false;
}

// ============================================================
//  Ponto de entrada (chamado pelo boot.asm)
// ============================================================
static void fatal_text(const char* msg) {
    volatile u16* vga = (volatile u16*)0xB8000;
    for (int i = 0; i < 80 * 25; i++) vga[i] = 0x0F00 | ' ';
    for (int i = 0; msg[i]; i++) vga[i] = 0x0C00 | (u8)msg[i];
    for (;;) asm volatile("hlt");
}
static bool disk_is_blank() {
    if (!disk_init()) return false;
    static u8 b[512 * 8];
    if (!disk_read(0, 8, b)) return false;
    for (int i = 0; i < (int)sizeof b; i++) if (b[i]) return false;
    return true;
}

extern "C" void kernel_main(u32 magic, u32 info) {
    (void)magic; (void)info;

    if (!init_video())
        fatal_text("HollowOS precisa da placa VGA do QEMU: rode com -vga std");

    build_wallpaper();
    mouse_init();
    vmm_init();
    rng_add_u32(rdtsc32());
    net_init();
    net_idle = ui_tick;                         // mantem a tela viva durante operacoes de rede demoradas
    read_time(now);
    rng_add_u32((u32)now.s | ((u32)now.m << 8) | ((u32)now.h << 16)); rng_add_entropy(net.mac, 6);

    // ---- sistema de arquivos: disco ATA (se houver) ou so RAM
    vfs_clock = clock_cb;
    vfs_init();
    const char* disk_msg = 0;
    if (!vfs_mount_disk()) {
        vfs_init();
        if (disk_is_blank()) { if (!vfs_format_disk()) disk_msg = "Disco pequeno demais: usando so a RAM."; }
        else if (disk_sectors() > 0) disk_msg = "Aviso: o disco tem dados que nao sao HFS. Nada foi apagado; usando so a RAM. (format sim apaga o disco)";
        else disk_msg = "Sem disco: os arquivos somem ao desligar. Rode com: make run";
    }
    populate_defaults();
    vfs_sync();

    int t = launch(W_TERM);
    if (t >= 0 && disk_msg) { term_line(win[t], disk_msg, 2); term_prompt(win[t]); win[t].llen = 0; }
    launch(W_BROWSER);

    u32 tick = 0;
    int last_min = now.m;
    bool had_ip = false;
    for (;;) {
        ui_tick();

        if ((++tick & 0x1FFF) == 0) {
            read_time(now);
            if (now.m != last_min) { last_min = now.m; dirty = true; }
        }
        if (net.has_ip != had_ip) {
            had_ip = net.has_ip; dirty = true;
            if (had_ip) { char r[40] = "nameserver "; char ip[20]; net_ip_str(net.dns, ip); str_cat(r, ip, sizeof r); str_cat(r, "\n", sizeof r); vfs_write_file("/etc/resolv.conf", r, (u32)str_len(r)); }
        }
        vfs_autosync(net_ms());
        asm volatile("pause");
    }
}

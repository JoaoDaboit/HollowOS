// html.cpp - HollowOS: HTML -> texto. Nao e um navegador de verdade: ignora CSS e JavaScript,
// mostra o texto da pagina em linhas e guarda os links para voce clicar.
#include "html.h"

static int slen(const char* s) { int n = 0; while (s[n]) n++; return n; }
static void scpy(char* d, const char* s, int max) { int i = 0; for (; s[i] && i < max - 1; i++) d[i] = s[i]; d[i] = 0; }
static char lc(char c) { return (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c; }
static bool starts_ci(const char* s, const char* p) { while (*p) { if (lc(*s) != lc(*p)) return false; s++; p++; } return true; }

// ---------------------------------------------------------------- UTF-8 -> ASCII
static const char* const L1[64] = {      // U+00C0 .. U+00FF
    "A","A","A","A","A","A","AE","C","E","E","E","E","I","I","I","I",
    "D","N","O","O","O","O","O","x","O","U","U","U","U","Y","T","ss",
    "a","a","a","a","a","a","ae","c","e","e","e","e","i","i","i","i",
    "d","n","o","o","o","o","o","/","o","u","u","u","u","y","t","y" };
static const char* fold_cp(unsigned cp, char* tmp) {
    if (cp < 128) { tmp[0] = (char)cp; tmp[1] = 0; return tmp; }
    if (cp >= 0xC0 && cp <= 0xFF) return L1[cp - 0xC0];
    switch (cp) {
        case 0xA0: case 0x2002: case 0x2003: case 0x2009: case 0x200A: case 0x202F: return " ";
        case 0xA9: return "(c)"; case 0xAE: return "(R)"; case 0xB0: return "o"; case 0xB7: return "."; case 0xAB: return "<<"; case 0xBB: return ">>";
        case 0xBF: return "?"; case 0xA1: return "!"; case 0xB1: return "+/-"; case 0xD7: return "x";
        case 0x2018: case 0x2019: case 0x201A: case 0x2032: return "'";
        case 0x201C: case 0x201D: case 0x201E: case 0x2033: return "\"";
        case 0x2010: case 0x2011: case 0x2012: case 0x2013: case 0x2014: case 0x2212: return "-";
        case 0x2022: case 0x25CF: return "*"; case 0x2026: return "..."; case 0x20AC: return "EUR"; case 0x2122: return "(TM)";
        case 0x2192: return "->"; case 0x2190: return "<-"; case 0x203A: return ">"; case 0x2039: return "<";
        case 0x141: return "L"; case 0x142: return "l"; case 0x152: return "OE"; case 0x153: return "oe";
        case 0x160: return "S"; case 0x161: return "s"; case 0x178: return "Y"; case 0x17D: return "Z"; case 0x17E: return "z";
        case 0x200B: case 0x200C: case 0x200D: case 0xFEFF: case 0xAD: return "";
    }
    return "?";
}
// decodifica 1 caractere UTF-8 em *i (avanca). Sequencias invalidas viram '?'.
static unsigned utf8_next(const unsigned char* s, int n, int* i) {
    unsigned c = s[*i];
    if (c < 0x80) { (*i)++; return c; }
    int len = (c >= 0xF0) ? 4 : (c >= 0xE0) ? 3 : (c >= 0xC0) ? 2 : 0;
    if (!len || *i + len > n) { (*i)++; return '?'; }
    unsigned cp = c & (0xFF >> (len + 1));
    for (int k = 1; k < len; k++) { if ((s[*i + k] & 0xC0) != 0x80) { (*i)++; return '?'; } cp = (cp << 6) | (s[*i + k] & 0x3F); }
    *i += len; return cp;
}
int fold_utf8(const char* in, int n, char* out, int max) {
    int o = 0, i = 0; char tmp[2];
    while (i < n && o < max - 1) {
        unsigned cp = utf8_next((const unsigned char*)in, n, &i);
        const char* f = fold_cp(cp, tmp);
        for (int k = 0; f[k] && o < max - 1; k++) out[o++] = f[k];
    }
    out[o] = 0; return o;
}

// ---------------------------------------------------------------- construtor de linhas
void page_reset(TextPage* p) {
    p->nlines = 0; p->nlinks = 0; p->col = 0; p->cur_link = -1; p->wlen = 0; p->blank_run = 1;
    p->pending_space = false; p->in_pre = false; p->title[0] = 0;
    p->lines[0][0] = 0; p->link_of[0] = -1;
}
static void line_end(TextPage* p) {                 // fecha a linha atual
    if (p->nlines >= PG_LINES - 1) return;
    p->lines[p->nlines][p->col] = 0;
    p->nlines++; p->col = 0;
    p->lines[p->nlines][0] = 0; p->link_of[p->nlines] = -1;
}
static void flush_word(TextPage* p) {
    if (!p->wlen) return;
    int need = p->wlen + (p->col > 0 && p->pending_space ? 1 : 0);
    if (p->col + need > PG_COLS - 2 && p->col > 0) { line_end(p); need = p->wlen; }
    if (p->col > 0 && p->pending_space) p->lines[p->nlines][p->col++] = ' ';
    for (int i = 0; i < p->wlen; i++) {
        if (p->col >= PG_COLS - 2) { line_end(p); }
        if (p->nlines >= PG_LINES - 1 && p->col >= PG_COLS - 2) break;
        p->lines[p->nlines][p->col++] = p->word[i];
    }
    if (p->cur_link >= 0 && p->link_of[p->nlines] < 0) p->link_of[p->nlines] = (short)p->cur_link;
    p->lines[p->nlines][p->col] = 0;
    p->wlen = 0; p->pending_space = false; p->blank_run = 0;
}
static void soft_break(TextPage* p) { flush_word(p); if (p->col > 0) line_end(p); p->pending_space = false; }
static void blank_line(TextPage* p) {
    soft_break(p);
    if (p->blank_run == 0 && p->nlines > 0) { line_end(p); p->blank_run = 1; }
}
static void put_char(TextPage* p, char c) {
    if (c == '\n' || c == '\r' || c == '\t' || c == ' ') {
        if (p->in_pre && c == '\n') { soft_break(p); return; }
        flush_word(p); p->pending_space = true; return;
    }
    if ((unsigned char)c < 32 || (unsigned char)c > 126) c = '?';
    if (p->wlen < PG_COLS - 3) p->word[p->wlen++] = c;
    else { flush_word(p); p->word[p->wlen++] = c; }
}
static void put_str(TextPage* p, const char* s) { for (; *s; s++) put_char(p, *s); }
void page_add_line(TextPage* p, const char* s, int link) {
    soft_break(p);
    int k = 0; while (s[k] && k < PG_COLS - 2) { p->lines[p->nlines][k] = ((unsigned char)s[k] < 32 || (unsigned char)s[k] > 126) ? '?' : s[k]; k++; }
    p->col = k; if (link >= 0) p->link_of[p->nlines] = (short)link;
    line_end(p); p->blank_run = (k == 0);
}
static int add_link(TextPage* p, const Url* base, const char* href) {
    if (!*href || *href == '#' || starts_ci(href, "javascript:") || starts_ci(href, "mailto:") || starts_ci(href, "data:") || starts_ci(href, "tel:")) return -1;
    if (p->nlinks >= PG_LINKS) return -1;
    char abs[PG_URLLEN + 100];
    if (base) url_resolve(*base, href, abs, sizeof abs); else scpy(abs, href, sizeof abs);
    for (int i = 0; abs[i]; i++) if (abs[i] == '#') { abs[i] = 0; break; }   // sem fragmento
    scpy(p->links[p->nlinks], abs, PG_URLLEN);
    return p->nlinks++;
}

// ---------------------------------------------------------------- entidades
static unsigned entity(const char* s, int n, int* used) {       // s aponta para depois do '&'; devolve 0 se nao for entidade
    int e = 0; while (e < n && e < 12 && s[e] != ';' && s[e] != ' ' && s[e] != '<' && s[e] != '&') e++;
    if (e >= n || s[e] != ';' || e == 0) return 0;
    *used = e + 1;
    if (s[0] == '#') {
        unsigned v = 0;
        if (s[1] == 'x' || s[1] == 'X') { for (int i = 2; i < e; i++) { char c = lc(s[i]); v = v * 16 + (c >= 'a' ? c - 'a' + 10 : c - '0'); } }
        else for (int i = 1; i < e; i++) v = v * 10 + (unsigned)(s[i] - '0');
        return v ? v : '?';
    }
    struct E { const char* n; unsigned v; };
    static const E T[] = { {"amp",'&'},{"lt",'<'},{"gt",'>'},{"quot",'"'},{"apos",'\''},{"nbsp",0xA0},{"copy",0xA9},{"reg",0xAE},{"hellip",0x2026},
        {"mdash",0x2014},{"ndash",0x2013},{"laquo",0xAB},{"raquo",0xBB},{"middot",0xB7},{"bull",0x2022},{"rsquo",0x2019},{"lsquo",0x2018},
        {"rdquo",0x201D},{"ldquo",0x201C},{"euro",0x20AC},{"trade",0x2122},{"deg",0xB0},{"times",0xD7},{"eacute",0xE9},{"egrave",0xE8},
        {"aacute",0xE1},{"agrave",0xE0},{"atilde",0xE3},{"acirc",0xE2},{"ccedil",0xE7},{"iacute",0xED},{"oacute",0xF3},{"otilde",0xF5},
        {"ocirc",0xF4},{"uacute",0xFA},{"ecirc",0xEA},{"ntilde",0xF1},{"uuml",0xFC},{"ouml",0xF6},{"auml",0xE4},{"Eacute",0xC9},{"Aacute",0xC1},
        {"Ccedil",0xC7},{"Atilde",0xC3},{"Oacute",0xD3},{"Iacute",0xCD},{"Uacute",0xDA},{"szlig",0xDF} };
    for (unsigned i = 0; i < sizeof T / sizeof T[0]; i++) {
        int k = 0; while (T[i].n[k] && T[i].n[k] == s[k]) k++;
        if (!T[i].n[k] && k == e) return T[i].v;
    }
    return 0;
}
static void put_cp(TextPage* p, unsigned cp) { char t[2]; put_str(p, fold_cp(cp, t)); }

// ---------------------------------------------------------------- tags
static bool attr_get(const char* t, int n, const char* name, char* out, int max) {        // t = texto da tag (sem < >)
    int nl = slen(name);
    for (int i = 0; i < n; i++) {
        if ((i == 0 || t[i - 1] == ' ' || t[i - 1] == '\t' || t[i - 1] == '\n' || t[i - 1] == '"' || t[i - 1] == '\'') && starts_ci(t + i, name) && t[i + nl] == '=') {
            int j = i + nl + 1; char q = 0;
            if (t[j] == '"' || t[j] == '\'') q = t[j++];
            int o = 0;
            while (j < n && o < max - 1 && (q ? t[j] != q : (t[j] != ' ' && t[j] != '>' && t[j] != '\t' && t[j] != '\n'))) out[o++] = t[j++];
            out[o] = 0; return true;
        }
    }
    return false;
}
static int tag_end(const char* h, int n, int i) {                // i aponta para '<'; retorna indice do '>' (respeita aspas)
    char q = 0;
    for (int j = i + 1; j < n; j++) {
        if (q) { if (h[j] == q) q = 0; }
        else if (h[j] == '"' || h[j] == '\'') q = h[j];
        else if (h[j] == '>') return j;
    }
    return n - 1;
}
static int find_close(const char* h, int n, int from, const char* name) {   // posicao de "</name" depois de from
    int nl = slen(name);
    for (int i = from; i + 2 + nl < n; i++)
        if (h[i] == '<' && h[i + 1] == '/' && starts_ci(h + i + 2, name)) return i;
    return n;
}
static bool is_block(const char* t) {
    static const char* B[] = { "div","section","article","header","footer","nav","main","aside","form","fieldset","figure","table","tr","ul","ol","dl","dt","dd","li","br","hr","details","summary","address","tbody","thead" };
    for (unsigned i = 0; i < sizeof B / sizeof B[0]; i++) { int k = 0; while (B[i][k] && B[i][k] == t[k]) k++; if (!B[i][k] && !t[k]) return true; }
    return false;
}
static bool name_is(const char* a, const char* b) { int k = 0; while (a[k] && a[k] == b[k]) k++; return a[k] == b[k]; }

void page_from_html(TextPage* p, const char* h, int n, const Url* base) {
    page_reset(p);
    for (int i = 0; i < n && p->nlines < PG_LINES - 1;) {
        char c = h[i];
        if (c == '<') {
            if (i + 3 < n && h[i + 1] == '!' && h[i + 2] == '-' && h[i + 3] == '-') {          // comentario
                int j = i + 4; while (j + 2 < n && !(h[j] == '-' && h[j + 1] == '-' && h[j + 2] == '>')) j++;
                i = j + 3; continue;
            }
            if (i + 1 >= n || !((h[i + 1] >= 'a' && h[i + 1] <= 'z') || (h[i + 1] >= 'A' && h[i + 1] <= 'Z') || h[i + 1] == '/')) { put_char(p, '<'); i++; continue; }
            int e = tag_end(h, n, i);
            bool closing = h[i + 1] == '/';
            int s = i + 1 + (closing ? 1 : 0);
            char name[16]; int nl = 0;
            while (s < e && nl < 15 && ((h[s] >= 'a' && h[s] <= 'z') || (h[s] >= 'A' && h[s] <= 'Z') || (h[s] >= '0' && h[s] <= '9'))) name[nl++] = lc(h[s++]);
            name[nl] = 0;
            const char* ta = h + s; int tn = e - s;                                          // atributos
            if (!closing && (name_is(name, "script") || name_is(name, "style") || name_is(name, "noscript") || name_is(name, "svg") || name_is(name, "template") || name_is(name, "iframe"))) {
                int j = find_close(h, n, e, name); i = j; if (i < n) i = tag_end(h, n, i) + 1; continue;
            }
            if (name_is(name, "title") && !closing) {
                int j = find_close(h, n, e, "title");
                fold_utf8(h + e + 1, j - e - 1 > 200 ? 200 : j - e - 1, p->title, sizeof p->title);
                for (int k = 0; p->title[k]; k++) if (p->title[k] == '\n' || p->title[k] == '\r' || p->title[k] == '\t') p->title[k] = ' ';
                i = j; if (i < n) i = tag_end(h, n, i) + 1; continue;
            }
            if (name_is(name, "a")) {
                if (!closing) { char href[PG_URLLEN + 40]; if (attr_get(ta, tn, "href", href, sizeof href)) { flush_word(p); p->cur_link = add_link(p, base, href); } }
                else { flush_word(p); p->cur_link = -1; }
            } else if (name_is(name, "img")) {
                char alt[60]; if (attr_get(ta, tn, "alt", alt, sizeof alt) && alt[0]) { put_str(p, "["); char f[64]; fold_utf8(alt, slen(alt), f, sizeof f); put_str(p, f); put_str(p, "]"); }
            } else if (name_is(name, "pre")) { blank_line(p); p->in_pre = !closing; }
            else if (nl == 2 && name[0] == 'h' && name[1] >= '1' && name[1] <= '6') blank_line(p);
            else if (name_is(name, "p") || name_is(name, "blockquote")) blank_line(p);
            else if (name_is(name, "li")) { soft_break(p); if (!closing) put_str(p, "* "); }
            else if (name_is(name, "br") || name_is(name, "hr")) soft_break(p);
            else if (name_is(name, "td") || name_is(name, "th")) { if (closing) put_str(p, " | "); }
            else if (is_block(name)) soft_break(p);
            else if (name_is(name, "input") || name_is(name, "button") || name_is(name, "select") || name_is(name, "textarea")) { flush_word(p); p->pending_space = true; }
            i = e + 1; continue;
        }
        if (c == '&') {
            int used = 0; unsigned cp = entity(h + i + 1, n - i - 1, &used);
            if (cp) { put_cp(p, cp); i += 1 + used; continue; }
            put_char(p, '&'); i++; continue;
        }
        if ((unsigned char)c >= 0x80) { unsigned cp = utf8_next((const unsigned char*)h, n, &i); put_cp(p, cp); continue; }
        put_char(p, c); i++;
    }
    soft_break(p);
    if (p->nlines == 0) page_add_line(p, "(pagina sem texto)", -1);
}

void page_from_text(TextPage* p, const char* t, int n) {
    page_reset(p);
    p->in_pre = true;
    for (int i = 0; i < n && p->nlines < PG_LINES - 1;) {
        if ((unsigned char)t[i] >= 0x80) { unsigned cp = utf8_next((const unsigned char*)t, n, &i); put_cp(p, cp); continue; }
        if (t[i] == '\t') { put_str(p, "    "); i++; continue; }
        if (t[i] == ' ') { flush_word(p); p->pending_space = true; /* mantem espacos */ if (p->col > 0 && p->col < PG_COLS - 3) { p->lines[p->nlines][p->col++] = ' '; p->pending_space = false; } i++; continue; }
        put_char(p, t[i]); i++;
    }
    soft_break(p);
    if (p->nlines == 0) page_add_line(p, "(vazio)", -1);
}

// ---------------------------------------------------------------- resultados do DuckDuckGo (html.duckduckgo.com/html)
static const char* find_str(const char* h, int n, int from, const char* pat) {
    int pl = slen(pat);
    for (int i = from; i + pl <= n; i++) { int k = 0; while (k < pl && h[i + k] == pat[k]) k++; if (k == pl) return h + i; }
    return 0;
}
static void inner_text(const char* h, int n, char* out, int max) {          // texto de um trecho HTML (sem tags), ja em ASCII
    char tmp[1200]; int o = 0;
    for (int i = 0; i < n && o < (int)sizeof(tmp) - 8;) {
        if (h[i] == '<') { int e = tag_end(h, n, i); tmp[o++] = ' '; i = e + 1; continue; }
        if (h[i] == '&') { int used = 0; unsigned cp = entity(h + i + 1, n - i - 1, &used); if (cp) { char t[2]; const char* f = fold_cp(cp, t); while (*f && o < (int)sizeof(tmp) - 8) tmp[o++] = *f++; i += 1 + used; continue; } }
        if ((unsigned char)h[i] >= 0x80) { unsigned cp = utf8_next((const unsigned char*)h, n, &i); char t[2]; const char* f = fold_cp(cp, t); while (*f && o < (int)sizeof(tmp) - 8) tmp[o++] = *f++; continue; }
        tmp[o++] = h[i++];
    }
    tmp[o] = 0;
    int k = 0; bool sp = true;
    for (int i = 0; tmp[i] && k < max - 1; i++) {
        char c = tmp[i];
        if (c == ' ' || c == '\n' || c == '\r' || c == '\t') { if (!sp) { out[k++] = ' '; sp = true; } }
        else { out[k++] = ((unsigned char)c < 32 || (unsigned char)c > 126) ? '?' : c; sp = false; }
    }
    while (k > 0 && out[k - 1] == ' ') k--;
    out[k] = 0;
}
static void add_wrapped(TextPage* p, const char* indent, const char* text, int link) {
    int il = slen(indent); int width = PG_COLS - 3 - il;
    int i = 0, tl = slen(text);
    while (i < tl && p->nlines < PG_LINES - 2) {
        while (text[i] == ' ') i++;
        int len = tl - i; if (len > width) { len = width; while (len > 12 && text[i + len] != ' ') len--; if (len <= 12) len = width; }
        char ln[PG_COLS]; int k = 0; for (int a = 0; a < il; a++) ln[k++] = indent[a];
        for (int a = 0; a < len; a++) ln[k++] = text[i + a];
        while (k > il && ln[k - 1] == ' ') k--;
        ln[k] = 0; page_add_line(p, ln, link);
        i += len;
    }
}
void page_from_ddg(TextPage* p, const char* h, int n, const char* query) {
    page_reset(p);
    char head[PG_COLS]; scpy(head, "DuckDuckGo: ", sizeof head);
    { char q[60]; fold_utf8(query, slen(query) > 56 ? 56 : slen(query), q, sizeof q); int k = slen(head); for (int i = 0; q[i] && k < PG_COLS - 2; i++) head[k++] = q[i]; head[k] = 0; }
    scpy(p->title, head, sizeof p->title);
    page_add_line(p, head, -1);
    page_add_line(p, "========================================", -1);
    page_add_line(p, "", -1);
    int count = 0, pos = 0;
    while (count < 25) {
        const char* m = find_str(h, n, pos, "result__a");
        if (!m) break;
        int mi = (int)(m - h);
        // volta ate o '<a' desta tag
        int ts = mi; while (ts > 0 && !(h[ts] == '<' && (h[ts + 1] == 'a' || h[ts + 1] == 'A'))) { ts--; if (mi - ts > 400) break; }
        int te = tag_end(h, n, ts);
        char href[800];
        pos = te + 1;
        if (!attr_get(h + ts + 1, te - ts - 1, "href", href, sizeof href)) continue;
        int ce = find_close(h, n, te + 1, "a");
        char title[200]; inner_text(h + te + 1, ce - te - 1, title, sizeof title);
        pos = ce;
        // URL de destino
        char url[PG_URLLEN];
        const char* u = find_str(href, slen(href), 0, "uddg=");
        if (u) { u += 5; int ul = 0; while (u[ul] && u[ul] != '&') ul++; url_decode(u, ul, url, sizeof url); }
        else if (href[0] == '/' && href[1] == '/') { scpy(url, "https:", sizeof url); int k = 6; for (int i = 0; href[i] && k < PG_URLLEN - 1; i++) url[k++] = href[i]; url[k] = 0; }
        else scpy(url, href, sizeof url);
        if (find_str(url, slen(url), 0, "duckduckgo.com/y.js") || find_str(url, slen(url), 0, "ad_provider")) continue;   // anuncios
        // trecho de descricao: ate o proximo resultado
        int nx = n; const char* nm = find_str(h, n, pos, "result__a"); if (nm) nx = (int)(nm - h);
        char snip[600]; snip[0] = 0;
        const char* sm = find_str(h, nx, pos, "result__snippet");
        if (sm) { int si = (int)(sm - h); while (si > 0 && h[si] != '<') si--; int ste = tag_end(h, n, si); int sce = find_close(h, n, ste + 1, "a"); inner_text(h + ste + 1, sce - ste - 1, snip, sizeof snip); }
        int li = -1;
        if (p->nlinks < PG_LINKS) { scpy(p->links[p->nlinks], url, PG_URLLEN); li = p->nlinks++; }
        count++;
        char num[8]; { int v = count, k = 0; char t[4]; while (v) { t[k++] = (char)('0' + v % 10); v /= 10; } int o = 0; while (k) num[o++] = t[--k]; num[o++] = '.'; num[o++] = ' '; num[o] = 0; }
        char first[260]; scpy(first, num, sizeof first); { int k = slen(first); for (int i = 0; title[i] && k < (int)sizeof(first) - 1; i++) first[k++] = title[i]; first[k] = 0; }
        add_wrapped(p, "", first, li);
        { char shown[PG_COLS]; scpy(shown, "   ", sizeof shown); int k = 3; const char* us = url; if (starts_ci(us, "https://")) us += 8; else if (starts_ci(us, "http://")) us += 7; for (int i = 0; us[i] && k < PG_COLS - 4; i++) shown[k++] = us[i]; shown[k] = 0; page_add_line(p, shown, li); }
        if (snip[0]) add_wrapped(p, "   ", snip, -1);
        page_add_line(p, "", -1);
    }
    if (count == 0) {
        if (find_str(h, n, 0, "anomaly") || find_str(h, n, 0, "challenge") || find_str(h, n, 0, "captcha"))
            page_add_line(p, "O DuckDuckGo pediu uma verificacao anti-robo. Tente de novo em instantes.", -1);
        else if (find_str(h, n, 0, "No  results") || find_str(h, n, 0, "No results") || find_str(h, n, 0, "no-results"))
            page_add_line(p, "Nenhum resultado para essa busca.", -1);
        else page_add_line(p, "Nao consegui ler os resultados (o formato da pagina pode ter mudado).", -1);
    } else page_add_line(p, "Clique num resultado para abrir a pagina.", -1);
}

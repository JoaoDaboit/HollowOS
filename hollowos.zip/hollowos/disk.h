// disk.h - HollowOS: driver de disco ATA (PIO, LBA28) - disco mestre do canal primario (QEMU: -drive if=ide)
#pragma once
#include "net.h"

bool disk_init();                                          // procura o disco; retorna true se achou
u32  disk_sectors();                                       // tamanho em setores de 512 bytes
bool disk_read(u32 lba, u32 count, void* buf);             // count <= 255
bool disk_write(u32 lba, u32 count, const void* buf);

// vfs.h - HollowOS: sistema de arquivos "HFS" (arvore de diretorios em RAM, com gravacao em disco ATA)
//
// Tudo fica na memoria (3 MB de dados, 255 arquivos/pastas, nomes de ate 27 letras). Se houver um disco ATA
// (QEMU: -drive file=hollow.img,format=raw,if=ide), o conteudo e carregado no boot e gravado de volta com
// vfs_sync() / automaticamente depois de alguns segundos sem mudancas.
#pragma once
#include "net.h"

#define VFS_NAME   28
#define VFS_NINO   256
#define VFS_BLK    4096
#define VFS_NBLK   768            // 3 MB de dados
#define VFS_ROOT   0

enum { VT_FREE = 0, VT_FILE = 1, VT_DIR = 2 };
// erros (valores de errno do Linux, negativos)
enum { VE_NOENT = -2, VE_IO = -5, VE_EXIST = -17, VE_NOTDIR = -20, VE_ISDIR = -21, VE_INVAL = -22, VE_NOSPC = -28,
       VE_NAMETOOLONG = -36, VE_NOTEMPTY = -39, VE_FBIG = -27, VE_MFILE = -24 };

void vfs_init();                                    // formata a RAM (so raiz); chame uma vez
bool vfs_mount_disk();                              // true se achou um HFS valido no disco e carregou
bool vfs_format_disk();                             // grava um HFS novo no disco (apaga tudo la)
bool vfs_disk_ok();                                 // ha disco usavel?
void vfs_sync();                                    // grava mudancas no disco (se houver disco)
void vfs_autosync(u32 now_ms);                      // chame no laco principal
extern u32 (*vfs_clock)();                          // hora unix (segundos) para mtime; pode ser 0

int  vfs_resolve(const char* path, int cwd);                        // inode ou erro
int  vfs_parent_of(const char* path, int cwd, char* leaf);          // inode do diretorio pai (e o nome final em leaf) ou erro
int  vfs_create(int dir, const char* name, int type);               // cria arquivo/pasta; erro VE_EXIST se existir
int  vfs_lookup(int dir, const char* name);                         // filho de dir
int  vfs_unlink(int ino);                                           // remove arquivo ou pasta vazia
int  vfs_rename(int ino, int newdir, const char* newname);
int  vfs_read(int ino, u32 off, void* buf, u32 n);                  // bytes lidos (0 = fim)
int  vfs_write(int ino, u32 off, const void* buf, u32 n);           // bytes escritos ou erro
int  vfs_truncate(int ino, u32 size);
int  vfs_type(int ino);
u32  vfs_size(int ino);
u32  vfs_mtime(int ino);
const char* vfs_name(int ino);
int  vfs_parent(int ino);
int  vfs_nth_child(int dir, int n);                                 // n-esimo filho (0..) ou -1
int  vfs_path(int ino, char* out, int max);                         // caminho absoluto
int  vfs_copy(int src, int dstdir, const char* name);               // copia arquivo
void vfs_stats(u32* files, u32* dirs, u32* used_blocks, u32* total_blocks);

// ajudas
int  vfs_write_file(const char* path, const void* data, u32 n);     // cria pastas pai se faltarem; sobrescreve
int  vfs_append_file(const char* path, const void* data, u32 n);

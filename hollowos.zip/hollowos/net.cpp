// net.cpp - HollowOS: driver Intel e1000 + ARP, IPv4, ICMP, UDP, DHCP, DNS, TCP minimo e HTTP/1.0
// Sem interrupcoes: tudo e feito por polling em net_poll(). O kernel e identity-mapped,
// entao o endereco de um buffer estatico ja e o endereco fisico usado pelo DMA da placa.
#include "net.h"

extern "C" { void* memcpy(void*, const void*, usize); void* memset(void*, int, usize); }

NetInfo net;
void (*net_idle)() = 0;          // chamado nos laços de espera (o kernel usa para manter a tela viva)
volatile bool net_cancel = false;  // o kernel liga para abortar uma operacao de rede bloqueante

// ---------------- I/O ----------------
static inline void outb(u16 p, u8 v)  { asm volatile("outb %0,%1" :: "a"(v), "Nd"(p)); }
static inline u8   inb(u16 p)         { u8 r; asm volatile("inb %1,%0" : "=a"(r) : "Nd"(p)); return r; }
static inline void outl(u16 p, u32 v) { asm volatile("outl %0,%1" :: "a"(v), "Nd"(p)); }
static inline u32  inl(u16 p)         { u32 r; asm volatile("inl %1,%0" : "=a"(r) : "Nd"(p)); return r; }

static u32 pci_read(u8 b, u8 d, u8 f, u8 o) {
    outl(0xCF8, 0x80000000u | ((u32)b << 16) | ((u32)d << 11) | ((u32)f << 8) | (o & 0xFC));
    return inl(0xCFC);
}
static void pci_write(u8 b, u8 d, u8 f, u8 o, u32 v) {
    outl(0xCF8, 0x80000000u | ((u32)b << 16) | ((u32)d << 11) | ((u32)f << 8) | (o & 0xFC));
    outl(0xCFC, v);
}

static inline u16 bs(u16 v) { return (u16)((v >> 8) | (v << 8)); }
static inline u32 bl(u32 v) { return (v >> 24) | ((v >> 8) & 0xFF00) | ((v << 8) & 0xFF0000) | (v << 24); }
static bool same(const void* a, const void* b, int n) {
    const u8* x = (const u8*)a; const u8* y = (const u8*)b;
    for (int i = 0; i < n; i++) if (x[i] != y[i]) return false;
    return true;
}
static int slen(const char* s) { int n = 0; while (s[n]) n++; return n; }

// ---------------- relogio (PIT canal 0, so leitura) ----------------
static u32 t_ms = 0, t_frac = 0;
static u16 t_last = 0;
static u16 pit_read() { outb(0x43, 0x00); u8 lo = inb(0x40); u8 hi = inb(0x40); return (u16)(lo | (hi << 8)); }
u32 net_ms() {
    u16 c = pit_read();
    u16 el = (u16)(t_last - c);          // o contador desce; modulo 65536
    t_last = c;
    t_frac += el;
    t_ms += t_frac / 1193;               // 1193182 Hz ~ 1193 ticks por ms
    t_frac %= 1193;
    return t_ms;
}

// ---------------- e1000 ----------------
struct __attribute__((packed)) RxD { u32 lo, hi; u16 len, csum; u8 status, err; u16 special; };
struct __attribute__((packed)) TxD { u32 lo, hi; u16 len; u8 cso, cmd, status, css; u16 special; };
#define NRX 32
#define NTX 8
static RxD rxd[NRX] __attribute__((aligned(128)));
static TxD txd[NTX] __attribute__((aligned(128)));
static u8  rxb[NRX][2048] __attribute__((aligned(16)));
static u8  txb[NTX][2048] __attribute__((aligned(16)));
static volatile u32* mmio = 0;
static int rx_cur = 0, tx_tail = 0;
static u32 rd(u32 r)          { return mmio[r / 4]; }
static void wr(u32 r, u32 v)  { mmio[r / 4] = v; }

static bool e1000_init() {
    static const u16 ids[] = { 0x100E, 0x100F, 0x1004, 0x1008, 0x1009, 0x100C, 0x100D, 0x1019, 0x101E };
    int fb = -1, fd = -1;
    for (int bb = 0; bb < 4 && fb < 0; bb++)
        for (int dd = 0; dd < 32 && fb < 0; dd++) {
            u32 id = pci_read((u8)bb, (u8)dd, 0, 0);
            if ((id & 0xFFFF) != 0x8086) continue;
            for (unsigned k = 0; k < sizeof(ids) / sizeof(ids[0]); k++)
                if ((id >> 16) == ids[k]) { fb = bb; fd = dd; break; }
        }
    if (fb < 0) return false;
    u8 bus = (u8)fb, dev = (u8)fd;
    u32 bar = pci_read(bus, dev, 0, 0x10) & 0xFFFFFFF0u;
    if (!bar) return false;
    mmio = (volatile u32*)bar;
    pci_write(bus, dev, 0, 4, pci_read(bus, dev, 0, 4) | 0x7);   // IO + memoria + bus master

    wr(0xD8, 0xFFFFFFFFu);                                       // sem interrupcoes
    wr(0x100, 0);
    wr(0x400, 0);
    wr(0x0, rd(0x0) | (1u << 26));                               // reset
    for (int i = 0; i < 1000000 && (rd(0x0) & (1u << 26)); i++) {}
    wr(0xD8, 0xFFFFFFFFu);
    rd(0xC0);
    u32 ctrl = rd(0x0);
    ctrl |= (1u << 6) | (1u << 5);                               // SLU | ASDE
    ctrl &= ~((1u << 3) | (1u << 7) | (1u << 31));               // LRST, ILOS, PHY_RST
    wr(0x0, ctrl);

    u32 ral = rd(0x5400), rah = rd(0x5404);
    if (ral == 0 && (rah & 0xFFFF) == 0) {                       // le da EEPROM
        u16 w[3];
        for (int i = 0; i < 3; i++) {
            wr(0x14, 1u | ((u32)i << 8));
            u32 v = 0;
            for (int t = 0; t < 100000; t++) { v = rd(0x14); if (v & 0x10) break; }
            w[i] = (u16)(v >> 16);
        }
        ral = (u32)w[0] | ((u32)w[1] << 16); rah = w[2];
    }
    for (int i = 0; i < 4; i++) net.mac[i] = (u8)(ral >> (8 * i));
    net.mac[4] = (u8)rah; net.mac[5] = (u8)(rah >> 8);
    wr(0x5400, ral);
    wr(0x5404, (rah & 0xFFFF) | (1u << 31));
    for (int i = 0; i < 128; i++) wr(0x5200 + i * 4, 0);        // tabela multicast

    memset(rxd, 0, sizeof(rxd));
    for (int i = 0; i < NRX; i++) { rxd[i].lo = (u32)(usize)&rxb[i][0]; rxd[i].hi = 0; }
    wr(0x2800, (u32)(usize)rxd); wr(0x2804, 0);
    wr(0x2808, NRX * 16);
    wr(0x2810, 0); wr(0x2818, NRX - 1);
    rx_cur = 0;
    wr(0x100, (1u << 1) | (1u << 15) | (1u << 26));              // EN | BAM | SECRC, buffers de 2048

    memset(txd, 0, sizeof(txd));
    for (int i = 0; i < NTX; i++) { txd[i].lo = (u32)(usize)&txb[i][0]; txd[i].status = 1; }
    wr(0x3800, (u32)(usize)txd); wr(0x3804, 0);
    wr(0x3808, NTX * 16);
    wr(0x3810, 0); wr(0x3818, 0);
    tx_tail = 0;
    wr(0x400, (1u << 1) | (1u << 3) | (0x0Fu << 4) | (0x40u << 12));
    wr(0x410, 0x0060200Au);
    net.link = (rd(0x8) & 2) != 0;
    return true;
}

static void eth_send(const u8* f, int len) {
    if (!mmio) return;
    int i = tx_tail;
    volatile TxD* d = &txd[i];
    for (int t = 0; t < 1000000 && !(d->status & 1); t++) {}
    if (len < 60) { memcpy(txb[i], f, len); memset(txb[i] + len, 0, 60 - len); len = 60; }
    else memcpy(txb[i], f, len);
    d->len = (u16)len; d->cso = 0; d->css = 0; d->special = 0;
    d->status = 0;
    d->cmd = 0x0B;                                               // EOP | IFCS | RS
    tx_tail = (i + 1) % NTX;
    wr(0x3818, tx_tail);
    net.tx_packets++;
}

// ---------------- checksum ----------------
static u32 sum16(const void* d, int n, u32 s) {
    const u8* p = (const u8*)d;
    while (n > 1) { s += (u32)(p[0] | (p[1] << 8)); p += 2; n -= 2; }
    if (n) s += p[0];
    return s;
}
static u16 fold(u32 s) { while (s >> 16) s = (s & 0xFFFF) + (s >> 16); return (u16)~s; }

// ---------------- cabecalhos ----------------
struct __attribute__((packed)) IpH { u8 vihl, tos; u16 len, id, frag; u8 ttl, proto; u16 csum; u8 src[4], dst[4]; };

static bool in_rx = false;
static u16  ip_id = 1;

static void rx_poll();

// ---------------- ARP ----------------
struct ArpE { u8 ip[4]; u8 mac[6]; bool ok; };
static ArpE arpc[8];
static int  arp_next = 0;

static void arp_learn(const u8* ip, const u8* mac) {
    for (int i = 0; i < 8; i++)
        if (arpc[i].ok && same(arpc[i].ip, ip, 4)) { memcpy(arpc[i].mac, mac, 6); return; }
    ArpE& e = arpc[arp_next]; arp_next = (arp_next + 1) % 8;
    memcpy(e.ip, ip, 4); memcpy(e.mac, mac, 6); e.ok = true;
}
static bool arp_lookup(const u8* ip, u8* mac) {
    for (int i = 0; i < 8; i++)
        if (arpc[i].ok && same(arpc[i].ip, ip, 4)) { memcpy(mac, arpc[i].mac, 6); return true; }
    return false;
}
static void arp_send(u16 op, const u8* tmac, const u8* tip) {
    u8 f[60]; memset(f, 0, sizeof f);
    if (op == 1) memset(f, 0xFF, 6); else memcpy(f, tmac, 6);
    memcpy(f + 6, net.mac, 6);
    f[12] = 0x08; f[13] = 0x06;
    u8* a = f + 14;
    a[0] = 0; a[1] = 1; a[2] = 8; a[3] = 0; a[4] = 6; a[5] = 4;
    a[6] = (u8)(op >> 8); a[7] = (u8)op;
    memcpy(a + 8, net.mac, 6); memcpy(a + 14, net.ip, 4);
    if (op == 2) memcpy(a + 18, tmac, 6);
    memcpy(a + 24, tip, 4);
    eth_send(f, 42);
}
static void arp_rx(const u8* a, int len) {
    if (len < 28) return;
    u16 op = (u16)((a[6] << 8) | a[7]);
    arp_learn(a + 14, a + 8);
    if (op == 1 && net.has_ip && same(a + 24, net.ip, 4)) arp_send(2, a + 8, a + 14);
}
static bool arp_resolve(const u8* ip, u8* mac) {
    if (arp_lookup(ip, mac)) return true;
    if (in_rx) return false;                                    // nunca bloqueia dentro do recebimento
    for (int tries = 0; tries < 4; tries++) {
        arp_send(1, 0, ip);
        u32 t0 = net_ms();
        while (net_ms() - t0 < 500) {
            rx_poll();
            if (arp_lookup(ip, mac)) return true;
        }
    }
    return false;
}

// ---------------- IPv4 ----------------
static bool ip_send_mac(const u8* src, const u8* dst, u8 proto, const u8* pl, int plen, const u8* mac) {
    if (plen > 1480) return false;
    u8 f[14 + 20 + 1480];
    memcpy(f, mac, 6); memcpy(f + 6, net.mac, 6); f[12] = 0x08; f[13] = 0x00;
    IpH* h = (IpH*)(f + 14);
    h->vihl = 0x45; h->tos = 0; h->len = bs((u16)(20 + plen));
    h->id = bs(ip_id++); h->frag = bs(0x4000); h->ttl = 64; h->proto = proto; h->csum = 0;
    memcpy(h->src, src, 4); memcpy(h->dst, dst, 4);
    h->csum = fold(sum16(h, 20, 0));
    memcpy(f + 34, pl, plen);
    eth_send(f, 34 + plen);
    return true;
}
static bool is_bcast(const u8* ip) { return ip[0] == 255 && ip[1] == 255 && ip[2] == 255 && ip[3] == 255; }
static bool ip_send(const u8* dst, u8 proto, const u8* pl, int plen) {
    u8 mac[6];
    if (is_bcast(dst)) memset(mac, 0xFF, 6);
    else {
        const u8* nh = dst;
        bool local = true;
        for (int i = 0; i < 4; i++) if ((dst[i] ^ net.ip[i]) & net.mask[i]) local = false;
        if (!local) nh = net.gw;
        if (!arp_resolve(nh, mac)) return false;
    }
    return ip_send_mac(net.ip, dst, proto, pl, plen, mac);
}

// ---------------- ICMP ----------------
static volatile bool ping_got = false;
static u16 ping_seq = 0;
static u32 ping_t0 = 0, ping_rtt = 0;

static void icmp_rx(const u8* src, const u8* d, int len) {
    if (len < 8) return;
    if (d[0] == 8) {                                            // echo request -> reply
        u8 r[1480]; if (len > 1480) return;
        memcpy(r, d, len); r[0] = 0; r[2] = 0; r[3] = 0;
        u16 c = fold(sum16(r, len, 0)); r[2] = (u8)c; r[3] = (u8)(c >> 8);
        ip_send(src, 1, r, len);
    } else if (d[0] == 0) {
        u16 id = (u16)((d[4] << 8) | d[5]), sq = (u16)((d[6] << 8) | d[7]);
        if (id == 0x4857 && sq == ping_seq) { ping_rtt = net_ms() - ping_t0; ping_got = true; }
    }
}
int net_ping(const u8* ip, int timeout_ms) {
    if (!net.has_ip) return -1;
    u8 p[40]; memset(p, 0, sizeof p);
    p[0] = 8; p[4] = 0x48; p[5] = 0x57; ping_seq++; p[6] = (u8)(ping_seq >> 8); p[7] = (u8)ping_seq;
    for (int i = 8; i < 40; i++) p[i] = (u8)i;
    u16 c = fold(sum16(p, 40, 0)); p[2] = (u8)c; p[3] = (u8)(c >> 8);
    ping_got = false; ping_t0 = net_ms();
    if (!ip_send(ip, 1, p, 40)) return -1;
    u32 t0 = net_ms();
    while ((int)(net_ms() - t0) < timeout_ms) { rx_poll(); if (ping_got) return (int)ping_rtt; }
    return -1;
}

// ---------------- UDP ----------------
static bool udp_build_send(const u8* src, const u8* dst, u16 sp, u16 dp, const u8* data, int len,
                           const u8* mac_or_null) {
    u8 p[1480]; if (len > 1472) return false;
    p[0] = (u8)(sp >> 8); p[1] = (u8)sp; p[2] = (u8)(dp >> 8); p[3] = (u8)dp;
    u16 l = (u16)(8 + len); p[4] = (u8)(l >> 8); p[5] = (u8)l; p[6] = 0; p[7] = 0;   // checksum 0 = opcional
    memcpy(p + 8, data, len);
    if (mac_or_null) return ip_send_mac(src, dst, 17, p, l, mac_or_null);
    return ip_send(dst, 17, p, l);
}

// ---------------- DHCP ----------------
static int  dhcp_state = 0;                // 0 parado, 1 discover enviado, 2 request enviado, 3 ok
static u32  dhcp_xid = 0x484F4C4Cu;
static u32  dhcp_t = 0;
static u8   d_offer[4], d_server[4], d_mask[4], d_gw[4], d_dns[4];

static void dhcp_send(u8 type) {
    u8 p[300]; memset(p, 0, sizeof p);
    p[0] = 1; p[1] = 1; p[2] = 6;
    p[4] = (u8)(dhcp_xid >> 24); p[5] = (u8)(dhcp_xid >> 16); p[6] = (u8)(dhcp_xid >> 8); p[7] = (u8)dhcp_xid;
    p[10] = 0x80;                                               // flag broadcast
    memcpy(p + 28, net.mac, 6);
    p[236] = 99; p[237] = 130; p[238] = 83; p[239] = 99;
    int o = 240;
    p[o++] = 53; p[o++] = 1; p[o++] = type;
    if (type == 3) {
        p[o++] = 50; p[o++] = 4; memcpy(p + o, d_offer, 4);  o += 4;
        p[o++] = 54; p[o++] = 4; memcpy(p + o, d_server, 4); o += 4;
    }
    p[o++] = 55; p[o++] = 3; p[o++] = 1; p[o++] = 3; p[o++] = 6;
    p[o++] = 255;
    static const u8 zero[4] = {0, 0, 0, 0}, bc[4] = {255, 255, 255, 255}, mb[6] = {255, 255, 255, 255, 255, 255};
    udp_build_send(zero, bc, 68, 67, p, 300, mb);
    dhcp_t = net_ms();
}
static void dhcp_rx(const u8* p, int len) {
    if (len < 241 || p[0] != 2) return;
    u32 xid = ((u32)p[4] << 24) | ((u32)p[5] << 16) | ((u32)p[6] << 8) | p[7];
    if (xid != dhcp_xid || !same(p + 28, net.mac, 6)) return;
    u8 type = 0;
    for (int i = 240; i < len;) {
        u8 c = p[i];
        if (c == 255) break;
        if (c == 0) { i++; continue; }
        if (i + 1 >= len) break;
        u8 l = p[i + 1]; const u8* v = p + i + 2;
        if (i + 2 + l > len) break;
        if (c == 53 && l >= 1) type = v[0];
        else if (c == 54 && l >= 4) memcpy(d_server, v, 4);
        else if (c == 1  && l >= 4) memcpy(d_mask, v, 4);
        else if (c == 3  && l >= 4) memcpy(d_gw, v, 4);
        else if (c == 6  && l >= 4) memcpy(d_dns, v, 4);
        i += 2 + l;
    }
    if (type == 2 && dhcp_state == 1) {
        memcpy(d_offer, p + 16, 4);
        dhcp_state = 2; dhcp_send(3);
    } else if (type == 5 && dhcp_state == 2) {
        memcpy(net.ip, p + 16, 4); memcpy(net.mask, d_mask, 4);
        memcpy(net.gw, d_gw, 4);   memcpy(net.dns, d_dns, 4);
        net.has_ip = true; dhcp_state = 3;
    }
}
void net_dhcp_restart() {
    memset(net.ip, 0, 4); net.has_ip = false;
    dhcp_xid++; dhcp_state = 1;
    dhcp_send(1);
}

// ---------------- DNS ----------------
static u8  dns_buf[512];
static int dns_len = 0;
static volatile bool dns_got = false;
static u16 dns_id = 0x2000;
struct DnsC { char name[48]; u8 ip[4]; bool ok; };
static DnsC dnsc[4]; static int dns_cn = 0;

static bool parse_ip(const char* s, u8* out) {
    int part = 0, val = 0, digits = 0;
    for (const char* p = s;; p++) {
        if (*p >= '0' && *p <= '9') { val = val * 10 + (*p - '0'); digits++; if (val > 255) return false; }
        else if (*p == '.' || *p == 0) {
            if (!digits || part > 3) return false;
            out[part++] = (u8)val; val = 0; digits = 0;
            if (*p == 0) break;
        } else return false;
    }
    return part == 4;
}
bool net_resolve(const char* name, u8* out) {
    if (parse_ip(name, out)) return true;
    if (!net.has_ip) return false;
    int nl = slen(name);
    if (nl >= 48) return false;
    for (int i = 0; i < 4; i++) {
        if (!dnsc[i].ok) continue;
        int j = 0; while (name[j] && dnsc[i].name[j] == name[j]) j++;
        if (!name[j] && !dnsc[i].name[j]) { memcpy(out, dnsc[i].ip, 4); return true; }
    }
    u8 q[300]; int o = 12; memset(q, 0, 12);
    dns_id++;
    q[0] = (u8)(dns_id >> 8); q[1] = (u8)dns_id; q[2] = 0x01; q[3] = 0x00; q[5] = 1;
    const char* p = name;
    while (*p) {
        const char* e = p; while (*e && *e != '.') e++;
        int l = (int)(e - p); if (l == 0 || l > 63 || o + l + 6 > 290) return false;
        q[o++] = (u8)l; memcpy(q + o, p, l); o += l;
        p = *e ? e + 1 : e;
    }
    q[o++] = 0; q[o++] = 0; q[o++] = 1; q[o++] = 0; q[o++] = 1;
    for (int attempt = 0; attempt < 3; attempt++) {
        dns_got = false;
        udp_build_send(net.ip, net.dns, 53001, 53, q, o, 0);
        u32 t0 = net_ms();
        while (net_ms() - t0 < 1000) {
            rx_poll();
            if (!dns_got) continue;
            const u8* r = dns_buf; int n = dns_len;
            if (n < 12 || r[0] != q[0] || r[1] != q[1] || (r[3] & 0x0F) != 0) { dns_got = false; continue; }
            int an = (r[6] << 8) | r[7], i = 12;
            // pula a pergunta
            while (i < n && r[i]) i += (r[i] & 0xC0) == 0xC0 ? 2 : r[i] + 1;
            i += 5;
            for (int a = 0; a < an && i < n; a++) {
                while (i < n && r[i]) { if ((r[i] & 0xC0) == 0xC0) { i++; break; } i += r[i] + 1; }
                i += 1;                                                  // zero final ou 2o byte do ponteiro
                if (i + 10 > n) break;
                int type = (r[i] << 8) | r[i + 1], rl = (r[i + 8] << 8) | r[i + 9];
                i += 10;
                if (type == 1 && rl == 4 && i + 4 <= n) {
                    memcpy(out, r + i, 4);
                    DnsC& c = dnsc[dns_cn]; dns_cn = (dns_cn + 1) % 4;
                    for (int k = 0; k <= nl; k++) c.name[k] = name[k];
                    memcpy(c.ip, out, 4); c.ok = true;
                    return true;
                }
                i += rl;
            }
            return false;                                                // resposta sem registro A
        }
    }
    return false;
}

// ---------------- UDP de usuario (1 soquete, para programas Linux) ----------------
struct UDg { u8 ip[4]; u16 port; u16 len; u8 data[1472]; };
static UDg uq[4];
static int uq_head = 0, uq_cnt = 0;
static bool u_on = false;
static u16 u_port = 0, u_next = 40000;

static void udp_rx(const u8* src, const u8* d, int len) {
    if (len < 8) return;
    u16 dp = (u16)((d[2] << 8) | d[3]);
    int pl = len - 8;
    if (dp == 68) dhcp_rx(d + 8, pl);
    else if (dp == 53001 && pl <= 512) { memcpy(dns_buf, d + 8, pl); dns_len = pl; dns_got = true; }
    else if (u_on && dp == u_port && uq_cnt < 4 && pl <= 1472) {
        UDg& g = uq[(uq_head + uq_cnt) % 4]; uq_cnt++;
        memcpy(g.ip, src, 4); g.port = (u16)((d[0] << 8) | d[1]); g.len = (u16)pl; memcpy(g.data, d + 8, pl);
    }
}
bool udp_open(u16 port) {
    if (u_on) return false;
    u_port = port ? port : u_next++; if (u_next > 45000) u_next = 40000;
    u_on = true; uq_head = uq_cnt = 0;
    return true;
}
void udp_close() { u_on = false; uq_cnt = 0; }
u16  udp_local_port() { return u_port; }
bool udp_send(const u8* ip, u16 port, const u8* data, int len) {
    if (!u_on || !net.has_ip || len > 1472) return false;
    return udp_build_send(net.ip, ip, u_port, port, data, len, 0);
}
int udp_avail() { rx_poll(); return uq_cnt; }
int udp_recv(u8* buf, int max, u8* src_ip, u16* src_port, int timeout_ms) {
    u32 t0 = net_ms();
    for (;;) {
        rx_poll();
        if (uq_cnt > 0) {
            UDg& g = uq[uq_head]; uq_head = (uq_head + 1) % 4; uq_cnt--;
            int n = g.len < max ? g.len : max;
            memcpy(buf, g.data, n);
            if (src_ip) memcpy(src_ip, g.ip, 4);
            if (src_port) *src_port = g.port;
            return n;
        }
        if ((int)(net_ms() - t0) >= timeout_ms) return -1;
        if (net_idle) net_idle();
        if (net_cancel) return -1;
    }
}

// ---------------- TCP (uma conexao) ----------------
struct __attribute__((packed)) TcpH { u16 sp, dp; u32 seq, ack; u8 off, fl; u16 win, csum, urg; };
enum { T_CLOSED = 0, T_SYN, T_EST, T_FINWAIT };
static struct { int st; u8 rip[4]; u16 lp, rp; u32 snd_nxt, snd_una, rcv_nxt; bool fin_rx, rst; } tc;
static u8  trx[16384];
static int tr_head = 0, tr_cnt = 0;
static u16 next_port = 49152;

static void tcp_seg(u32 seq, u8 fl, const u8* data, int len, bool mss) {
    u8 b[1480]; if (len > 1400) return;
    TcpH* h = (TcpH*)b;
    h->sp = bs(tc.lp); h->dp = bs(tc.rp); h->seq = bl(seq); h->ack = bl(tc.rcv_nxt);
    int hl = mss ? 24 : 20;
    h->off = (u8)((hl / 4) << 4); h->fl = fl;
    int free_sp = (int)sizeof(trx) - tr_cnt; if (free_sp > 0xFFFF) free_sp = 0xFFFF;
    h->win = bs((u16)free_sp); h->csum = 0; h->urg = 0;
    if (mss) { b[20] = 2; b[21] = 4; b[22] = 0x05; b[23] = 0xB4; }
    memcpy(b + hl, data, len);
    int tot = hl + len;
    u8 ph[12]; memcpy(ph, net.ip, 4); memcpy(ph + 4, tc.rip, 4);
    ph[8] = 0; ph[9] = 6; ph[10] = (u8)(tot >> 8); ph[11] = (u8)tot;
    h->csum = fold(sum16(b, tot, sum16(ph, 12, 0)));
    ip_send(tc.rip, 6, b, tot);
}
static void tcp_rx(const u8* src, const u8* d, int len) {
    if (tc.st == T_CLOSED || len < 20) return;
    const TcpH* h = (const TcpH*)d;
    if (!same(src, tc.rip, 4) || bs(h->dp) != tc.lp || bs(h->sp) != tc.rp) return;
    u32 seq = bl(h->seq), ack = bl(h->ack);
    u8 fl = h->fl;
    int hl = (h->off >> 4) * 4; if (hl < 20 || hl > len) return;
    int plen = len - hl;
    if (fl & 4) { tc.st = T_CLOSED; tc.rst = true; return; }
    if (tc.st == T_SYN) {
        if ((fl & 0x12) == 0x12 && ack == tc.snd_nxt) {
            tc.snd_una = ack; tc.rcv_nxt = seq + 1; tc.st = T_EST;
            tcp_seg(tc.snd_nxt, 0x10, 0, 0, false);
        }
        return;
    }
    if (fl & 0x10) { if ((int)(ack - tc.snd_una) > 0 && (int)(tc.snd_nxt - ack) >= 0) tc.snd_una = ack; }
    if (plen > 0) {
        if (seq == tc.rcv_nxt) {
            int space = (int)sizeof(trx) - tr_cnt;
            int n = plen < space ? plen : space;
            for (int i = 0; i < n; i++) trx[(tr_head + tr_cnt + i) % sizeof(trx)] = d[hl + i];
            tr_cnt += n; tc.rcv_nxt += n;
        }
        tcp_seg(tc.snd_nxt, 0x10, 0, 0, false);                          // ACK (tambem serve de dup-ACK)
    }
    if ((fl & 1) && seq + plen == tc.rcv_nxt && !tc.fin_rx) {
        tc.fin_rx = true; tc.rcv_nxt++;
        tcp_seg(tc.snd_nxt, 0x10, 0, 0, false);
    }
}
bool tcp_connect(const u8* ip, u16 port, int timeout_ms) {
    if (!net.has_ip) return false;
    memset(&tc, 0, sizeof tc);
    memcpy(tc.rip, ip, 4); tc.rp = port; tc.lp = next_port++; if (next_port > 60000) next_port = 49152;
    tr_head = 0; tr_cnt = 0;
    u32 iss = net_ms() * 64000u + 0x1234u;
    tc.snd_una = iss; tc.snd_nxt = iss + 1; tc.st = T_SYN;
    int tries = timeout_ms / 1000; if (tries < 1) tries = 1;
    for (int a = 0; a < tries; a++) {
        tcp_seg(iss, 0x02, 0, 0, true);
        u32 t0 = net_ms();
        while (net_ms() - t0 < 1000) {
            rx_poll();
            if (tc.st == T_EST) return true;
            if (tc.st == T_CLOSED) return false;
            if (net_idle) net_idle();
            if (net_cancel) { tc.st = T_CLOSED; return false; }
        }
    }
    tc.st = T_CLOSED;
    return false;
}
int tcp_send(const u8* data, int len) {
    int sent = 0;
    while (sent < len) {
        int n = len - sent; if (n > 1400) n = 1400;
        u32 seq = tc.snd_nxt;
        tc.snd_nxt += n;
        bool acked = false;
        for (int tries = 0; tries < 8 && !acked; tries++) {
            if (tc.st != T_EST) return -1;
            tcp_seg(seq, 0x18, data + sent, n, false);
            u32 t0 = net_ms();
            while (net_ms() - t0 < 400) {
                rx_poll();
                if ((int)(tc.snd_una - (seq + n)) >= 0) { acked = true; break; }
                if (tc.st != T_EST) return -1;
                if (net_idle) net_idle();
                if (net_cancel) return -1;
            }
        }
        if (!acked) return -1;
        sent += n;
    }
    return sent;
}
int tcp_recv(u8* buf, int max, int timeout_ms) {
    u32 t0 = net_ms();
    for (;;) {
        rx_poll();
        if (tr_cnt > 0) {
            int was_free = (int)sizeof(trx) - tr_cnt;
            int n = tr_cnt < max ? tr_cnt : max;
            for (int i = 0; i < n; i++) buf[i] = trx[(tr_head + i) % sizeof(trx)];
            tr_head = (tr_head + n) % sizeof(trx); tr_cnt -= n;
            if (was_free < 4096 && tc.st == T_EST) tcp_seg(tc.snd_nxt, 0x10, 0, 0, false);   // abre a janela
            return n;
        }
        if (tc.fin_rx || tc.st == T_CLOSED) return 0;
        if ((int)(net_ms() - t0) >= timeout_ms) return -1;
        if (net_idle) net_idle();
        if (net_cancel) return -1;
    }
}
int tcp_avail() {
    rx_poll();
    if (tr_cnt > 0) return tr_cnt;
    if (tc.fin_rx || tc.st == T_CLOSED) return -1;
    return 0;
}
bool tcp_alive() { return tc.st == T_EST || tr_cnt > 0; }
void tcp_close() {
    if (tc.st == T_EST) {
        tcp_seg(tc.snd_nxt, 0x11, 0, 0, false);
        tc.snd_nxt++;
        u32 t0 = net_ms();
        while (net_ms() - t0 < 300) rx_poll();
    }
    tc.st = T_CLOSED;
}

// ---------------- HTTP ----------------
static void cat(char* d, int& n, int max, const char* s) { while (*s && n < max - 1) d[n++] = *s++; d[n] = 0; }
int http_get(const char* host, u16 port, const char* path, char* out, int maxlen, int timeout_ms) {
    u8 ip[4];
    if (!net_resolve(host, ip)) return -1;
    if (!tcp_connect(ip, port, 3000)) return -2;
    char req[700]; int n = 0; req[0] = 0;
    cat(req, n, sizeof req, "GET "); cat(req, n, sizeof req, path);
    cat(req, n, sizeof req, " HTTP/1.0\r\nHost: "); cat(req, n, sizeof req, host);
    cat(req, n, sizeof req, "\r\nUser-Agent: HollowOS/0.3\r\nConnection: close\r\n\r\n");
    if (tcp_send((const u8*)req, n) < 0) { tcp_close(); return -3; }
    int total = 0;
    while (total < maxlen) {
        int r = tcp_recv((u8*)out + total, maxlen - total, timeout_ms);
        if (r <= 0) break;
        total += r;
    }
    tcp_close();
    return total;
}

// ---------------- recepcao ----------------
static void ip_rx(const u8* p, int len) {
    if (len < 20) return;
    const IpH* h = (const IpH*)p;
    if ((h->vihl >> 4) != 4) return;
    int hl = (h->vihl & 15) * 4, tl = bs(h->len);
    if (hl < 20 || tl > len || tl < hl) return;
    if (net.has_ip && !same(h->dst, net.ip, 4) && !is_bcast(h->dst)) return;
    if ((h->frag & bs(0x3FFF)) != 0) return;                     // sem fragmentos
    const u8* d = p + hl; int dl = tl - hl;
    if (h->proto == 1) icmp_rx(h->src, d, dl);
    else if (h->proto == 17) udp_rx(h->src, d, dl);
    else if (h->proto == 6) tcp_rx(h->src, d, dl);
}
static void rx_poll() {
    if (!mmio || in_rx) return;
    static u8 frame[2048];
    for (;;) {
        volatile RxD* d = &rxd[rx_cur];
        if (!(d->status & 1)) break;
        int len = d->len; if (len > 2048) len = 2048;
        if (d->err == 0 && len >= 14) {
            memcpy(frame, rxb[rx_cur], len);
            net.rx_packets++;
            in_rx = true;
            u16 type = (u16)((frame[12] << 8) | frame[13]);
            if (type == 0x0806) arp_rx(frame + 14, len - 14);
            else if (type == 0x0800) ip_rx(frame + 14, len - 14);
            in_rx = false;
        }
        d->status = 0;
        wr(0x2818, rx_cur);
        rx_cur = (rx_cur + 1) % NRX;
    }
}

// ---------------- API publica ----------------
bool net_init() {
    memset(&net, 0, sizeof net);
    outb(0x43, 0x34); outb(0x40, 0); outb(0x40, 0);              // PIT: contador livre de 16 bits
    t_last = pit_read(); t_ms = 0; t_frac = 0;
    if (!e1000_init()) return false;
    net.present = true;
    net_dhcp_restart();
    return true;
}
void net_poll() {
    net_ms();
    if (!net.present) return;
    net.link = (rd(0x8) & 2) != 0;
    rx_poll();
    if (!net.has_ip && dhcp_state != 0 && net_ms() - dhcp_t > 3000) { dhcp_state = 1; dhcp_send(1); }
}
void net_ip_str(const u8* ip, char* out) {
    int n = 0;
    for (int i = 0; i < 4; i++) {
        int v = ip[i];
        if (v >= 100) out[n++] = (char)('0' + v / 100);
        if (v >= 10)  out[n++] = (char)('0' + (v / 10) % 10);
        out[n++] = (char)('0' + v % 10);
        if (i < 3) out[n++] = '.';
    }
    out[n] = 0;
}
void net_mac_str(const u8* mac, char* out) {
    static const char hx[] = "0123456789abcdef";
    int n = 0;
    for (int i = 0; i < 6; i++) { out[n++] = hx[mac[i] >> 4]; out[n++] = hx[mac[i] & 15]; if (i < 5) out[n++] = ':'; }
    out[n] = 0;
}

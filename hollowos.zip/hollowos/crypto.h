// crypto.h - HollowOS: criptografia minima para o TLS 1.2 (SHA-256, HMAC, AES-128-GCM, X25519, RNG)
#pragma once
#include "net.h"      // u8, u16, u32, usize

struct Sha256 { u32 h[8]; u8 buf[64]; u32 blen; u32 total_lo, total_hi; };
void sha256_init(Sha256* c);
void sha256_update(Sha256* c, const void* d, u32 n);
void sha256_final(Sha256* c, u8 out[32]);          // nao altera c (trabalha numa copia)
void sha256(const void* d, u32 n, u8 out[32]);

void hmac_sha256(const u8* key, u32 klen, const u8* msg, u32 mlen, u8 out[32]);
// PRF do TLS 1.2: P_SHA256(secret, label + seed)
void tls_prf(const u8* secret, u32 slen, const char* label, const u8* seed, u32 seedlen, u8* out, u32 outlen);

struct Aes128 { u8 rk[176]; };
void aes128_init(Aes128* a, const u8 key[16]);
void aes128_encrypt(const Aes128* a, const u8 in[16], u8 out[16]);

struct Gcm { Aes128 aes; u8 H[16]; };
void gcm_init(Gcm* g, const u8 key[16]);
// cifra len bytes e escreve o tag (16 bytes) em tag
void gcm_encrypt(const Gcm* g, const u8 iv[12], const u8* aad, u32 aadlen,
                 const u8* in, u32 len, u8* out, u8 tag[16]);
// decifra e confere o tag; retorna false se o tag nao bate (out fica inutilizavel)
bool gcm_decrypt(const Gcm* g, const u8 iv[12], const u8* aad, u32 aadlen,
                 const u8* in, u32 len, u8* out, const u8 tag[16]);

void x25519(u8 out[32], const u8 scalar[32], const u8 point[32]);
void x25519_base(u8 out[32], const u8 scalar[32]);

// Aleatorio (DRBG baseado em SHA-256). rng_add_entropy pode ser chamado com qualquer coisa imprevisivel
// (tempo entre teclas, rdtsc, MAC...). Quanto mais entropia, melhor.
void rng_add_entropy(const void* d, u32 n);
void rng_add_u32(u32 v);
void rng_bytes(u8* out, u32 n);

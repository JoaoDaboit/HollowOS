import http.server, ssl, sys, threading
class H(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def log_message(self, *a): pass
    def send(self, code, body, extra=()):
        self.send_response(code); self.send_header("Content-Length", str(len(body)))
        for k, v in extra: self.send_header(k, v)
        self.send_header("Connection", "close"); self.end_headers(); self.wfile.write(body); self.close_connection = True
    def do_GET(self):
        if self.path == "/hello": self.send(200, b"ola mundo", [("Content-Type", "text/plain")])
        elif self.path == "/redir": self.send(302, b"", [("Location", "/redir2")])
        elif self.path == "/redir2": self.send(301, b"", [("Location", "chunked")])   # relativo
        elif self.path == "/chunked":
            self.send_response(200); self.send_header("Transfer-Encoding", "chunked"); self.send_header("Connection", "close"); self.end_headers()
            for part in (b"chunk-um ", b"chunk-dois"): self.wfile.write(b"%x\r\n" % len(part) + part + b"\r\n")
            self.wfile.write(b"0\r\n\r\n"); self.close_connection = True
        elif self.path == "/semlen":
            self.send_response(200); self.send_header("Connection", "close"); self.end_headers(); self.wfile.write(b"ate fechar"); self.close_connection = True
        else: self.send(404, b"nao achei")
    def do_POST(self):
        n = int(self.headers["Content-Length"]); b = self.rfile.read(n); self.send(200, b"POST:" + b)
kind, port = sys.argv[1], int(sys.argv[2])
s = http.server.ThreadingHTTPServer(("127.0.0.1", port), H)
if kind == "tls":
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER); ctx.minimum_version = ssl.TLSVersion.TLSv1_2; ctx.maximum_version = ssl.TLSVersion.TLSv1_2
    ctx.load_cert_chain("/tmp/rsa.crt", "/tmp/rsa.key"); ctx.set_ciphers("ECDHE-RSA-AES128-GCM-SHA256"); ctx.set_ecdh_curve("X25519")
    s.socket = ctx.wrap_socket(s.socket, server_side=True)
print("pronto", flush=True); s.serve_forever()

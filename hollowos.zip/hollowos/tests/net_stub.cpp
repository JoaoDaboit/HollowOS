#include "../net.h"
u32 net_ms() { return 0; }
bool tcp_connect(const u8*, u16, int) { return false; }
int tcp_send(const u8*, int) { return -1; }
int tcp_recv(u8*, int, int) { return -1; }
void tcp_close() {}
bool net_resolve(const char*, u8*) { return false; }

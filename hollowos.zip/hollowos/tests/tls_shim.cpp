// Shim para testar tls.cpp no PC: implementa tcp_* e net_ms com sockets reais.
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <poll.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include "../tls.h"
static int fd = -1;
u32 net_ms() { timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return (u32)(t.tv_sec * 1000 + t.tv_nsec / 1000000); }
bool tcp_connect(const u8* ip, u16 port, int) {
    fd = socket(AF_INET, SOCK_STREAM, 0); sockaddr_in a{}; a.sin_family = AF_INET; a.sin_port = htons(port); memcpy(&a.sin_addr, ip, 4);
    return connect(fd, (sockaddr*)&a, sizeof a) == 0;
}
int tcp_send(const u8* d, int n) { int s = 0; while (s < n) { int r = write(fd, d + s, n - s); if (r <= 0) return -1; s += r; } return n; }
int tcp_recv(u8* b, int max, int to) {
    pollfd p{fd, POLLIN, 0}; int r = poll(&p, 1, to); if (r <= 0) return -1;
    int n = read(fd, b, max); return n < 0 ? -1 : n;
}
void tcp_close() { if (fd >= 0) close(fd); fd = -1; }
int main(int argc, char** argv) {
    u16 port = (u16)atoi(argv[1]); u8 ip[4] = {127,0,0,1};
    int big = argc > 2 ? atoi(argv[2]) : 0;
    unsigned char seedb[8] = {1,2,3,4,5,6,7,8};
    extern void rng_add_entropy(const void*, u32); rng_add_entropy(seedb, 8); FILE* f = fopen("/dev/urandom", "rb"); u8 r[32]; fread(r, 1, 32, f); fclose(f); rng_add_entropy(r, 32);
    if (!tls_connect("localhost", ip, port, 10000)) { printf("FALHA: %s\n", tls_error()); return 1; }
    char req[200]; snprintf(req, sizeof req, "GET /%s HTTP/1.0\r\nHost: localhost\r\n\r\n", big ? "big" : "");
    tls_send((u8*)req, strlen(req));
    static u8 buf[4000000]; int tot = 0;
    for (;;) { int n = tls_recv(buf + tot, sizeof buf - tot, 5000); if (n <= 0) break; tot += n; }
    printf("recebidos=%d\n", tot);
    // procura corpo
    int off = 0; for (int i = 0; i + 3 < tot; i++) if (!memcmp(buf + i, "\r\n\r\n", 4)) { off = i + 4; break; }
    unsigned h = 2166136261u; for (int i = off; i < tot; i++) { h ^= buf[i]; h *= 16777619u; }
    printf("corpo=%d hash=%u\n", tot - off, h);
    tls_send((u8*)"x", 1); tls_close();
    return 0;
}

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "../vfs.h"
#include "../disk.h"
static unsigned char* img; static unsigned nsec = 40 + 768*8 + 8;
bool disk_init() { return true; } u32 disk_sectors() { return nsec; }
bool disk_read(u32 l, u32 c, void* b) { memcpy(b, img + l*512, c*512); return true; }
bool disk_write(u32 l, u32 c, const void* b) { memcpy(img + l*512, b, c*512); return true; }
#define CHECK(x) do { if (!(x)) { printf("FALHOU linha %d: %s\n", __LINE__, #x); fails++; } } while (0)
int main() {
  int fails = 0; img = (unsigned char*)calloc(nsec, 512);
  vfs_init(); CHECK(vfs_format_disk());
  int d = vfs_create(0, "home", VT_DIR); CHECK(d > 0);
  CHECK(vfs_create(0, "home", VT_DIR) == VE_EXIST);
  int f = vfs_create(d, "a.txt", VT_FILE); CHECK(f > 0);
  CHECK(vfs_resolve("/home/a.txt", 0) == f); CHECK(vfs_resolve("a.txt", d) == f); CHECK(vfs_resolve("../home/./a.txt", d) == f);
  CHECK(vfs_resolve("/nada", 0) == VE_NOENT); CHECK(vfs_resolve("/home/a.txt/x", 0) == VE_NOTDIR);
  static unsigned char big[200000], back[200000]; for (int i = 0; i < 200000; i++) big[i] = (unsigned char)(i * 13 + i / 7);
  CHECK(vfs_write(f, 0, big, 200000) == 200000); CHECK(vfs_size(f) == 200000);
  CHECK(vfs_read(f, 0, back, 200000) == 200000 && !memcmp(big, back, 200000));
  CHECK(vfs_read(f, 5000, back, 100) == 100 && !memcmp(big + 5000, back, 100));
  CHECK(vfs_read(f, 199990, back, 100) == 10);
  CHECK(vfs_write(f, 4090, "XXXXXXXXXXXX", 12) == 12); vfs_read(f, 4090, back, 12); CHECK(!memcmp(back, "XXXXXXXXXXXX", 12));
  CHECK(vfs_truncate(f, 10) == 0 && vfs_size(f) == 10);
  CHECK(vfs_truncate(f, 9000) == 0); vfs_read(f, 0, back, 9000); CHECK(back[10] == 0 && back[8999] == 0 && back[0] == big[0]);
  int g = vfs_copy(f, 0, "copia"); CHECK(g > 0 && vfs_size(g) == 9000);
  CHECK(vfs_rename(g, d, "movido") == 0 && vfs_resolve("/home/movido", 0) == g);
  CHECK(vfs_rename(d, d, "x") == VE_INVAL);
  CHECK(vfs_unlink(d) == VE_NOTEMPTY);
  char leaf[40]; int p = vfs_parent_of("/home/novo.txt", 0, leaf); CHECK(p == d && !strcmp(leaf, "novo.txt"));
  char path[100]; vfs_path(g, path, 100); CHECK(!strcmp(path, "/home/movido"));
  CHECK(vfs_write_file("/etc/net/resolv.conf", "nameserver 1.1.1.1\n", 19) > 0);
  CHECK(vfs_append_file("/etc/net/resolv.conf", "x\n", 2) > 0 && vfs_size(vfs_resolve("/etc/net/resolv.conf", 0)) == 21);
  // enche o disco
  int h = vfs_create(0, "enorme", VT_FILE); int tot = 0, r; static unsigned char chunk[65536];
  while ((r = vfs_write(h, tot, chunk, 65536)) > 0) tot += r; CHECK(r == VE_NOSPC || r == 0 || tot >= 2000000);
  vfs_unlink(h); u32 fl, dr, us, to; vfs_stats(&fl, &dr, &us, &to); CHECK(us < 100);
  vfs_sync();
  // remonta do "disco"
  vfs_init(); CHECK(vfs_resolve("/home/a.txt", 0) < 0); CHECK(vfs_mount_disk());
  int f2 = vfs_resolve("/home/a.txt", 0); CHECK(f2 > 0 && vfs_size(f2) == 9000);
  vfs_read(f2, 0, back, 9000); CHECK(back[0] == big[0] && back[9] == big[9] && back[10] == 0);
  CHECK(vfs_resolve("/home/movido", 0) > 0);
  printf(fails ? "%d falhas\n" : "VFS OK\n", fails); return fails != 0;
}

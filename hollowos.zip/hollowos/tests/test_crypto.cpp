// Gera saidas do crypto.cpp para comparar com o Python (tests/check_crypto.py)
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "../crypto.h"
static void hex(const char* name, const u8* d, int n) { printf("%s=", name); for (int i = 0; i < n; i++) printf("%02x", d[i]); printf("\n"); }
int main() {
    // SHA-256 de varios tamanhos (cobre as bordas de padding)
    static u8 data[5000]; for (int i = 0; i < 5000; i++) data[i] = (u8)(i * 7 + 3);
    int lens[] = {0,1,3,55,56,57,63,64,65,119,120,121,128,1000,4999};
    for (unsigned k = 0; k < sizeof lens / sizeof lens[0]; k++) { u8 o[32]; sha256(data, lens[k], o); char n[32]; sprintf(n, "sha%d", lens[k]); hex(n, o, 32); }
    // incremental
    { Sha256 c; sha256_init(&c); for (int i = 0; i < 1000; i += 7) sha256_update(&c, data + i, (1000 - i) < 7 ? (1000 - i) : 7); u8 o[32]; sha256_final(&c, o); hex("shainc1000", o, 32); }
    // HMAC
    { u8 key[100]; for (int i = 0; i < 100; i++) key[i] = (u8)i; u8 o[32];
      hmac_sha256(key, 20, data, 77, o); hex("hmac20", o, 32);
      hmac_sha256(key, 100, data, 300, o); hex("hmac100", o, 32); }
    // PRF
    { u8 sec[48]; for (int i = 0; i < 48; i++) sec[i] = (u8)(i + 1); u8 seed[64]; for (int i = 0; i < 64; i++) seed[i] = (u8)(255 - i); u8 o[100];
      tls_prf(sec, 48, "key expansion", seed, 64, o, 100); hex("prf100", o, 100);
      tls_prf(sec, 32, "client finished", seed, 32, o, 12); hex("prf12", o, 12); }
    // AES-128 FIPS-197
    { u8 key[16], pt[16], ct[16]; for (int i = 0; i < 16; i++) { key[i] = (u8)i; pt[i] = (u8)(i * 0x11); }
      Aes128 a; aes128_init(&a, key); aes128_encrypt(&a, pt, ct); hex("aes", ct, 16); }
    // GCM varios tamanhos
    { u8 key[16], iv[12]; for (int i = 0; i < 16; i++) key[i] = (u8)(i * 3 + 1); for (int i = 0; i < 12; i++) iv[i] = (u8)(i + 9);
      Gcm g; gcm_init(&g, key);
      int pl[] = {0, 1, 15, 16, 17, 100, 1500}; int al[] = {0, 13, 20, 13, 0, 29, 13};
      for (int k = 0; k < 7; k++) {
        static u8 out[2000], back[2000]; u8 tag[16];
        gcm_encrypt(&g, iv, data + 100, al[k], data, pl[k], out, tag);
        char n[32]; sprintf(n, "gcmct%d", k); hex(n, out, pl[k]); sprintf(n, "gcmtag%d", k); hex(n, tag, 16);
        bool ok = gcm_decrypt(&g, iv, data + 100, al[k], out, pl[k], back, tag);
        printf("gcmdec%d=%d%d\n", k, ok, ok && memcmp(back, data, pl[k]) == 0);
        tag[3] ^= 1; printf("gcmbad%d=%d\n", k, gcm_decrypt(&g, iv, data + 100, al[k], out, pl[k], back, tag));
      } }
    // X25519
    { u8 sk[32], pk[32], o[32]; for (int i = 0; i < 32; i++) { sk[i] = (u8)(i * 5 + 11); pk[i] = (u8)(i * 9 + 2); }
      x25519(o, sk, pk); hex("x25519", o, 32);
      x25519_base(o, sk); hex("x25519base", o, 32);
      // vetor RFC 7748
      u8 a[32] = {0xa5,0x46,0xe3,0x6b,0xf0,0x52,0x7c,0x9d,0x3b,0x16,0x15,0x4b,0x82,0x46,0x5e,0xdd,0x62,0x14,0x4c,0x0a,0xc1,0xfc,0x5a,0x18,0x50,0x6a,0x22,0x44,0xba,0x44,0x9a,0xc4};
      u8 b[32] = {0xe6,0xdb,0x68,0x67,0x58,0x30,0x30,0xdb,0x35,0x94,0xc1,0xa4,0x24,0xb1,0x5f,0x7c,0x72,0x66,0x24,0xec,0x26,0xb3,0x35,0x3b,0x10,0xa9,0x03,0xa6,0xd0,0xab,0x1c,0x4c};
      x25519(o, a, b); hex("x25519rfc", o, 32); }
    // RNG: saidas diferentes
    { u8 r1[32], r2[32]; rng_add_u32(1234); rng_bytes(r1, 32); rng_bytes(r2, 32); printf("rngdiff=%d\n", memcmp(r1, r2, 32) != 0); }
    return 0;
}

import ssl, socket, sys, threading, hashlib
kind = sys.argv[1]; port = int(sys.argv[2])
ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
ctx.minimum_version = ssl.TLSVersion.TLSv1_2; ctx.maximum_version = ssl.TLSVersion.TLSv1_2
ctx.load_cert_chain(f"/tmp/{kind}.crt", f"/tmp/{kind}.key")
ctx.set_ciphers("ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES128-GCM-SHA256")
ctx.set_ecdh_curve("X25519")
BIG = bytes((i*31+7)&255 for i in range(1500000))
s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1); s.bind(("127.0.0.1", port)); s.listen(5)
print("pronto", flush=True)
while True:
    c, _ = s.accept()
    try:
        t = ctx.wrap_socket(c, server_side=True)
        req = t.recv(4096)
        body = BIG if b"GET /big" in req else b"ola do servidor TLS\n"
        t.sendall(b"HTTP/1.0 200 OK\r\nContent-Length: %d\r\n\r\n" % len(body) + body)
        try: t.recv(10)
        except Exception: pass
        t.close()
        print("cipher", t.cipher() if False else "ok", flush=True)
    except Exception as e:
        print("erro servidor:", e, flush=True)

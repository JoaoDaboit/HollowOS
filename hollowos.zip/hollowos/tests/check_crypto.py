import subprocess, hashlib, hmac, sys
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey
out = subprocess.run(["./tests/test_crypto"], capture_output=True, text=True).stdout
res = dict(l.split("=",1) for l in out.strip().split("\n"))
data = bytes((i*7+3)&255 for i in range(5000))
bad = 0
def chk(name, exp):
    global bad
    got = res.get(name)
    ok = got == exp
    if not ok: bad += 1; print("FALHOU", name, "\n  got", got, "\n  exp", exp)
for n in [0,1,3,55,56,57,63,64,65,119,120,121,128,1000,4999]:
    chk(f"sha{n}", hashlib.sha256(data[:n]).hexdigest())
chk("shainc1000", hashlib.sha256(data[:1000]).hexdigest())
key = bytes(range(100))
chk("hmac20", hmac.new(key[:20], data[:77], hashlib.sha256).hexdigest())
chk("hmac100", hmac.new(key, data[:300], hashlib.sha256).hexdigest())
def prf(sec, label, seed, n):
    ls = label.encode()+seed; a = ls; o = b""
    a = hmac.new(sec, ls, hashlib.sha256).digest()
    while len(o) < n:
        o += hmac.new(sec, a+ls, hashlib.sha256).digest()
        a = hmac.new(sec, a, hashlib.sha256).digest()
    return o[:n]
sec = bytes(i+1 for i in range(48)); seed = bytes(255-i for i in range(64))
chk("prf100", prf(sec,"key expansion",seed,100).hex())
chk("prf12", prf(sec[:32],"client finished",seed[:32],12).hex())
k = bytes(range(16)); pt = bytes(i*0x11 for i in range(16))
e = Cipher(algorithms.AES(k), modes.ECB()).encryptor()
chk("aes", (e.update(pt)+e.finalize()).hex())
gk = bytes((i*3+1)&255 for i in range(16)); iv = bytes(i+9 for i in range(12))
pl = [0,1,15,16,17,100,1500]; al = [0,13,20,13,0,29,13]
for i,(p,a) in enumerate(zip(pl,al)):
    ct = AESGCM(gk).encrypt(iv, data[:p], data[100:100+a])
    chk(f"gcmct{i}", ct[:-16].hex()); chk(f"gcmtag{i}", ct[-16:].hex())
    chk(f"gcmdec{i}", "11"); chk(f"gcmbad{i}", "0")
sk = bytes((i*5+11)&255 for i in range(32)); pk = bytes((i*9+2)&255 for i in range(32))
chk("x25519", X25519PrivateKey.from_private_bytes(sk).exchange(X25519PublicKey.from_public_bytes(pk)).hex())
chk("x25519base", X25519PrivateKey.from_private_bytes(sk).public_key().public_bytes_raw().hex())
chk("x25519rfc", "c3da55379de9c6908e94ea4df28d084f32eccf03491c71f754b4075577a28552")
chk("rngdiff", "1")
print("TUDO OK" if not bad else f"{bad} falhas")
sys.exit(1 if bad else 0)

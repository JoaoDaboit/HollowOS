#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <poll.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include "../web.h"
static int fd = -1;
u32 net_ms() { timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return (u32)(t.tv_sec * 1000 + t.tv_nsec / 1000000); }
bool net_resolve(const char*, u8* ip) { ip[0] = 127; ip[1] = 0; ip[2] = 0; ip[3] = 1; return true; }
bool tcp_connect(const u8* ip, u16 port, int) { fd = socket(AF_INET, SOCK_STREAM, 0); sockaddr_in a{}; a.sin_family = AF_INET; a.sin_port = htons(port); memcpy(&a.sin_addr, ip, 4); return connect(fd, (sockaddr*)&a, sizeof a) == 0; }
int tcp_send(const u8* d, int n) { int s = 0; while (s < n) { int r = write(fd, d + s, n - s); if (r <= 0) return -1; s += r; } return n; }
int tcp_recv(u8* b, int max, int to) { pollfd p{fd, POLLIN, 0}; int r = poll(&p, 1, to); if (r <= 0) return -1; int n = read(fd, b, max); return n < 0 ? -1 : n; }
void tcp_close() { if (fd >= 0) close(fd); fd = -1; }
static char out[100000]; static int olen;
static bool sink(const u8* d, int n, void*) { memcpy(out + olen, d, n); olen += n; return true; }
int main(int argc, char** argv) {
  FILE* f = fopen("/dev/urandom", "rb"); u8 r[32]; fread(r, 1, 32, f); fclose(f); extern void rng_add_entropy(const void*, u32); rng_add_entropy(r, 32);
  const char* base = argv[1]; int fails = 0;
  char url[200]; WebResult w;
  #define T(cond, msg) do { if (!(cond)) { printf("FALHOU: %s (status=%d err=%s out='%.60s')\n", msg, w.status, w.error ? w.error : "-", out); fails++; } } while (0)
  olen = 0; memset(out, 0, sizeof out); snprintf(url, sizeof url, "%s/hello", base);
  T(web_request("GET", url, 0, sink, 0, &w, 8000) && w.status == 200 && !strcmp(out, "ola mundo"), "GET simples");
  olen = 0; memset(out, 0, sizeof out); snprintf(url, sizeof url, "%s/redir", base);
  T(web_request("GET", url, 0, sink, 0, &w, 8000) && w.status == 200 && w.redirects == 2 && strstr(out, "chunk-um chunk-dois"), "redirect + chunked");
  olen = 0; memset(out, 0, sizeof out); snprintf(url, sizeof url, "%s/echo", base);
  T(web_request("POST", url, "q=linux+kernel&kl=wt-wt", sink, 0, &w, 8000) && w.status == 200 && !strcmp(out, "POST:q=linux+kernel&kl=wt-wt"), "POST");
  olen = 0; memset(out, 0, sizeof out); snprintf(url, sizeof url, "%s/semlen", base);
  T(web_request("GET", url, 0, sink, 0, &w, 8000) && w.status == 200 && !strcmp(out, "ate fechar"), "corpo ate fechar");
  olen = 0; snprintf(url, sizeof url, "%s/nada", base);
  T(web_request("GET", url, 0, sink, 0, &w, 8000) && w.status == 404, "404");
  printf(fails ? "%d falhas\n" : "WEB OK\n", fails); return fails != 0;
}

#include <stdio.h>
#include <string.h>
#include "../html.h"
static TextPage P;
static void dump(const char* t) { printf("--- %s (linhas=%d links=%d titulo='%s')\n", t, P.nlines, P.nlinks, P.title);
  for (int i = 0; i < P.nlines; i++) printf("%3d %c|%s\n", i, P.link_of[i] >= 0 ? '@' : ' ', P.lines[i]);
  for (int i = 0; i < P.nlinks; i++) printf("  link[%d]=%s\n", i, P.links[i]); }
int main() {
  const char* ddg =
   "<html><body><div class=\"results\">"
   "<div class=\"result results_links results_links_deep web-result \"><div class=\"links_main links_deep result__body\">"
   "<h2 class=\"result__title\"><a rel=\"nofollow\" class=\"result__a\" href=\"//duckduckgo.com/l/?uddg=https%3A%2F%2Fpt.wikipedia.org%2Fwiki%2FLinux&amp;rut=abc\">Linux &ndash; Wikip&eacute;dia, a enciclop&eacute;dia livre</a></h2>"
   "<div class=\"result__extras\"><a class=\"result__url\" href=\"//duckduckgo.com/l/?uddg=https%3A%2F%2Fpt.wikipedia.org%2Fwiki%2FLinux\">pt.wikipedia.org/wiki/Linux</a></div>"
   "<a class=\"result__snippet\" href=\"//duckduckgo.com/l/?uddg=x\">Linux &eacute; um <b>kernel</b> de sistema operacional criado por Linus Torvalds em 1991. O nome tamb&#233;m designa distribui&#xE7;&otilde;es inteiras.</a></div></div>"
   "<div class=\"result result--ad\"><h2><a class=\"result__a\" href=\"//duckduckgo.com/y.js?ad_provider=bingv7aa&u3=x\">Anuncio</a></h2><a class=\"result__snippet\">ad</a></div>"
   "<div class=\"result\"><h2><a class=\"result__a\" href=\"https://kernel.org/\">The Linux Kernel Archives</a></h2><a class=\"result__snippet\" href=\"x\">Kernel.org hospeda o c\xc3\xb3digo-fonte. \xe2\x80\x9cCitacao\xe2\x80\x9d \xe2\x80\x94 fim.</a></div>"
   "</div></body></html>";
  page_from_ddg(&P, ddg, strlen(ddg), "o que \xc3\xa9 linux?"); dump("ddg");
  const char* gen = "<html><head><title>Minha P\xc3\xa1gina</title><style>body{color:red}</style><script>alert('x<b>')</script></head><body><h1>Ol\xc3\xa1 mundo</h1><p>Texto <a href=\"/sobre/index.html\">com link</a> e <a href='../x/y'>outro</a> &amp; &copy; fim.</p><ul><li>um</li><li>dois <b>negrito</b></li></ul><!-- coment --><pre>linha1\n  linha2</pre><p>Uma linha muito longa que precisa ser quebrada em varias linhas porque excede a largura maxima da pagina do navegador do HollowOS ok</p></body></html>";
  Url b; url_parse("https://exemplo.com/a/b/c.html?x=1", &b);
  page_from_html(&P, gen, strlen(gen), &b); dump("generico");
  char out[200]; Url u; 
  url_parse("exemplo.com:8080/p?q=1", &u); url_string(u, out, sizeof out); printf("url: %s https=%d port=%d\n", out, u.https, u.port);
  const char* refs[] = {"/z", "z.html", "../up.html", "./a/./b/../c", "//cdn.x.com/f.js", "?pagina=2", "https://outro.org/a"};
  for (auto r : refs) { url_resolve(b, r, out, sizeof out); printf("resolve %-18s -> %s\n", r, out); }
  url_encode("busca com acentos & simbolos=1", out, sizeof out); printf("enc: %s\n", out);
  char dec[100]; url_decode("a%20b%2Fc+d%C3%A9", 17, dec, sizeof dec); printf("dec: %s\n", dec);
  return 0;
}

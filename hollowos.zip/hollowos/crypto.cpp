// crypto.cpp - HollowOS: SHA-256, HMAC, PRF do TLS 1.2, AES-128-GCM, X25519 e gerador aleatorio.
// Codigo simples e portavel (sem tabelas gigantes, sem SSE). Nao e resistente a ataques de tempo
// de cache; serve para um SO de estudo. Testado contra vetores conhecidos (veja tests/).
#include "crypto.h"

static inline void cpy(void* d, const void* s, u32 n) { u8* a = (u8*)d; const u8* b = (const u8*)s; while (n--) *a++ = *b++; }
static inline void zer(void* d, u32 n) { u8* a = (u8*)d; while (n--) *a++ = 0; }
static inline u32 ror(u32 x, int n) { return (x >> n) | (x << (32 - n)); }

// ============================================================ SHA-256
static const u32 K256[64] = {
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2 };

void sha256_init(Sha256* c) {
    static const u32 iv[8] = { 0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19 };
    for (int i = 0; i < 8; i++) c->h[i] = iv[i];
    c->blen = 0; c->total_lo = c->total_hi = 0;
}
static void sha256_block(Sha256* c, const u8* p) {
    u32 w[64];
    for (int i = 0; i < 16; i++) w[i] = ((u32)p[4*i] << 24) | ((u32)p[4*i+1] << 16) | ((u32)p[4*i+2] << 8) | p[4*i+3];
    for (int i = 16; i < 64; i++) {
        u32 s0 = ror(w[i-15], 7) ^ ror(w[i-15], 18) ^ (w[i-15] >> 3);
        u32 s1 = ror(w[i-2], 17) ^ ror(w[i-2], 19) ^ (w[i-2] >> 10);
        w[i] = w[i-16] + s0 + w[i-7] + s1;
    }
    u32 a = c->h[0], b = c->h[1], cc = c->h[2], d = c->h[3], e = c->h[4], f = c->h[5], g = c->h[6], h = c->h[7];
    for (int i = 0; i < 64; i++) {
        u32 S1 = ror(e, 6) ^ ror(e, 11) ^ ror(e, 25);
        u32 ch = (e & f) ^ (~e & g);
        u32 t1 = h + S1 + ch + K256[i] + w[i];
        u32 S0 = ror(a, 2) ^ ror(a, 13) ^ ror(a, 22);
        u32 mj = (a & b) ^ (a & cc) ^ (b & cc);
        u32 t2 = S0 + mj;
        h = g; g = f; f = e; e = d + t1; d = cc; cc = b; b = a; a = t1 + t2;
    }
    c->h[0] += a; c->h[1] += b; c->h[2] += cc; c->h[3] += d; c->h[4] += e; c->h[5] += f; c->h[6] += g; c->h[7] += h;
}
void sha256_update(Sha256* c, const void* d, u32 n) {
    const u8* p = (const u8*)d;
    u32 old = c->total_lo; c->total_lo += n; if (c->total_lo < old) c->total_hi++;
    while (n) {
        if (c->blen == 0 && n >= 64) { sha256_block(c, p); p += 64; n -= 64; continue; }
        u32 k = 64 - c->blen; if (k > n) k = n;
        cpy(c->buf + c->blen, p, k); c->blen += k; p += k; n -= k;
        if (c->blen == 64) { sha256_block(c, c->buf); c->blen = 0; }
    }
}
void sha256_final(Sha256* src, u8 out[32]) {
    Sha256 c = *src;
    u32 lo = c.total_lo, hi = c.total_hi;
    u8 pad[72]; u32 padlen = (c.blen < 56) ? (56 - c.blen) : (120 - c.blen);
    zer(pad, sizeof pad); pad[0] = 0x80;
    u32 bits_hi = (hi << 3) | (lo >> 29), bits_lo = lo << 3;
    sha256_update(&c, pad, padlen);
    u8 len[8] = { (u8)(bits_hi >> 24), (u8)(bits_hi >> 16), (u8)(bits_hi >> 8), (u8)bits_hi,
                  (u8)(bits_lo >> 24), (u8)(bits_lo >> 16), (u8)(bits_lo >> 8), (u8)bits_lo };
    sha256_update(&c, len, 8);
    for (int i = 0; i < 8; i++) { out[4*i] = (u8)(c.h[i] >> 24); out[4*i+1] = (u8)(c.h[i] >> 16); out[4*i+2] = (u8)(c.h[i] >> 8); out[4*i+3] = (u8)c.h[i]; }
}
void sha256(const void* d, u32 n, u8 out[32]) { Sha256 c; sha256_init(&c); sha256_update(&c, d, n); sha256_final(&c, out); }

// ============================================================ HMAC e PRF
void hmac_sha256(const u8* key, u32 klen, const u8* msg, u32 mlen, u8 out[32]) {
    u8 k[64]; zer(k, 64);
    if (klen > 64) sha256(key, klen, k); else cpy(k, key, klen);
    u8 ip[64], op[64];
    for (int i = 0; i < 64; i++) { ip[i] = k[i] ^ 0x36; op[i] = k[i] ^ 0x5c; }
    Sha256 c; u8 inner[32];
    sha256_init(&c); sha256_update(&c, ip, 64); sha256_update(&c, msg, mlen); sha256_final(&c, inner);
    sha256_init(&c); sha256_update(&c, op, 64); sha256_update(&c, inner, 32); sha256_final(&c, out);
}
void tls_prf(const u8* secret, u32 slen, const char* label, const u8* seed, u32 seedlen, u8* out, u32 outlen) {
    u8 ls[128]; u32 ll = 0;
    while (label[ll]) { ls[ll] = (u8)label[ll]; ll++; }
    cpy(ls + ll, seed, seedlen); u32 lsl = ll + seedlen;           // label + seed (<= 128)
    u8 a[32]; hmac_sha256(secret, slen, ls, lsl, a);              // A(1)
    u32 done = 0;
    while (done < outlen) {
        u8 buf[32 + 128]; cpy(buf, a, 32); cpy(buf + 32, ls, lsl);
        u8 o[32]; hmac_sha256(secret, slen, buf, 32 + lsl, o);
        u32 k = outlen - done; if (k > 32) k = 32;
        cpy(out + done, o, k); done += k;
        hmac_sha256(secret, slen, a, 32, a);                      // A(i+1)
    }
}

// ============================================================ AES-128
static u8 SBOX[256];
static bool sbox_ready = false;
static inline u8 rotl8(u8 x, int s) { return (u8)((x << s) | (x >> (8 - s))); }
static void make_sbox() {
    u8 p = 1, q = 1;
    do {
        p = (u8)(p ^ (p << 1) ^ ((p & 0x80) ? 0x1B : 0));
        q ^= (u8)(q << 1); q ^= (u8)(q << 2); q ^= (u8)(q << 4);
        if (q & 0x80) q ^= 0x09;
        u8 x = (u8)(q ^ rotl8(q, 1) ^ rotl8(q, 2) ^ rotl8(q, 3) ^ rotl8(q, 4));
        SBOX[p] = (u8)(x ^ 0x63);
    } while (p != 1);
    SBOX[0] = 0x63;
    sbox_ready = true;
}
static inline u8 xt(u8 x) { return (u8)((x << 1) ^ ((x & 0x80) ? 0x1B : 0)); }

void aes128_init(Aes128* a, const u8 key[16]) {
    if (!sbox_ready) make_sbox();
    cpy(a->rk, key, 16);
    u8 rc = 1;
    for (int i = 16; i < 176; i += 4) {
        u8 t[4]; cpy(t, a->rk + i - 4, 4);
        if ((i & 15) == 0) {
            u8 t0 = t[0]; t[0] = (u8)(SBOX[t[1]] ^ rc); t[1] = SBOX[t[2]]; t[2] = SBOX[t[3]]; t[3] = SBOX[t0];
            rc = xt(rc);
        }
        for (int k = 0; k < 4; k++) a->rk[i + k] = (u8)(a->rk[i - 16 + k] ^ t[k]);
    }
}
void aes128_encrypt(const Aes128* a, const u8 in[16], u8 out[16]) {
    u8 s[16];
    for (int i = 0; i < 16; i++) s[i] = (u8)(in[i] ^ a->rk[i]);
    for (int r = 1; r <= 10; r++) {
        u8 t[16];
        for (int i = 0; i < 16; i++) t[i] = SBOX[s[i]];
        // ShiftRows (estado em ordem de coluna: indice = 4*col + linha)
        u8 u[16];
        for (int c = 0; c < 4; c++) for (int rw = 0; rw < 4; rw++) u[4*c + rw] = t[4*((c + rw) & 3) + rw];
        if (r < 10) {
            for (int c = 0; c < 4; c++) {
                u8 a0 = u[4*c], a1 = u[4*c+1], a2 = u[4*c+2], a3 = u[4*c+3];
                s[4*c]   = (u8)(xt(a0) ^ (xt(a1) ^ a1) ^ a2 ^ a3);
                s[4*c+1] = (u8)(a0 ^ xt(a1) ^ (xt(a2) ^ a2) ^ a3);
                s[4*c+2] = (u8)(a0 ^ a1 ^ xt(a2) ^ (xt(a3) ^ a3));
                s[4*c+3] = (u8)((xt(a0) ^ a0) ^ a1 ^ a2 ^ xt(a3));
            }
        } else cpy(s, u, 16);
        for (int i = 0; i < 16; i++) s[i] ^= a->rk[16 * r + i];
    }
    cpy(out, s, 16);
}

// ============================================================ GCM
static inline u32 ld32(const u8* p) { return ((u32)p[0] << 24) | ((u32)p[1] << 16) | ((u32)p[2] << 8) | p[3]; }
static inline void st32(u8* p, u32 v) { p[0] = (u8)(v >> 24); p[1] = (u8)(v >> 16); p[2] = (u8)(v >> 8); p[3] = (u8)v; }

// y = (y xor x) * H no corpo GF(2^128) do GCM
static void ghash_mul(u8 y[16], const u8 x[16], const u8 H[16]) {
    u32 z[4] = {0, 0, 0, 0}, v[4], yy[4];
    for (int i = 0; i < 4; i++) { v[i] = ld32(H + 4*i); yy[i] = ld32(y + 4*i) ^ ld32(x + 4*i); }
    for (int i = 0; i < 128; i++) {
        if (yy[i >> 5] & (0x80000000u >> (i & 31))) { z[0] ^= v[0]; z[1] ^= v[1]; z[2] ^= v[2]; z[3] ^= v[3]; }
        u32 lsb = v[3] & 1;
        v[3] = (v[3] >> 1) | (v[2] << 31); v[2] = (v[2] >> 1) | (v[1] << 31);
        v[1] = (v[1] >> 1) | (v[0] << 31); v[0] >>= 1;
        if (lsb) v[0] ^= 0xE1000000u;
    }
    for (int i = 0; i < 4; i++) st32(y + 4*i, z[i]);
}
static void ghash_data(u8 y[16], const u8* d, u32 n, const u8 H[16]) {
    while (n >= 16) { ghash_mul(y, d, H); d += 16; n -= 16; }
    if (n) { u8 b[16]; zer(b, 16); cpy(b, d, n); ghash_mul(y, b, H); }
}
void gcm_init(Gcm* g, const u8 key[16]) {
    aes128_init(&g->aes, key);
    u8 z[16]; zer(z, 16);
    aes128_encrypt(&g->aes, z, g->H);
}
static void gctr(const Gcm* g, u8 ctr[16], const u8* in, u32 len, u8* out) {
    while (len) {
        u32 c = ld32(ctr + 12) + 1; st32(ctr + 12, c);
        u8 ks[16]; aes128_encrypt(&g->aes, ctr, ks);
        u32 k = len < 16 ? len : 16;
        for (u32 i = 0; i < k; i++) out[i] = (u8)(in[i] ^ ks[i]);
        in += k; out += k; len -= k;
    }
}
static void gcm_tag(const Gcm* g, const u8 iv[12], const u8* aad, u32 aadlen, const u8* ct, u32 len, u8 tag[16]) {
    u8 y[16]; zer(y, 16);
    ghash_data(y, aad, aadlen, g->H);
    ghash_data(y, ct, len, g->H);
    u8 lb[16]; zer(lb, 16);
    u32 abits = aadlen << 3, cbits = len << 3;
    st32(lb + 4, abits); st32(lb + 12, cbits);                 // (tamanhos < 512 MB)
    ghash_mul(y, lb, g->H);
    u8 j0[16]; cpy(j0, iv, 12); st32(j0 + 12, 1);
    u8 ek[16]; aes128_encrypt(&g->aes, j0, ek);
    for (int i = 0; i < 16; i++) tag[i] = (u8)(y[i] ^ ek[i]);
}
void gcm_encrypt(const Gcm* g, const u8 iv[12], const u8* aad, u32 aadlen, const u8* in, u32 len, u8* out, u8 tag[16]) {
    u8 ctr[16]; cpy(ctr, iv, 12); st32(ctr + 12, 1);
    gctr(g, ctr, in, len, out);
    gcm_tag(g, iv, aad, aadlen, out, len, tag);
}
bool gcm_decrypt(const Gcm* g, const u8 iv[12], const u8* aad, u32 aadlen, const u8* in, u32 len, u8* out, const u8 tag[16]) {
    u8 t[16]; gcm_tag(g, iv, aad, aadlen, in, len, t);
    u8 diff = 0; for (int i = 0; i < 16; i++) diff |= (u8)(t[i] ^ tag[i]);
    if (diff) return false;
    u8 ctr[16]; cpy(ctr, iv, 12); st32(ctr + 12, 1);
    gctr(g, ctr, in, len, out);
    return true;
}

// ============================================================ X25519 (estilo TweetNaCl)
typedef long long i64;
typedef i64 gf[16];
static const gf C121665 = { 0xDB41, 1 };

static void car25519(gf o) {
    for (int i = 0; i < 16; i++) {
        o[i] += (1LL << 16);
        i64 c = o[i] >> 16;
        o[(i + 1) * (i < 15)] += c - 1 + 37 * (c - 1) * (i == 15);
        o[i] -= c << 16;
    }
}
static void sel25519(gf p, gf q, int b) {
    i64 c = ~((i64)b - 1);
    for (int i = 0; i < 16; i++) { i64 t = c & (p[i] ^ q[i]); p[i] ^= t; q[i] ^= t; }
}
static void pack25519(u8* o, const gf n) {
    gf m, t;
    for (int i = 0; i < 16; i++) t[i] = n[i];
    car25519(t); car25519(t); car25519(t);
    for (int j = 0; j < 2; j++) {
        m[0] = t[0] - 0xffed;
        for (int i = 1; i < 15; i++) { m[i] = t[i] - 0xffff - ((m[i-1] >> 16) & 1); m[i-1] &= 0xffff; }
        m[15] = t[15] - 0x7fff - ((m[14] >> 16) & 1);
        int b = (int)((m[15] >> 16) & 1);
        m[14] &= 0xffff;
        sel25519(t, m, 1 - b);
    }
    for (int i = 0; i < 16; i++) { o[2*i] = (u8)(t[i] & 0xff); o[2*i+1] = (u8)(t[i] >> 8); }
}
static void unpack25519(gf o, const u8* n) {
    for (int i = 0; i < 16; i++) o[i] = n[2*i] + ((i64)n[2*i+1] << 8);
    o[15] &= 0x7fff;
}
static void fadd(gf o, const gf a, const gf b) { for (int i = 0; i < 16; i++) o[i] = a[i] + b[i]; }
static void fsub(gf o, const gf a, const gf b) { for (int i = 0; i < 16; i++) o[i] = a[i] - b[i]; }
static void fmul(gf o, const gf a, const gf b) {
    i64 t[31];
    for (int i = 0; i < 31; i++) t[i] = 0;
    for (int i = 0; i < 16; i++) for (int j = 0; j < 16; j++) t[i + j] += a[i] * b[j];
    for (int i = 0; i < 15; i++) t[i] += 38 * t[i + 16];
    for (int i = 0; i < 16; i++) o[i] = t[i];
    car25519(o); car25519(o);
}
static void fsq(gf o, const gf a) { fmul(o, a, a); }
static void inv25519(gf o, const gf in) {
    gf c;
    for (int a = 0; a < 16; a++) c[a] = in[a];
    for (int a = 253; a >= 0; a--) { fsq(c, c); if (a != 2 && a != 4) fmul(c, c, in); }
    for (int a = 0; a < 16; a++) o[a] = c[a];
}
void x25519(u8 out[32], const u8 n[32], const u8 p[32]) {
    u8 z[32];
    i64 x[80];
    gf a, b, c, d, e, f;
    for (int i = 0; i < 31; i++) z[i] = n[i];
    z[31] = (u8)((n[31] & 127) | 64); z[0] &= 248;
    unpack25519(x, p);
    for (int i = 0; i < 16; i++) { b[i] = x[i]; d[i] = a[i] = c[i] = 0; }
    a[0] = d[0] = 1;
    for (int i = 254; i >= 0; --i) {
        int r = (z[i >> 3] >> (i & 7)) & 1;
        sel25519(a, b, r); sel25519(c, d, r);
        fadd(e, a, c); fsub(a, a, c); fadd(c, b, d); fsub(b, b, d);
        fsq(d, e); fsq(f, a); fmul(a, c, a); fmul(c, b, e);
        fadd(e, a, c); fsub(a, a, c); fsq(b, a); fsub(c, d, f);
        fmul(a, c, C121665); fadd(a, a, d); fmul(c, c, a); fmul(a, d, f);
        fmul(d, b, x); fsq(b, e);
        sel25519(a, b, r); sel25519(c, d, r);
    }
    for (int i = 0; i < 16; i++) { x[i + 16] = a[i]; x[i + 32] = c[i]; x[i + 48] = b[i]; x[i + 64] = d[i]; }
    inv25519(x + 32, x + 32);
    fmul(x + 16, x + 16, x + 32);
    pack25519(out, x + 16);
}
void x25519_base(u8 out[32], const u8 scalar[32]) {
    u8 base[32]; zer(base, 32); base[0] = 9;
    x25519(out, scalar, base);
}

// ============================================================ Aleatorio
static u8  rng_pool[32];
static u32 rng_ctr = 0;
static bool rng_seeded = false;

void rng_add_entropy(const void* d, u32 n) {
    Sha256 c; sha256_init(&c);
    sha256_update(&c, rng_pool, 32);
    sha256_update(&c, d, n);
    sha256_final(&c, rng_pool);
    rng_seeded = true;
}
void rng_add_u32(u32 v) { rng_add_entropy(&v, 4); }
static u32 read_tsc() { u32 lo, hi; asm volatile("rdtsc" : "=a"(lo), "=d"(hi)); return lo ^ (hi * 2654435761u); }
void rng_bytes(u8* out, u32 n) {
    rng_add_u32(read_tsc());
    while (n) {
        u8 blk[32]; Sha256 c; sha256_init(&c);
        sha256_update(&c, rng_pool, 32); rng_ctr++; sha256_update(&c, &rng_ctr, 4);
        sha256_final(&c, blk);
        u32 k = n < 32 ? n : 32;
        cpy(out, blk, k); out += k; n -= k;
    }
    u8 nx[36]; cpy(nx, rng_pool, 32); st32(nx + 32, 0x4E455854u);      // "NEXT": avanca o estado (sigilo para frente)
    sha256(nx, 36, rng_pool);
}

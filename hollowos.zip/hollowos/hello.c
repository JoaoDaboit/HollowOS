// Programa de teste Linux i386 estatico, sem libc: usa so syscalls (int 0x80)
static inline int sc3(int n, int a, int b, int c) {
    int r; asm volatile("int $0x80" : "=a"(r) : "a"(n), "b"(a), "c"(b), "d"(c) : "memory"); return r;
}
static inline int sc6(int n, int a, int b, int c, int d, int e, int f) {
    register int ebp_ asm("ebp") = f;
    int r; asm volatile("int $0x80" : "=a"(r)
        : "a"(n), "b"(a), "c"(b), "d"(c), "S"(d), "D"(e), "r"(ebp_) : "memory"); return r;
}
static int len(const char* s) { int n = 0; while (s[n]) n++; return n; }
static void say(const char* s) { sc3(4, 1, (int)s, len(s)); }
static void num(int v) { char b[12]; int n = 11; b[n] = 0; if (!v) b[--n] = '0'; while (v) { b[--n] = '0' + v % 10; v /= 10; } say(b + n); }

void _start(void) {
    say("Ola! Sou um programa Linux (ELF i386) rodando no HollowOS.\n");
    // brk: aumenta o heap, escreve e le de volta
    int b0 = sc3(45, 0, 0, 0);
    int b1 = sc3(45, b0 + 8192, 0, 0);
    char* h = (char*)b0; for (int i = 0; i < 8192; i++) h[i] = (char)i;
    int ok = 1; for (int i = 0; i < 8192; i++) if (h[i] != (char)i) ok = 0;
    say("brk: "); say(b1 == b0 + 8192 && ok ? "ok\n" : "FALHOU\n");
    // mmap2 anonimo (PROT_READ|WRITE=3, MAP_PRIVATE|ANON=0x22)
    int m = sc6(192, 0, 65536, 3, 0x22, -1, 0);
    char* p = (char*)m; int z = ((unsigned)m < 0xFFFFF000u);
    if (z) { for (int i = 0; i < 65536; i++) if (p[i]) z = 0; p[0] = 42; z = z && p[0] == 42; }
    say("mmap: "); say(z ? "ok\n" : "FALHOU\n");
    say("getpid = "); num(sc3(20, 0, 0, 0)); say("\n");
    sc3(1, 0, 0, 0);                       // exit(0)
    for (;;) {}
}

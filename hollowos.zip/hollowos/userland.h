// userland.h - modo usuario (anel 3), chamadas de sistema Linux i386 e carregador ELF
#pragma once
#include "net.h"

enum { USER_ERR_NOT_ELF = -1, USER_ERR_UNSUPPORTED = -2, USER_ERR_RANGE = -3, USER_ERR_NOFILE = -4, USER_ERR_NOINTERP = -5, USER_ERR_BUSY = -6 };

void user_init();                                                  // GDT, TSS, IDT, FPU/SSE (chame 1 vez no boot)
// Roda o ELF do arquivo (inode do VFS). cwd = inode da pasta atual. Retorna codigo de saida (0..255) ou erro < 0.
int  user_run(int ino, int argc, const char* const* argv, int cwd);
const char* user_err(int rc);                                      // texto do erro de carga (ou 0)
// rc <= -1000: o programa foi morto por uma excecao da CPU (vetor = -1000 - rc)

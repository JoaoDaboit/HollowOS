# HollowOS - Roadmap

Legenda:  [x] pronto e testado   [~] pronto, compila, MAS ainda nao foi iniciado no QEMU   [ ] a fazer

O que foi testado de verdade (no PC, com `make test`, antes de entrar no kernel): SHA-256, HMAC, PRF, AES-GCM e
X25519 contra o Python/OpenSSL; o cliente TLS 1.2 contra um servidor OpenSSL (RSA e ECDSA, 1,5 MB baixados com
hash conferido); o cliente HTTP/HTTPS (GET, POST, redirecionamento, chunked); o conversor de HTML; o sistema de
arquivos (incluindo gravar e remontar de um "disco" simulado).
O que NAO foi testado: o boot no QEMU (nao havia QEMU nem nasm onde isto foi escrito). O kernel compila e linka
sem simbolos faltando, e o BSS termina em ~10,7 MB (limite: 16 MB).

## Fase 1 - Rede
- [~] Driver Intel e1000, ARP, IPv4, ICMP, UDP, DHCP, DNS (net.cpp)
- [~] UDP para programas Linux (1 soquete), ganchos para manter a tela viva durante esperas

## Fase 2 - Transporte e web
- [~] TCP minimo (1 conexao, retransmissao simples)
- [x] Cliente HTTP/1.1 (GET/POST, redirecionamento, chunked) sobre TCP ou TLS - web.cpp
- [ ] TCP completo: varias conexoes, fora de ordem, janela deslizante, congestionamento

## Fase 3 - Internet segura sem ponte (FEITO: HTTPS dentro do kernel)
- [x] SHA-256, HMAC, AES-128-GCM, X25519, gerador aleatorio (crypto.cpp)
- [x] TLS 1.2 cliente: ECDHE x25519 + AES-128-GCM, certificados RSA e ECDSA (tls.cpp)
- [ ] **Validar o certificado do servidor** (hoje NAO valida: protege contra quem so espia a rede,
      mas nao contra um atacante no meio). Falta: bignum/RSA, ECDSA P-256, parser X.509, lista de CAs, data.
- [ ] P-256 (hoje so x25519: servidores que insistem em P-256 falham com mensagem clara)
- [ ] TLS 1.3, retomada de sessao
- [~] Entropia: vem do tempo entre teclas/mouse e do rdtsc; no QEMU e fraca. RDRAND/virtio-rng seria melhor.
- [~] HTML -> texto com links clicaveis (html.cpp). Nao tem CSS, JavaScript, imagens nem formularios.

## Fase 4 - Armazenamento (FEITO)
- [~] Driver ATA PIO (disk.cpp)
- [x] Sistema de arquivos HFS proprio (vfs.cpp): pastas, 255 arquivos, 3 MB, gravacao em disco, remonta no boot
- [ ] Mais de 3 MB (hoje tudo fica na RAM), FAT32/ext2 para trocar arquivos com o PC, gravacao segura contra queda de energia
- [~] Comandos: ls cd cat cp mv rm mkdir touch df sync format, redirecao > e >>, wget grava no disco

## Fase 5 - Base para programas de verdade
- [x] GDT/IDT/TSS e excecoes; modo usuario (anel 3) e int 0x80
- [ ] Paginacao (memoria virtual)   (hoje: identity-map, exige QEMU -m 256)
- [ ] Multitarefa: processos, escalonador, **fork/exec/pipe/wait** (e por isso shells e pipelines Linux ainda nao rodam)

## Fase 6 - Executar programas Linux
- [~] ELF32: estatico, PIE e **dinamico via PT_INTERP** (ld.so em /lib; bibliotecas em /lib e /usr/lib)
- [~] ~120 syscalls Linux i386: arquivos (open/read/write/lseek/stat/getdents/mkdir/unlink/rename...), stdin do terminal,
      mmap2 anonimo e de arquivo, brk, poll, relogios, sockets TCP/UDP (socketcall e as chamadas diretas), uname, getrandom...
- [~] FPU/SSE ligados; argv/envp/auxv
- [ ] Rodar um programa estatico musl baixado com wget -> busybox (so applets sem fork) -> nano/htop
- [ ] Faltam: fork, execve, pipe, select, sockets servidor, /proc, /sys, threads reais, sinais de verdade, mremap
- [ ] Apps graficos exigem ainda: servidor de janelas (X11/Wayland) ou API propria
- Observacao realista: "a maioria dos aplicativos Linux" so e possivel depois de fork/exec + paginacao + /proc.
  Hoje: programas de terminal i386 que usam arquivos, rede e stdin e NAO fazem fork.

## Fase 7 - Aplicativos
- [x] DuckDuckGo e o aplicativo oficial (manifesto /apps/duckduckgo.app, primeiro na barra e no menu)
- [x] Gerenciador de Arquivos grafico, barra de tarefas com apps fixados, janelas, rede e relogio
- [ ] Repositorio com indice assinado, baixar, verificar hash, instalar (so depois da validacao de certificados)

Observacao: Firefox, GIMP, VLC e LibreOffice precisam de milhares de syscalls, glibc, GPU/X11 e muito mais.

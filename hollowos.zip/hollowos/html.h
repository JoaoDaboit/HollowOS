// html.h - HollowOS: transforma HTML em texto puro com links clicaveis (para o navegador DuckDuckGo)
#pragma once
#include "web.h"

#define PG_COLS   96          // largura maxima de uma linha (inclui o zero final)
#define PG_LINES  1500
#define PG_LINKS  200
#define PG_URLLEN 300

struct TextPage {
    char  lines[PG_LINES][PG_COLS];
    short link_of[PG_LINES];            // indice do link da linha (-1 = nenhum)
    char  links[PG_LINKS][PG_URLLEN];
    char  title[80];
    int   nlines, nlinks;
    // estado interno do construtor
    int   col, cur_link, wlen, blank_run;
    char  word[PG_COLS];
    bool  pending_space, in_pre;
};

void page_reset(TextPage* p);
void page_from_html(TextPage* p, const char* html, int n, const Url* base);
void page_from_ddg(TextPage* p, const char* html, int n, const char* query);   // resultados do html.duckduckgo.com
void page_from_text(TextPage* p, const char* text, int n);
void page_add_line(TextPage* p, const char* s, int link);                       // 1 linha pronta (corta se passar da largura)

// converte UTF-8 para ASCII (a fonte do HollowOS so tem ASCII). Escreve em out e retorna o tamanho.
int  fold_utf8(const char* in, int n, char* out, int max);

// net.h - driver de rede Intel e1000 + pilha minima (ARP, IPv4, ICMP, UDP, DHCP, DNS)
#pragma once

typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned int   u32;
typedef unsigned int   usize;

struct NetInfo {
    bool present;          // placa e1000 encontrada
    bool link;             // cabo/link ativo
    bool has_ip;           // DHCP concluido
    u8   mac[6];
    u8   ip[4];
    u8   mask[4];
    u8   gw[4];
    u8   dns[4];
    u32  rx_packets;
    u32  tx_packets;
};
extern NetInfo net;

bool net_init();                              // acha a placa e comeca o DHCP
void net_poll();                              // chame sempre no laco principal
u32  net_ms();                                // milissegundos desde o boot (precisa ser chamado com frequencia)
bool net_resolve(const char* name, u8* out);  // nome ou "1.2.3.4" -> IP (bloqueia ate ~3 s)
int  net_ping(const u8* ip, int timeout_ms);  // retorna tempo em ms, ou -1
void net_dhcp_restart();                      // pede um novo IP
void net_ip_str(const u8* ip, char* out);     // out: >= 16 bytes
void net_mac_str(const u8* mac, char* out);   // out: >= 18 bytes

// ---- TCP minimo (1 conexao por vez) e HTTP/1.0 em texto puro ----
bool tcp_connect(const u8* ip, u16 port, int timeout_ms);   // true se conectou
int  tcp_send(const u8* data, int len);                     // len ou -1
int  tcp_recv(u8* buf, int max, int timeout_ms);            // >0 bytes, 0 = fechou, -1 = tempo esgotado
void tcp_close();
// GET http://host:port/path. Grava cabecalhos + corpo em out. Retorna bytes, -1 DNS, -2 conexao, -3 envio.
int  http_get(const char* host, u16 port, const char* path, char* out, int maxlen, int timeout_ms);

// ---- ganchos para o kernel ----
extern void (*net_idle)();           // chamado dentro dos laços de espera (mantem a interface viva)
extern volatile bool net_cancel;     // ligue para abortar a operacao bloqueante em andamento
int  tcp_avail();                    // >0 bytes prontos, 0 nada ainda, -1 conexao fechada
bool tcp_alive();

// ---- UDP para programas Linux (um soquete por vez) ----
bool udp_open(u16 port);             // port 0 = escolhe uma porta alta
void udp_close();
u16  udp_local_port();
bool udp_send(const u8* ip, u16 port, const u8* data, int len);
int  udp_avail();                    // datagramas na fila
int  udp_recv(u8* buf, int max, u8* src_ip, u16* src_port, int timeout_ms);   // bytes ou -1 (tempo)

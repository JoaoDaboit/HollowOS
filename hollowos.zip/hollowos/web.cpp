// web.cpp - HollowOS: HTTP/1.1 sobre TCP (porta 80) e TLS (porta 443). Uma conexao por pedido.
#include "web.h"
#include "tls.h"

static inline void cpy(void* d, const void* s, u32 n) { u8* a = (u8*)d; const u8* b = (const u8*)s; while (n--) *a++ = *b++; }
static int slen(const char* s) { int n = 0; while (s[n]) n++; return n; }
static void scpy(char* d, const char* s, int max) { int i = 0; for (; s[i] && i < max - 1; i++) d[i] = s[i]; d[i] = 0; }
static void scat(char* d, const char* s, int max) { int n = slen(d), i = 0; for (; s[i] && n + i < max - 1; i++) d[n + i] = s[i]; d[n + i] = 0; }
static char lc(char c) { return (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c; }
static bool starts_ci(const char* s, const char* p) { while (*p) { if (lc(*s) != lc(*p)) return false; s++; p++; } return true; }

// ---------------------------------------------------------------- URL
bool url_parse(const char* s, Url* u) {
    while (*s == ' ') s++;
    u->https = true; u->port = 443;
    if (starts_ci(s, "https://")) s += 8;
    else if (starts_ci(s, "http://")) { s += 7; u->https = false; u->port = 80; }
    else if (starts_ci(s, "//")) s += 2;
    int n = 0;
    while (*s && *s != '/' && *s != '?' && *s != '#' && *s != ':' && n < (int)sizeof(u->host) - 1) u->host[n++] = lc(*s++);
    u->host[n] = 0;
    if (n == 0) return false;
    if (*s == ':') {
        s++; int p = 0, d = 0;
        while (*s >= '0' && *s <= '9') { p = p * 10 + (*s - '0'); s++; d++; if (p > 65535) return false; }
        if (!d) return false;
        u->port = (u16)p;
    }
    while (*s && *s != '/' && *s != '?' && *s != '#') s++;      // lixo entre host e caminho
    int k = 0;
    if (*s != '/') u->path[k++] = '/';
    for (; *s && *s != '#' && k < (int)sizeof(u->path) - 1; s++) u->path[k++] = (*s == ' ') ? '+' : *s;
    u->path[k] = 0;
    return true;
}
void url_string(const Url& u, char* out, int max) {
    scpy(out, u.https ? "https://" : "http://", max); scat(out, u.host, max);
    if ((u.https && u.port != 443) || (!u.https && u.port != 80)) {
        char b[8]; int v = u.port, n = 0; char t[8];
        while (v) { t[n++] = (char)('0' + v % 10); v /= 10; }
        int k = 0; b[k++] = ':'; while (n) b[k++] = t[--n]; b[k] = 0; scat(out, b, max);
    }
    scat(out, u.path, max);
}
void url_resolve(const Url& base, const char* ref, char* out, int max) {
    if (starts_ci(ref, "http://") || starts_ci(ref, "https://")) { scpy(out, ref, max); return; }
    char root[200]; scpy(root, base.https ? "https://" : "http://", sizeof root); scat(root, base.host, sizeof root);
    if ((base.https && base.port != 443) || (!base.https && base.port != 80)) {
        char b[8]; int v = base.port, n = 0; char t[8]; while (v) { t[n++] = (char)('0' + v % 10); v /= 10; }
        int k = 0; b[k++] = ':'; while (n) b[k++] = t[--n]; b[k] = 0; scat(root, b, sizeof root);
    }
    if (ref[0] == '/' && ref[1] == '/') { scpy(out, base.https ? "https:" : "http:", max); scat(out, ref, max); return; }
    if (ref[0] == '/') { scpy(out, root, max); scat(out, ref, max); return; }
    char path[600]; scpy(path, base.path, sizeof path);
    if (ref[0] == '?') {                                    // so a query
        for (int i = 0; path[i]; i++) if (path[i] == '?') { path[i] = 0; break; }
        scpy(out, root, max); scat(out, path, max); scat(out, ref, max); return;
    }
    for (int i = 0; path[i]; i++) if (path[i] == '?') { path[i] = 0; break; }
    int e = slen(path); while (e > 0 && path[e - 1] != '/') e--;
    path[e] = 0;                                            // diretorio base
    scat(path, ref, sizeof path);
    // normaliza "." e ".." segmento a segmento
    char res[600]; int rl = 0; bool dirend = false;
    for (int i = 0; path[i] && rl < (int)sizeof(res) - 2;) {
        int j = i + 1; while (path[j] && path[j] != '/') j++;
        int sl = j - i - 1;
        dirend = false;
        if (sl == 1 && path[i + 1] == '.') dirend = true;
        else if (sl == 2 && path[i + 1] == '.' && path[i + 2] == '.') { while (rl > 0 && res[rl - 1] != '/') rl--; if (rl > 0) rl--; dirend = true; }
        else for (int k = i; k < j && rl < (int)sizeof(res) - 2; k++) res[rl++] = path[k];
        i = j;
    }
    if (dirend || rl == 0) res[rl++] = '/';
    res[rl] = 0;
    scpy(out, root, max); scat(out, res, max);
}
void url_encode(const char* s, char* o, int max) {
    static const char hx[] = "0123456789ABCDEF";
    int n = 0;
    for (; *s && n < max - 4; s++) {
        u8 c = (u8)*s;
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.' || c == '~') o[n++] = (char)c;
        else if (c == ' ') o[n++] = '+';
        else { o[n++] = '%'; o[n++] = hx[c >> 4]; o[n++] = hx[c & 15]; }
    }
    o[n] = 0;
}
static int hexv(char c) { return c >= '0' && c <= '9' ? c - '0' : c >= 'a' && c <= 'f' ? c - 'a' + 10 : c >= 'A' && c <= 'F' ? c - 'A' + 10 : -1; }
void url_decode(const char* s, int n, char* out, int max) {
    int o = 0;
    for (int i = 0; i < n && o < max - 1; i++) {
        if (s[i] == '%' && i + 2 < n && hexv(s[i + 1]) >= 0 && hexv(s[i + 2]) >= 0) { out[o++] = (char)(hexv(s[i + 1]) * 16 + hexv(s[i + 2])); i += 2; }
        else if (s[i] == '+') out[o++] = ' ';
        else out[o++] = s[i];
    }
    out[o] = 0;
}

// ---------------------------------------------------------------- conexao (TCP ou TLS)
static bool g_tls = false;
static int conn_send(const u8* d, int n) { return g_tls ? tls_send(d, n) : tcp_send(d, n); }
static int conn_recv(u8* b, int max, int to) { return g_tls ? tls_recv(b, max, to) : tcp_recv(b, max, to); }
static void conn_close() { if (g_tls) tls_close(); else tcp_close(); }

// ---------------------------------------------------------------- corpo (chunked / content-length / ate fechar)
struct Body {
    int mode;                 // 0 = ate fechar, 1 = content-length, 2 = chunked
    long remain;              // modo 1: bytes que faltam
    int cstate;               // modo 2: 0 tamanho, 1 dados, 2 CRLF apos dados, 3 trailer/fim
    long csize; int sizedigits; bool sizeline_ext;
    bool done;
    WebSink sink; void* ctx; u32 total;
    bool aborted;
};
static bool emit(Body& b, const u8* d, int n) {
    if (n <= 0) return true;
    b.total += n;
    if (b.sink && !b.sink(d, n, b.ctx)) { b.aborted = true; return false; }
    return true;
}
static bool body_feed(Body& b, const u8* p, int n) {
    if (b.done) return true;
    if (b.mode == 0) return emit(b, p, n);
    if (b.mode == 1) {
        int k = (long)n > b.remain ? (int)b.remain : n;
        if (!emit(b, p, k)) return false;
        b.remain -= k; if (b.remain <= 0) b.done = true;
        return true;
    }
    int i = 0;
    while (i < n && !b.done) {
        if (b.cstate == 0) {                                  // linha com o tamanho em hexa
            char c = (char)p[i++];
            if (c == '\n') { b.cstate = b.csize == 0 ? 3 : 1; b.remain = b.csize; b.sizeline_ext = false; if (b.csize == 0) b.done = true; }
            else if (c == ';') b.sizeline_ext = true;
            else if (!b.sizeline_ext && hexv(c) >= 0) { b.csize = b.csize * 16 + hexv(c); }
        } else if (b.cstate == 1) {
            int k = (long)(n - i) > b.remain ? (int)b.remain : n - i;
            if (!emit(b, p + i, k)) return false;
            i += k; b.remain -= k; if (b.remain == 0) b.cstate = 2;
        } else if (b.cstate == 2) {                           // CRLF depois dos dados
            if (p[i++] == '\n') { b.cstate = 0; b.csize = 0; b.sizeline_ext = false; }
        }
    }
    return true;
}

// ---------------------------------------------------------------- pedido
static char hdr[8192];
static const char* UA = "Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0";

static bool header_get(const char* h, const char* name, char* out, int max) {
    int nl = slen(name);
    for (const char* p = h; *p;) {
        if (starts_ci(p, name) && p[nl] == ':') {
            p += nl + 1; while (*p == ' ') p++;
            int k = 0; while (*p && *p != '\r' && *p != '\n' && k < max - 1) out[k++] = *p++;
            out[k] = 0; return true;
        }
        while (*p && *p != '\n') p++;
        if (*p) p++;
    }
    return false;
}

bool web_request(const char* method, const char* url, const char* post_body, WebSink sink, void* ctx, WebResult* r, int timeout_ms) {
    r->status = 0; r->redirects = 0; r->bytes = 0; r->error = 0; r->ctype[0] = 0; r->final_url[0] = 0;
    char cur[700]; scpy(cur, url, sizeof cur);
    bool post = (method[0] == 'P');
    static char reqbuf[1800];

    for (int hop = 0; hop <= 5; hop++) {
        Url u;
        if (!url_parse(cur, &u)) { r->error = "URL invalida."; return false; }
        url_string(u, r->final_url, sizeof r->final_url);
        u8 ip[4];
        if (!net_resolve(u.host, ip)) { r->error = "Nao consegui resolver o nome (DNS)."; return false; }
        g_tls = u.https;
        if (u.https) {
            if (!tls_connect(u.host, ip, u.port, timeout_ms)) { r->error = tls_error(); return false; }
        } else if (!tcp_connect(ip, u.port, 5000)) { r->error = "Nao consegui conectar ao servidor."; return false; }

        // ---- monta o pedido
        int n = 0; reqbuf[0] = 0;
        scpy(reqbuf, post ? "POST " : "GET ", sizeof reqbuf); scat(reqbuf, u.path, sizeof reqbuf);
        scat(reqbuf, " HTTP/1.1\r\nHost: ", sizeof reqbuf); scat(reqbuf, u.host, sizeof reqbuf);
        if ((u.https && u.port != 443) || (!u.https && u.port != 80)) {
            char pb[8]; int v = u.port, k = 0; char t[8]; while (v) { t[k++] = (char)('0' + v % 10); v /= 10; }
            int m = 0; pb[m++] = ':'; while (k) pb[m++] = t[--k]; pb[m] = 0; scat(reqbuf, pb, sizeof reqbuf);
        }
        scat(reqbuf, "\r\nUser-Agent: ", sizeof reqbuf); scat(reqbuf, UA, sizeof reqbuf);
        scat(reqbuf, "\r\nAccept: text/html,application/xhtml+xml,*/*;q=0.8\r\nAccept-Language: pt-BR,pt;q=0.9,en;q=0.5\r\nAccept-Encoding: identity\r\nConnection: close\r\n", sizeof reqbuf);
        if (post) {
            int bl = slen(post_body); char nb[12]; int k = 0; char t[12]; int v = bl; if (!v) t[k++] = '0'; while (v) { t[k++] = (char)('0' + v % 10); v /= 10; }
            int m = 0; while (k) nb[m++] = t[--k]; nb[m] = 0;
            scat(reqbuf, "Content-Type: application/x-www-form-urlencoded\r\nContent-Length: ", sizeof reqbuf); scat(reqbuf, nb, sizeof reqbuf);
            scat(reqbuf, "\r\n\r\n", sizeof reqbuf); scat(reqbuf, post_body, sizeof reqbuf);
        } else scat(reqbuf, "\r\n", sizeof reqbuf);
        n = slen(reqbuf);
        if (conn_send((const u8*)reqbuf, n) < 0) { conn_close(); r->error = g_tls ? tls_error() : "Falha ao enviar o pedido."; return false; }

        // ---- cabecalhos
        int hl = 0;
        static u8 first[4096]; int firstn = 0;
        Body b; b.mode = 0; b.remain = 0; b.cstate = 0; b.csize = 0; b.sizeline_ext = false; b.done = false; b.sink = sink; b.ctx = ctx; b.total = 0; b.aborted = false;
        bool headers_done = false, redirecting = false;
        char loc[700]; loc[0] = 0;
        for (;;) {
            static u8 buf[4096];
            int got = conn_recv(buf, sizeof buf, timeout_ms);
            if (got < 0) { conn_close(); r->error = "Tempo esgotado esperando o servidor."; return false; }
            if (got == 0) break;                                              // servidor fechou
            if (!headers_done) {
                for (int i = 0; i < got; i++) {
                    if (hl < (int)sizeof(hdr) - 1) hdr[hl++] = (char)buf[i];
                    if (hl >= 4 && hdr[hl - 4] == '\r' && hdr[hl - 3] == '\n' && hdr[hl - 2] == '\r' && hdr[hl - 1] == '\n') {
                        hdr[hl] = 0; headers_done = true;
                        firstn = got - (i + 1); if (firstn > 0) cpy(first, buf + i + 1, firstn);
                        break;
                    }
                }
                if (!headers_done && hl >= (int)sizeof(hdr) - 1) { conn_close(); r->error = "Cabecalhos HTTP grandes demais."; return false; }
                if (!headers_done) continue;
                // interpreta
                int st = 0;
                if (hl > 12 && hdr[0] == 'H') for (int i = 9; i < 12; i++) st = st * 10 + (hdr[i] - '0');
                r->status = st;
                char v[96];
                if (header_get(hdr, "Content-Type", r->ctype, sizeof r->ctype)) {}
                if (header_get(hdr, "Transfer-Encoding", v, sizeof v) && starts_ci(v, "chunked")) b.mode = 2;
                else if (header_get(hdr, "Content-Length", v, sizeof v)) { long x = 0; for (int i = 0; v[i] >= '0' && v[i] <= '9'; i++) x = x * 10 + (v[i] - '0'); b.mode = 1; b.remain = x; if (x == 0) b.done = true; }
                if ((st == 301 || st == 302 || st == 303 || st == 307 || st == 308) && header_get(hdr, "Location", loc, sizeof loc) && loc[0]) redirecting = true;
                if (redirecting) break;
                if (st == 204 || st == 304) b.done = true;
                if (firstn > 0 && !body_feed(b, first, firstn)) break;
                if (b.done) break;
                continue;
            }
            if (!body_feed(b, buf, got) || b.done) break;
        }
        conn_close();
        if (!headers_done) { r->error = "O servidor fechou a conexao sem responder."; return false; }
        if (redirecting) {
            if (hop == 5) { r->error = "Redirecionamentos demais."; return false; }
            char abs[700]; url_resolve(u, loc, abs, sizeof abs);
            scpy(cur, abs, sizeof cur); r->redirects++;
            if (r->status == 301 || r->status == 302 || r->status == 303) post = false;
            continue;
        }
        r->bytes = b.total;
        return true;
    }
    r->error = "Redirecionamentos demais."; return false;
}

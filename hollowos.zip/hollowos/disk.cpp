// disk.cpp - HollowOS: ATA PIO (sem interrupcoes). Funciona no QEMU e em PCs com controladora em modo IDE/legado.
#include "disk.h"

static inline void outb(u16 p, u8 v)  { asm volatile("outb %0,%1" :: "a"(v), "Nd"(p)); }
static inline u8   inb(u16 p)         { u8 r; asm volatile("inb %1,%0" : "=a"(r) : "Nd"(p)); return r; }
static inline u16  inw(u16 p)         { u16 r; asm volatile("inw %1,%0" : "=a"(r) : "Nd"(p)); return r; }
static inline void outw(u16 p, u16 v) { asm volatile("outw %0,%1" :: "a"(v), "Nd"(p)); }

static const u16 IO = 0x1F0, CTL = 0x3F6;
static bool present = false;
static u32  nsect = 0;

static void delay400() { for (int i = 0; i < 4; i++) inb(CTL); }
static bool wait_bsy() { for (int i = 0; i < 4000000; i++) { if (!(inb(IO + 7) & 0x80)) return true; } return false; }
static bool wait_drq() {
    for (int i = 0; i < 4000000; i++) {
        u8 s = inb(IO + 7);
        if (s & 0x01) return false;                 // ERR
        if (s & 0x20) return false;                 // DF
        if (!(s & 0x80) && (s & 0x08)) return true; // !BSY && DRQ
    }
    return false;
}

bool disk_init() {
    present = false; nsect = 0;
    if (inb(IO + 7) == 0xFF) return false;          // barramento flutuando: nao ha controladora
    outb(CTL, 0x02);                                // nIEN: sem interrupcoes
    outb(IO + 6, 0xA0); delay400();                 // seleciona o mestre
    outb(IO + 2, 0); outb(IO + 3, 0); outb(IO + 4, 0); outb(IO + 5, 0);
    outb(IO + 7, 0xEC);                             // IDENTIFY
    if (inb(IO + 7) == 0) return false;             // sem dispositivo
    if (!wait_bsy()) return false;
    if (inb(IO + 4) != 0 || inb(IO + 5) != 0) return false;   // nao e ATA (ATAPI etc.)
    if (!wait_drq()) return false;
    u16 id[256];
    for (int i = 0; i < 256; i++) id[i] = inw(IO);
    nsect = (u32)id[60] | ((u32)id[61] << 16);
    if (nsect == 0) return false;
    present = true;
    return true;
}
u32 disk_sectors() { return present ? nsect : 0; }

static bool setup(u32 lba, u32 count, u8 cmd) {
    if (!present || count == 0 || count > 255 || lba + count > nsect) return false;
    if (!wait_bsy()) return false;
    outb(IO + 6, (u8)(0xE0 | ((lba >> 24) & 0x0F)));
    outb(IO + 2, (u8)count);
    outb(IO + 3, (u8)lba); outb(IO + 4, (u8)(lba >> 8)); outb(IO + 5, (u8)(lba >> 16));
    outb(IO + 7, cmd);
    return true;
}
bool disk_read(u32 lba, u32 count, void* buf) {
    if (!setup(lba, count, 0x20)) return false;
    u16* p = (u16*)buf;
    for (u32 s = 0; s < count; s++) {
        if (!wait_drq()) return false;
        for (int i = 0; i < 256; i++) *p++ = inw(IO);
        delay400();
    }
    return true;
}
bool disk_write(u32 lba, u32 count, const void* buf) {
    if (!setup(lba, count, 0x30)) return false;
    const u16* p = (const u16*)buf;
    for (u32 s = 0; s < count; s++) {
        if (!wait_drq()) return false;
        for (int i = 0; i < 256; i++) outw(IO, *p++);
        delay400();
    }
    outb(IO + 7, 0xE7);                             // CACHE FLUSH
    return wait_bsy();
}

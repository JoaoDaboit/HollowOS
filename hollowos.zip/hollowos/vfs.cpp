// vfs.cpp - HollowOS: HFS (veja vfs.h). Estruturas simples: tabela de inodes + FAT de blocos de 4 KB.
#include "vfs.h"
#include "disk.h"

static inline void cpy(void* d, const void* s, u32 n) { u8* a = (u8*)d; const u8* b = (const u8*)s; while (n--) *a++ = *b++; }
static inline void zer(void* d, u32 n) { u8* a = (u8*)d; while (n--) *a++ = 0; }
static int slen(const char* s) { int n = 0; while (s[n]) n++; return n; }
static bool seq(const char* a, const char* b) { while (*a && *a == *b) { a++; b++; } return *a == *b; }

#define FAT_FREE 0xFFFE
#define FAT_END  0xFFFF
#define NONE     0xFFFF

struct Inode {                     // 44 bytes
    u8  type, pad;
    u16 parent;
    u16 first;                     // 1o bloco (NONE se vazio)
    u16 nblk;
    u32 size;
    u32 mtime;
    char name[VFS_NAME];
};
struct Meta {                      // vai inteiro para o disco (setores 0..META_SECT-1)
    char magic[8];                 // "HFS1...."
    u32  nino, nblk, version, reserved;
    Inode ino[VFS_NINO];
    u16  fat[VFS_NBLK];
};
static Meta M;
static u8   pool[VFS_NBLK][VFS_BLK];
static u8   blk_dirty[VFS_NBLK];
static bool meta_dirty = false;
static u32  dirty_since = 0;
static bool g_disk = false;
u32 (*vfs_clock)() = 0;

static const u32 META_SECT = 40;                 // sizeof(Meta) ~ 13 KB -> 26 setores; reservamos 40
static const u32 DATA_LBA  = 40;
static inline u32 blk_lba(int b) { return DATA_LBA + (u32)b * (VFS_BLK / 512); }
static bool g_dirty_flag = false;

static void touch_meta() { meta_dirty = true; g_dirty_flag = true; }
static u32 now_sec() { return vfs_clock ? vfs_clock() : 0; }

void vfs_init() {
    zer(&M, sizeof M);
    cpy(M.magic, "HFS1", 5); M.nino = VFS_NINO; M.nblk = VFS_NBLK; M.version = 1;
    for (int i = 0; i < VFS_NBLK; i++) M.fat[i] = FAT_FREE;
    M.ino[VFS_ROOT].type = VT_DIR; M.ino[VFS_ROOT].parent = VFS_ROOT; M.ino[VFS_ROOT].first = NONE;
    M.ino[VFS_ROOT].name[0] = 0; M.ino[VFS_ROOT].mtime = now_sec();
    zer(blk_dirty, sizeof blk_dirty); meta_dirty = false; g_dirty_flag = false;
}

// ---------------------------------------------------------------- disco
bool vfs_disk_ok() { return g_disk; }
static bool disk_write_meta() {
    static_assert(sizeof(Meta) <= 40 * 512, "Meta grande demais");
    static u8 tmp[40 * 512];
    zer(tmp, sizeof tmp); cpy(tmp, &M, sizeof M);
    for (u32 s = 0; s < META_SECT; s += 20) if (!disk_write(s, 20, tmp + s * 512)) return false;
    return true;
}
bool vfs_format_disk() {
    if (!disk_init()) { g_disk = false; return false; }
    if (disk_sectors() < DATA_LBA + VFS_NBLK * (VFS_BLK / 512)) { g_disk = false; return false; }
    g_disk = true;
    if (!disk_write_meta()) { g_disk = false; return false; }
    meta_dirty = false;
    return true;
}
bool vfs_mount_disk() {
    g_disk = false;
    if (!disk_init()) return false;
    if (disk_sectors() < DATA_LBA + VFS_NBLK * (VFS_BLK / 512)) return false;
    static u8 tmp[40 * 512];
    for (u32 s = 0; s < META_SECT; s += 20) if (!disk_read(s, 20, tmp + s * 512)) return false;
    Meta* m = (Meta*)tmp;
    if (!(m->magic[0] == 'H' && m->magic[1] == 'F' && m->magic[2] == 'S' && m->magic[3] == '1') || m->nino != VFS_NINO || m->nblk != VFS_NBLK) return false;
    if (m->ino[VFS_ROOT].type != VT_DIR) return false;
    cpy(&M, m, sizeof M);
    for (int b = 0; b < VFS_NBLK; b++) {
        if (M.fat[b] == FAT_FREE) continue;
        for (u32 s = 0; s < VFS_BLK / 512; s += 8) {                // 8 setores por chamada = 4 KB (1 bloco)
            if (!disk_read(blk_lba(b) + s, 8, &pool[b][s * 512])) { vfs_init(); return false; }
        }
    }
    zer(blk_dirty, sizeof blk_dirty); meta_dirty = false; g_dirty_flag = false;
    g_disk = true;
    return true;
}
void vfs_sync() {
    if (!g_disk || !g_dirty_flag) { g_dirty_flag = false; return; }
    for (int b = 0; b < VFS_NBLK; b++) {
        if (!blk_dirty[b]) continue;
        if (M.fat[b] != FAT_FREE) disk_write(blk_lba(b), 8, pool[b]);
        blk_dirty[b] = 0;
    }
    if (meta_dirty) { disk_write_meta(); meta_dirty = false; }
    g_dirty_flag = false;
}
void vfs_autosync(u32 now_ms) {
    if (!g_disk) return;
    static bool was = false;
    if (g_dirty_flag && !was) { dirty_since = now_ms; was = true; }
    if (!g_dirty_flag) { was = false; return; }
    if (now_ms - dirty_since > 3000) { vfs_sync(); was = false; }
}

// ---------------------------------------------------------------- blocos
static int blk_alloc() {
    static int hint = 0;
    for (int k = 0; k < VFS_NBLK; k++) {
        int b = (hint + k) % VFS_NBLK;
        if (M.fat[b] == FAT_FREE) { M.fat[b] = FAT_END; hint = b + 1; zer(pool[b], VFS_BLK); blk_dirty[b] = 1; return b; }
    }
    return -1;
}
static void chain_free(int first) {
    int b = first;
    while (b != NONE && b < VFS_NBLK) { int nx = M.fat[b]; M.fat[b] = FAT_FREE; blk_dirty[b] = 0; if (nx == FAT_END || nx == FAT_FREE) break; b = nx; }
}
// bloco numero k do arquivo (k=0 e o primeiro); -1 se nao existe
static int blk_at(const Inode& n, u32 k) {
    int b = n.first;
    for (u32 i = 0; i < k; i++) { if (b == NONE || b >= VFS_NBLK) return -1; b = M.fat[b]; if (b == FAT_END || b == FAT_FREE) return -1; }
    return (b == NONE || b >= VFS_NBLK) ? -1 : b;
}

// ---------------------------------------------------------------- nomes e caminhos
static bool valid_ino(int i) { return i >= 0 && i < VFS_NINO && M.ino[i].type != VT_FREE; }
int vfs_type(int i) { return valid_ino(i) ? (int)M.ino[i].type : (int)VT_FREE; }
u32 vfs_size(int i) { return valid_ino(i) ? M.ino[i].size : 0; }
u32 vfs_mtime(int i) { return valid_ino(i) ? M.ino[i].mtime : 0; }
const char* vfs_name(int i) { return valid_ino(i) ? M.ino[i].name : ""; }
int vfs_parent(int i) { return valid_ino(i) ? (int)M.ino[i].parent : 0; }

int vfs_lookup(int dir, const char* name) {
    if (!valid_ino(dir) || M.ino[dir].type != VT_DIR) return VE_NOTDIR;
    if (seq(name, ".") || !name[0]) return dir;
    if (seq(name, "..")) return M.ino[dir].parent;
    for (int i = 1; i < VFS_NINO; i++)
        if (M.ino[i].type != VT_FREE && M.ino[i].parent == dir && seq(M.ino[i].name, name)) return i;
    return VE_NOENT;
}
int vfs_nth_child(int dir, int n) {
    for (int i = 1; i < VFS_NINO; i++)
        if (M.ino[i].type != VT_FREE && M.ino[i].parent == dir) { if (n-- == 0) return i; }
    return -1;
}
// consome um componente de caminho; retorna ponteiro para o resto
static const char* next_comp(const char* p, char* comp) {
    while (*p == '/') p++;
    int n = 0;
    while (*p && *p != '/') { if (n < VFS_NAME) comp[n] = *p; n++; p++; }
    if (n > VFS_NAME - 1) { comp[0] = 0; return 0; }
    comp[n] = 0;
    return p;
}
int vfs_resolve(const char* path, int cwd) {
    int cur = (path[0] == '/') ? VFS_ROOT : cwd;
    if (!valid_ino(cur)) cur = VFS_ROOT;
    char comp[VFS_NAME + 1];
    for (;;) {
        path = next_comp(path, comp);
        if (!path) return VE_NAMETOOLONG;
        if (!comp[0]) return cur;
        int nx = vfs_lookup(cur, comp);
        if (nx < 0) return nx;
        cur = nx;
        // se ainda ha caminho depois e cur nao e pasta: erro
        const char* q = path; while (*q == '/') q++;
        if (*q && M.ino[cur].type != VT_DIR) return VE_NOTDIR;
    }
}
int vfs_parent_of(const char* path, int cwd, char* leaf) {
    int cur = (path[0] == '/') ? VFS_ROOT : cwd;
    if (!valid_ino(cur)) cur = VFS_ROOT;
    char comp[VFS_NAME + 1], nextc[VFS_NAME + 1];
    const char* p = next_comp(path, comp);
    if (!p) return VE_NAMETOOLONG;
    if (!comp[0]) { leaf[0] = 0; return cur; }                 // "/" ou ""
    for (;;) {
        const char* q = next_comp(p, nextc);
        if (!q) return VE_NAMETOOLONG;
        if (!nextc[0]) { int n = 0; while (comp[n]) { leaf[n] = comp[n]; n++; } leaf[n] = 0; return cur; }
        int nx = vfs_lookup(cur, comp);
        if (nx < 0) return nx;
        if (M.ino[nx].type != VT_DIR) return VE_NOTDIR;
        cur = nx;
        int n = 0; while (nextc[n]) { comp[n] = nextc[n]; n++; } comp[n] = 0;
        p = q;
    }
}
int vfs_path(int ino, char* out, int max) {
    if (!valid_ino(ino)) { out[0] = 0; return VE_NOENT; }
    if (ino == VFS_ROOT) { out[0] = '/'; out[1] = 0; return 1; }
    int chain[40], n = 0;
    for (int c = ino; c != VFS_ROOT && n < 40; c = M.ino[c].parent) chain[n++] = c;
    int o = 0;
    for (int k = n - 1; k >= 0; k--) {
        if (o < max - 1) out[o++] = '/';
        for (const char* s = M.ino[chain[k]].name; *s && o < max - 1; s++) out[o++] = *s;
    }
    out[o] = 0; return o;
}

// ---------------------------------------------------------------- criar/remover/renomear
static bool name_ok(const char* n) {
    int l = slen(n);
    if (l == 0 || l >= VFS_NAME) return false;
    if (seq(n, ".") || seq(n, "..")) return false;
    for (int i = 0; i < l; i++) if (n[i] == '/') return false;
    return true;
}
int vfs_create(int dir, const char* name, int type) {
    if (!valid_ino(dir) || M.ino[dir].type != VT_DIR) return VE_NOTDIR;
    int l = slen(name);
    if (l >= VFS_NAME) return VE_NAMETOOLONG;
    if (!name_ok(name)) return VE_INVAL;
    if (vfs_lookup(dir, name) >= 0) return VE_EXIST;
    for (int i = 1; i < VFS_NINO; i++) {
        if (M.ino[i].type != VT_FREE) continue;
        Inode& n = M.ino[i]; zer(&n, sizeof n);
        n.type = (u8)type; n.parent = (u16)dir; n.first = NONE; n.mtime = now_sec();
        cpy(n.name, name, l + 1);
        M.ino[dir].mtime = n.mtime;
        touch_meta();
        return i;
    }
    return VE_NOSPC;
}
int vfs_unlink(int ino) {
    if (!valid_ino(ino) || ino == VFS_ROOT) return VE_INVAL;
    Inode& n = M.ino[ino];
    if (n.type == VT_DIR) { if (vfs_nth_child(ino, 0) >= 0) return VE_NOTEMPTY; }
    else if (n.first != NONE) chain_free(n.first);
    int par = n.parent;
    zer(&n, sizeof n);
    M.ino[par].mtime = now_sec();
    touch_meta();
    return 0;
}
int vfs_rename(int ino, int newdir, const char* newname) {
    if (!valid_ino(ino) || ino == VFS_ROOT) return VE_INVAL;
    if (!valid_ino(newdir) || M.ino[newdir].type != VT_DIR) return VE_NOTDIR;
    if (!name_ok(newname)) return slen(newname) >= VFS_NAME ? VE_NAMETOOLONG : VE_INVAL;
    for (int c = newdir;; c = M.ino[c].parent) { if (c == ino) return VE_INVAL; if (c == VFS_ROOT) break; }   // nao move pasta para dentro dela mesma
    int ex = vfs_lookup(newdir, newname);
    if (ex >= 0 && ex != ino) return VE_EXIST;
    M.ino[ino].parent = (u16)newdir;
    int l = slen(newname); cpy(M.ino[ino].name, newname, l + 1);
    M.ino[ino].mtime = now_sec();
    touch_meta();
    return 0;
}

// ---------------------------------------------------------------- dados
int vfs_read(int ino, u32 off, void* buf, u32 n) {
    if (!valid_ino(ino)) return VE_NOENT;
    Inode& in = M.ino[ino];
    if (in.type == VT_DIR) return VE_ISDIR;
    if (off >= in.size) return 0;
    if (n > in.size - off) n = in.size - off;
    u8* o = (u8*)buf; u32 done = 0;
    u32 k = off / VFS_BLK;
    int b = blk_at(in, k);
    while (done < n) {
        if (b < 0) break;
        u32 bo = (off + done) % VFS_BLK;
        u32 c = VFS_BLK - bo; if (c > n - done) c = n - done;
        cpy(o + done, &pool[b][bo], c);
        done += c;
        if (bo + c == VFS_BLK) { int nx = M.fat[b]; b = (nx == FAT_END || nx == FAT_FREE) ? -1 : nx; }
    }
    return (int)done;
}
int vfs_write(int ino, u32 off, const void* buf, u32 n) {
    if (!valid_ino(ino)) return VE_NOENT;
    Inode& in = M.ino[ino];
    if (in.type == VT_DIR) return VE_ISDIR;
    if (n == 0) return 0;
    if (off + n < off || off + n > (u32)VFS_NBLK * VFS_BLK) return VE_FBIG;
    // garante blocos ate off+n (e zera o buraco se off > size: blocos novos ja vem zerados)
    u32 need = (off + n + VFS_BLK - 1) / VFS_BLK;
    while (in.nblk < need) {
        int b = blk_alloc();
        if (b < 0) return in.size > off ? 0 : VE_NOSPC;
        if (in.first == NONE) in.first = (u16)b;
        else { int last = blk_at(in, in.nblk - 1); if (last < 0) return VE_IO; M.fat[last] = (u16)b; }
        in.nblk++;
    }
    const u8* src = (const u8*)buf; u32 done = 0;
    int b = blk_at(in, off / VFS_BLK);
    while (done < n && b >= 0) {
        u32 bo = (off + done) % VFS_BLK;
        u32 c = VFS_BLK - bo; if (c > n - done) c = n - done;
        cpy(&pool[b][bo], src + done, c);
        blk_dirty[b] = 1;
        done += c;
        if (bo + c == VFS_BLK) { int nx = M.fat[b]; b = (nx == FAT_END || nx == FAT_FREE) ? -1 : nx; }
    }
    if (off + done > in.size) in.size = off + done;
    in.mtime = now_sec();
    touch_meta();
    return (int)done;
}
int vfs_truncate(int ino, u32 size) {
    if (!valid_ino(ino)) return VE_NOENT;
    Inode& in = M.ino[ino];
    if (in.type == VT_DIR) return VE_ISDIR;
    if (size > (u32)VFS_NBLK * VFS_BLK) return VE_FBIG;
    if (size > in.size) {                                       // estende com zeros
        u8 z[1] = {0}; u32 old = in.size;
        int r = vfs_write(ino, size - 1, z, 1);
        if (r < 0) return r;
        (void)old; return 0;
    }
    u32 need = (size + VFS_BLK - 1) / VFS_BLK;
    if (need < in.nblk) {
        if (need == 0) { chain_free(in.first); in.first = NONE; }
        else { int last = blk_at(in, need - 1); if (last >= 0) { int nx = M.fat[last]; M.fat[last] = FAT_END; if (nx != FAT_END && nx != FAT_FREE) chain_free(nx); } }
        in.nblk = (u16)need;
    }
    if (size % VFS_BLK && in.nblk) {                            // zera o resto do ultimo bloco (para estender depois com zeros)
        int lb = blk_at(in, in.nblk - 1);
        if (lb >= 0) { for (u32 i = size % VFS_BLK; i < VFS_BLK; i++) pool[lb][i] = 0; blk_dirty[lb] = 1; }
    }
    in.size = size; in.mtime = now_sec();
    touch_meta();
    return 0;
}
int vfs_copy(int src, int dstdir, const char* name) {
    if (!valid_ino(src) || M.ino[src].type != VT_FILE) return VE_INVAL;
    int dst = vfs_lookup(dstdir, name);
    if (dst >= 0) { if (M.ino[dst].type != VT_FILE) return VE_ISDIR; if (dst == src) return VE_INVAL; vfs_truncate(dst, 0); }
    else { dst = vfs_create(dstdir, name, VT_FILE); if (dst < 0) return dst; }
    static u8 tmp[VFS_BLK];
    u32 size = M.ino[src].size, off = 0;
    while (off < size) {
        int r = vfs_read(src, off, tmp, VFS_BLK);
        if (r <= 0) break;
        int w = vfs_write(dst, off, tmp, (u32)r);
        if (w < r) { vfs_unlink(dst); return w < 0 ? w : VE_NOSPC; }
        off += (u32)r;
    }
    return dst;
}
void vfs_stats(u32* files, u32* dirs, u32* used, u32* total) {
    u32 f = 0, d = 0, u = 0;
    for (int i = 0; i < VFS_NINO; i++) { if (M.ino[i].type == VT_FILE) f++; else if (M.ino[i].type == VT_DIR) d++; }
    for (int b = 0; b < VFS_NBLK; b++) if (M.fat[b] != FAT_FREE) u++;
    if (files) *files = f;
    if (dirs) *dirs = d;
    if (used) *used = u;
    if (total) *total = VFS_NBLK;
}

// ---------------------------------------------------------------- ajudas
static int mkpath(const char* path, char* leaf) {       // cria pastas intermediarias; devolve pasta final e o nome em leaf
    int cur = (path[0] == '/') ? VFS_ROOT : VFS_ROOT;
    char comp[VFS_NAME + 1], nxt[VFS_NAME + 1];
    const char* p = next_comp(path, comp); if (!p) return VE_NAMETOOLONG;
    if (!comp[0]) return VE_INVAL;
    for (;;) {
        const char* q = next_comp(p, nxt); if (!q) return VE_NAMETOOLONG;
        if (!nxt[0]) { int n = 0; while (comp[n]) { leaf[n] = comp[n]; n++; } leaf[n] = 0; return cur; }
        int d = vfs_lookup(cur, comp);
        if (d == VE_NOENT) d = vfs_create(cur, comp, VT_DIR);
        if (d < 0) return d;
        if (M.ino[d].type != VT_DIR) return VE_NOTDIR;
        cur = d; int n = 0; while (nxt[n]) { comp[n] = nxt[n]; n++; } comp[n] = 0; p = q;
    }
}
int vfs_write_file(const char* path, const void* data, u32 n) {
    char leaf[VFS_NAME + 1];
    int dir = mkpath(path, leaf); if (dir < 0) return dir;
    int f = vfs_lookup(dir, leaf);
    if (f >= 0) { if (M.ino[f].type != VT_FILE) return VE_ISDIR; vfs_truncate(f, 0); }
    else { f = vfs_create(dir, leaf, VT_FILE); if (f < 0) return f; }
    if (n) { int w = vfs_write(f, 0, data, n); if (w < 0) return w; if ((u32)w < n) return VE_NOSPC; }
    return f;
}
int vfs_append_file(const char* path, const void* data, u32 n) {
    char leaf[VFS_NAME + 1];
    int dir = mkpath(path, leaf); if (dir < 0) return dir;
    int f = vfs_lookup(dir, leaf);
    if (f < 0) f = vfs_create(dir, leaf, VT_FILE);
    if (f < 0) return f;
    if (M.ino[f].type != VT_FILE) return VE_ISDIR;
    int w = vfs_write(f, M.ino[f].size, data, n);
    return w < 0 ? w : f;
}

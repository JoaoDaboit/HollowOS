; boot.asm - ponto de entrada do OS
; O QEMU (ou o GRUB) carrega este arquivo gracas ao header Multiboot.
; Ele ja entrega a CPU em modo protegido de 32 bits, entao so precisamos
; configurar a pilha e chamar o kernel em C++.

MB_MAGIC    equ 0x1BADB002
MB_FLAGS    equ 0x00000000
MB_CHECKSUM equ -(MB_MAGIC + MB_FLAGS)

section .multiboot
align 4
    dd MB_MAGIC
    dd MB_FLAGS
    dd MB_CHECKSUM

section .bss
align 16
stack_bottom:
    resb 65536              ; 64 KB de pilha (TLS e rede usam bastante)
stack_top:

section .text
global _start
extern kernel_main

_start:
    cli                     ; desliga interrupcoes
    mov esp, stack_top      ; configura a pilha
    push ebx                ; argumento 2: ponteiro da info multiboot
    push eax                ; argumento 1: magic do bootloader
    call kernel_main

.hang:
    hlt                     ; se o kernel retornar, para a CPU
    jmp .hang

; evita aviso do linker sobre pilha executavel
section .note.GNU-stack noalloc noexec nowrite progbits

// userland.cpp - HollowOS: modo usuario (anel 3), int 0x80 estilo Linux i386, carregador ELF32 (estatico,
// PIE e dinamico via PT_INTERP), arquivos (VFS), terminal (stdin/stdout) e sockets TCP/UDP.
// Sem paginacao: o programa e carregado no proprio endereco do ELF (identity-map); QEMU precisa de -m 256.
// Um processo por vez, sem fork/exec/threads (veja ROADMAP.md).
#include "userland.h"
#include "vfs.h"
#include "crypto.h"

extern "C" { void* memcpy(void*, const void*, usize); void* memset(void*, int, usize); }
extern "C" void k_console_write(const char* s, int n);            // kernel.cpp
extern "C" int  k_console_read(char* buf, int max);               // le uma linha do teclado (0 = EOF)
extern "C" void k_yield();                                        // mantem a interface viva
extern "C" bool k_abort();                                        // Ctrl+C foi apertado?
extern "C" u32  k_unix_time();

// ---------------- mapa de memoria do processo ----------------
static const u32 USER_LO     = 0x01000000;   // 16 MB: acima do kernel (1 MB + BSS)
static const u32 LOAD_END    = 0x0A000000;   // programa principal cabe em [16 MB, 160 MB)
static const u32 PIE_BASE    = 0x08048000;   // onde carregamos executaveis PIE
static const u32 BRK_END     = 0x0B000000;
static const u32 INTERP_BASE = 0x0B000000;   // ld.so (interpretador dinamico), ate 8 MB
static const u32 INTERP_END  = 0x0B800000;
static const u32 MMAP_LO     = 0x0B800000;
static const u32 MMAP_HI     = 0x0DE00000;
static const u32 STACK_TOP   = 0x0E000000;
static const u32 USER_HI     = 0x0E000000;

// ---------------- GDT / TSS / IDT ----------------
struct __attribute__((packed)) GdtE { u16 lim, base_lo; u8 base_mid, access, gran, base_hi; };
struct __attribute__((packed)) DtPtr { u16 limit; u32 base; };
struct __attribute__((packed)) IdtE { u16 off_lo, sel; u8 zero, attr; u16 off_hi; };
struct __attribute__((packed)) Tss {
    u32 link, esp0, ss0, esp1, ss1, esp2, ss2, cr3, eip, eflags, eax, ecx, edx, ebx, esp, ebp, esi, edi;
    u32 es, cs, ss, ds, fs, gs, ldt; u16 trap, iomap;
};
static GdtE  gdt[9];
static IdtE  idt[256];
static Tss   tss;
static u8    kstack[65536] __attribute__((aligned(16)));

static void gdt_set(int i, u32 base, u32 lim, u8 access, u8 gran) {
    gdt[i].lim = (u16)lim; gdt[i].base_lo = (u16)base; gdt[i].base_mid = (u8)(base >> 16);
    gdt[i].access = access; gdt[i].gran = (u8)(((lim >> 16) & 0x0F) | (gran & 0xF0)); gdt[i].base_hi = (u8)(base >> 24);
}

extern "C" void isr_common();
extern "C" u32 isr_table[32];
extern "C" void isr128();
extern "C" int  enter_user(u32 eip, u32 esp);
extern "C" void leave_user(int code) __attribute__((noreturn));

asm(R"(
.text
.globl isr_common
isr_common:
    pusha
    mov %esp, %eax
    push %eax
    call isr_handler
    add $4, %esp
    popa
    add $8, %esp
    iret
)" "\n.text\n" "isr0: pushl $0\n pushl $0\n jmp isr_common\nisr1: pushl $0\n pushl $1\n jmp isr_common\nisr2: pushl $0\n pushl $2\n jmp isr_common\nisr3: pushl $0\n pushl $3\n jmp isr_common\nisr4: pushl $0\n pushl $4\n jmp isr_common\nisr5: pushl $0\n pushl $5\n jmp isr_common\nisr6: pushl $0\n pushl $6\n jmp isr_common\nisr7: pushl $0\n pushl $7\n jmp isr_common\nisr8: pushl $8\n jmp isr_common\nisr9: pushl $0\n pushl $9\n jmp isr_common\nisr10: pushl $10\n jmp isr_common\nisr11: pushl $11\n jmp isr_common\nisr12: pushl $12\n jmp isr_common\nisr13: pushl $13\n jmp isr_common\nisr14: pushl $14\n jmp isr_common\nisr15: pushl $0\n pushl $15\n jmp isr_common\nisr16: pushl $0\n pushl $16\n jmp isr_common\nisr17: pushl $17\n jmp isr_common\nisr18: pushl $0\n pushl $18\n jmp isr_common\nisr19: pushl $0\n pushl $19\n jmp isr_common\nisr20: pushl $0\n pushl $20\n jmp isr_common\nisr21: pushl $21\n jmp isr_common\nisr22: pushl $0\n pushl $22\n jmp isr_common\nisr23: pushl $0\n pushl $23\n jmp isr_common\nisr24: pushl $0\n pushl $24\n jmp isr_common\nisr25: pushl $0\n pushl $25\n jmp isr_common\nisr26: pushl $0\n pushl $26\n jmp isr_common\nisr27: pushl $0\n pushl $27\n jmp isr_common\nisr28: pushl $0\n pushl $28\n jmp isr_common\nisr29: pushl $29\n jmp isr_common\nisr30: pushl $30\n jmp isr_common\nisr31: pushl $0\n pushl $31\n jmp isr_common\nisr128: pushl $0\n pushl $128\n jmp isr_common\n" R"(
.section .rodata
.globl isr_table
.align 4
isr_table: .long )" "isr0, isr1, isr2, isr3, isr4, isr5, isr6, isr7, isr8, isr9, isr10, isr11, isr12, isr13, isr14, isr15, isr16, isr17, isr18, isr19, isr20, isr21, isr22, isr23, isr24, isr25, isr26, isr27, isr28, isr29, isr30, isr31" R"(

.text
.globl enter_user
enter_user:
    mov 4(%esp), %ecx
    mov 8(%esp), %edx
    push %ebx
    push %esi
    push %edi
    push %ebp
    mov %esp, k_saved_esp
    mov $0x23, %ax
    mov %ax, %ds
    mov %ax, %es
    mov %ax, %fs
    mov %ax, %gs
    push $0x23
    push %edx
    push $0x2
    push $0x1B
    push %ecx
    xor %eax, %eax
    xor %ebx, %ebx
    xor %esi, %esi
    xor %edi, %edi
    xor %ebp, %ebp
    iret

.globl leave_user
leave_user:
    mov 4(%esp), %eax
    mov k_saved_esp, %esp
    pop %ebp
    pop %edi
    pop %esi
    pop %ebx
    mov $0x10, %cx
    mov %cx, %ds
    mov %cx, %es
    mov %cx, %fs
    mov %cx, %gs
    ret
.data
k_saved_esp: .long 0
.text
)");

struct Regs { u32 edi, esi, ebp, esp_d, ebx, edx, ecx, eax, vec, err, eip, cs, eflags, uesp, uss; };

// ---------------- estado do processo ----------------
static u32 brk_start, brk_cur, mmap_cur;
static int unk_count;
static int cwd_ino = 0;
static bool g_busy = false;
static char err_text[160];

static bool uok(u32 p, u32 n) { return p >= USER_LO && p + n >= p && p + n <= USER_HI; }
static void say(const char* s) { int n = 0; while (s[n]) n++; k_console_write(s, n); }
static void say_hex(u32 v) { char b[11] = "0x00000000"; for (int i = 0; i < 8; i++) b[9 - i] = "0123456789abcdef"[(v >> (4 * i)) & 15]; say(b); }
static void say_dec(int v) {
    char b[12]; int n = 11; b[n] = 0;
    bool neg = v < 0; u32 u = neg ? (u32)-v : (u32)v;
    if (!u) b[--n] = '0';
    while (u) { b[--n] = (char)('0' + u % 10); u /= 10; }
    if (neg) b[--n] = '-';
    say(b + n);
}
static bool ustr(u32 p, char* out, int max) {                 // copia string do usuario (valida cada byte)
    for (int i = 0; i < max; i++) {
        if (!uok(p + i, 1)) return false;
        out[i] = *(const char*)(p + i);
        if (!out[i]) return true;
    }
    return false;
}
static void w32(u32 a, u32 v) { if (uok(a, 4)) *(u32*)a = v; }

// ---------------- erros Linux ----------------
enum { E_PERM = 1, E_NOENT = 2, E_SRCH = 3, E_BADF = 9, E_CHILD = 10, E_AGAIN = 11, E_NOMEM = 12, E_ACCES = 13, E_FAULT = 14, E_EXIST = 17,
       E_NODEV = 19, E_NOTDIR = 20, E_ISDIR = 21, E_INVAL = 22, E_MFILE = 24, E_NOTTY = 25, E_NOSPC = 28, E_SPIPE = 29, E_RANGE = 34, E_NOSYS = 38,
       E_NOTSOCK = 88, E_AFNOSUPPORT = 97, E_NETUNREACH = 101, E_TIMEDOUT = 110, E_CONNREFUSED = 111, E_OPNOTSUPP = 95, E_NOTCONN = 107 };

// ---------------- descritores de arquivo ----------------
enum { FK_NONE = 0, FK_CON, FK_FILE, FK_DIR, FK_NULL, FK_ZERO, FK_RAND, FK_TCP, FK_UDP };
enum { O_ACCMODE = 3, O_WRONLY = 1, O_RDWR = 2, O_CREAT = 0x40, O_EXCL = 0x80, O_TRUNC = 0x200, O_APPEND = 0x400, O_NONBLOCK = 0x800, O_DIRECTORY = 0x10000 };
struct Fd { u8 kind; int ino; u32 off; u32 oflags; u8 peer_ip[4]; u16 peer_port; bool has_peer; bool connected; };
static const int NFD = 64;
static Fd fds[NFD];
static char inbuf[512]; static int inpos, inlen; static bool in_eof;

static int fd_alloc(int from = 0) { for (int i = from; i < NFD; i++) if (fds[i].kind == FK_NONE) return i; return -E_MFILE; }
static Fd* fd_get(int fd) { return (fd >= 0 && fd < NFD && fds[fd].kind != FK_NONE) ? &fds[fd] : 0; }
static bool sock_shared(int self, u8 kind) { for (int i = 0; i < NFD; i++) if (i != self && fds[i].kind == kind) return true; return false; }

static void close_fd(int i) {
    Fd& f = fds[i];
    if (f.kind == FK_TCP && !sock_shared(i, FK_TCP)) tcp_close();
    if (f.kind == FK_UDP && !sock_shared(i, FK_UDP)) udp_close();
    f.kind = FK_NONE;
}

static int console_read(u32 buf, u32 n, bool nonblock) {
    (void)nonblock;
    if (n == 0) return 0;
    if (inpos >= inlen) {
        if (in_eof) return 0;
        inlen = k_console_read(inbuf, sizeof inbuf); inpos = 0;
        if (inlen <= 0) { inlen = 0; in_eof = true; return 0; }
    }
    u32 k = (u32)(inlen - inpos); if (k > n) k = n;
    memcpy((void*)buf, inbuf + inpos, k); inpos += (int)k;
    return (int)k;
}

static int sock_recv(Fd& f, u32 buf, u32 n, u32 from_addr) {
    bool nb = f.oflags & O_NONBLOCK;
    if (f.kind == FK_TCP) {
        int r = tcp_recv((u8*)buf, (int)n, nb ? 0 : 60000);
        if (r > 0) return r;
        if (r == 0) return 0;
        return nb ? -E_AGAIN : -E_TIMEDOUT;
    }
    u8 ip[4]; u16 port = 0;
    int r = udp_recv((u8*)buf, (int)n, ip, &port, nb ? 0 : 10000);
    if (r < 0) return nb ? -E_AGAIN : -E_TIMEDOUT;
    if (from_addr && uok(from_addr, 16)) { u8* a = (u8*)from_addr; memset(a, 0, 16); a[0] = 2; a[2] = (u8)(port >> 8); a[3] = (u8)port; memcpy(a + 4, ip, 4); }
    return r;
}
static int sock_send(Fd& f, u32 buf, u32 n, const u8* ip, u16 port) {
    if (f.kind == FK_TCP) { int r = tcp_send((const u8*)buf, (int)n); return r < 0 ? -E_NOTCONN : r; }
    if (!ip) { if (!f.has_peer) return -E_NOTCONN; ip = f.peer_ip; port = f.peer_port; }
    if (udp_local_port() == 0 || !f.connected) { udp_open(0); f.connected = true; }
    return udp_send(ip, port, (const u8*)buf, (int)n) ? (int)n : -E_NETUNREACH;
}

static int fd_read(int fd, u32 buf, u32 n) {
    Fd* f = fd_get(fd); if (!f) return -E_BADF;
    if (n && !uok(buf, n)) return -E_FAULT;
    if ((f->oflags & O_ACCMODE) == O_WRONLY) return -E_BADF;
    switch (f->kind) {
    case FK_CON:  return console_read(buf, n, f->oflags & O_NONBLOCK);
    case FK_FILE: { int r = vfs_read(f->ino, f->off, (void*)buf, n); if (r > 0) f->off += (u32)r; return r; }
    case FK_DIR:  return -E_ISDIR;
    case FK_NULL: return 0;
    case FK_ZERO: memset((void*)buf, 0, n); return (int)n;
    case FK_RAND: rng_bytes((u8*)buf, n); return (int)n;
    case FK_TCP: case FK_UDP: return sock_recv(*f, buf, n, 0);
    }
    return -E_BADF;
}
static int fd_write(int fd, u32 buf, u32 n) {
    Fd* f = fd_get(fd); if (!f) return -E_BADF;
    if (n && !uok(buf, n)) return -E_FAULT;
    switch (f->kind) {
    case FK_CON:  k_console_write((const char*)buf, (int)n); k_yield(); return (int)n;
    case FK_FILE: {
        if ((f->oflags & O_ACCMODE) == 0) return -E_BADF;
        if (f->oflags & O_APPEND) f->off = vfs_size(f->ino);
        int r = vfs_write(f->ino, f->off, (const void*)buf, n); if (r > 0) f->off += (u32)r; return r;
    }
    case FK_DIR:  return -E_ISDIR;
    case FK_NULL: case FK_ZERO: case FK_RAND: return (int)n;
    case FK_TCP: case FK_UDP: return sock_send(*f, buf, n, 0, 0);
    }
    return -E_BADF;
}

// ---------------- caminhos ----------------
static int resolve_at(int dirfd, const char* path) {
    if (path[0] == '/' || dirfd == -100) return vfs_resolve(path, cwd_ino);
    Fd* f = fd_get(dirfd); if (!f || f->kind != FK_DIR) return -E_BADF;
    return vfs_resolve(path, f->ino);
}
static bool is_dev(const char* p, const char* n) { int i = 0; while (n[i] && p[i] == n[i]) i++; return !n[i] && !p[i]; }
static int dev_kind(const char* p) {
    if (is_dev(p, "/dev/null")) return FK_NULL;
    if (is_dev(p, "/dev/zero")) return FK_ZERO;
    if (is_dev(p, "/dev/urandom") || is_dev(p, "/dev/random")) return FK_RAND;
    if (is_dev(p, "/dev/tty") || is_dev(p, "/dev/console") || is_dev(p, "/dev/stdin") || is_dev(p, "/dev/stdout") || is_dev(p, "/dev/stderr")) return FK_CON;
    return FK_NONE;
}
static int sys_open(int dirfd, u32 upath, u32 flags, u32 mode) {
    (void)mode;
    char path[256]; if (!ustr(upath, path, sizeof path)) return -E_FAULT;
    int fd = fd_alloc(); if (fd < 0) return fd;
    int dk = dev_kind(path);
    Fd& f = fds[fd]; memset(&f, 0, sizeof f); f.oflags = flags;
    if (dk != FK_NONE) { f.kind = (u8)dk; return fd; }
    int ino = resolve_at(dirfd, path);
    if (ino == VE_NOENT && (flags & O_CREAT)) {
        char leaf[VFS_NAME + 1];
        int dir;
        if (path[0] == '/' || dirfd == -100) dir = vfs_parent_of(path, cwd_ino, leaf);
        else { Fd* d = fd_get(dirfd); dir = (d && d->kind == FK_DIR) ? vfs_parent_of(path, d->ino, leaf) : -E_BADF; }
        if (dir < 0) return dir;
        ino = vfs_create(dir, leaf, VT_FILE);
        if (ino < 0) return ino;
    } else if (ino >= 0 && (flags & O_CREAT) && (flags & O_EXCL)) return -E_EXIST;
    if (ino < 0) return ino;
    int t = vfs_type(ino);
    if (t == VT_DIR) {
        if ((flags & O_ACCMODE) != 0) return -E_ISDIR;
        f.kind = FK_DIR; f.ino = ino; f.off = 0; return fd;
    }
    if (flags & O_DIRECTORY) return -E_NOTDIR;
    if ((flags & O_TRUNC) && (flags & O_ACCMODE) != 0) vfs_truncate(ino, 0);
    f.kind = FK_FILE; f.ino = ino; f.off = 0;
    return fd;
}

// struct stat64 (96 bytes) do Linux i386
static void put_le32(u8* p, u32 v) { p[0] = (u8)v; p[1] = (u8)(v >> 8); p[2] = (u8)(v >> 16); p[3] = (u8)(v >> 24); }
static int fill_stat(u32 buf, int kind, int ino) {
    if (!uok(buf, 96)) return -E_FAULT;
    u8* s = (u8*)buf; memset(s, 0, 96);
    u32 mode, size = 0, mt = 0;
    if (kind == FK_DIR || (kind == FK_FILE && vfs_type(ino) == VT_DIR)) { mode = 0040755; size = 4096; mt = vfs_mtime(ino); }
    else if (kind == FK_FILE) { mode = 0100755; size = vfs_size(ino); mt = vfs_mtime(ino); }
    else if (kind == FK_TCP || kind == FK_UDP) mode = 0140777;
    else mode = 0020666;
    put_le32(s + 12, (u32)ino + 1); put_le32(s + 16, mode); put_le32(s + 20, 1);
    put_le32(s + 44, size); put_le32(s + 52, 4096); put_le32(s + 56, (size + 511) / 512);
    put_le32(s + 64, mt); put_le32(s + 72, mt); put_le32(s + 80, mt); put_le32(s + 88, (u32)ino + 1);
    return 0;
}
static int sys_stat(int dirfd, u32 upath, u32 buf) {
    char path[256]; if (!ustr(upath, path, sizeof path)) return -E_FAULT;
    int dk = dev_kind(path); if (dk != FK_NONE) return fill_stat(buf, dk, 0);
    int ino = resolve_at(dirfd, path); if (ino < 0) return ino;
    return fill_stat(buf, vfs_type(ino) == VT_DIR ? FK_DIR : FK_FILE, ino);
}
static int sys_getdents64(int fd, u32 buf, u32 count) {
    Fd* f = fd_get(fd); if (!f || f->kind != FK_DIR) return -E_BADF;
    if (!uok(buf, count)) return -E_FAULT;
    u32 o = 0;
    for (;;) {
        char name[VFS_NAME + 1]; int ino; u8 type;
        u32 idx = f->off;
        if (idx == 0) { name[0] = '.'; name[1] = 0; ino = f->ino; type = 4; }
        else if (idx == 1) { name[0] = '.'; name[1] = '.'; name[2] = 0; ino = vfs_parent(f->ino); type = 4; }
        else {
            int c = vfs_nth_child(f->ino, (int)idx - 2); if (c < 0) break;
            const char* nm = vfs_name(c); int k = 0; while (nm[k]) { name[k] = nm[k]; k++; } name[k] = 0;
            ino = c; type = vfs_type(c) == VT_DIR ? 4 : 8;
        }
        int nl = 0; while (name[nl]) nl++;
        u32 reclen = (19 + (u32)nl + 1 + 7) & ~7u;
        if (o + reclen > count) { if (o == 0) return -E_INVAL; break; }
        u8* d = (u8*)(buf + o); memset(d, 0, reclen);
        put_le32(d, (u32)ino + 1); put_le32(d + 8, idx + 1); d[16] = (u8)reclen; d[17] = (u8)(reclen >> 8); d[18] = type;
        memcpy(d + 19, name, nl + 1);
        o += reclen; f->off++;
    }
    return (int)o;
}

// ---------------- tempo ----------------
static void sleep_ms(u32 ms) {
    u32 t0 = net_ms();
    while (net_ms() - t0 < ms) { k_yield(); if (k_abort()) leave_user(130); asm volatile("pause"); }
}
static u32 g_boot_unix = 0, g_boot_ms = 0;
static u32 now_unix() { return g_boot_unix + (net_ms() - g_boot_ms) / 1000; }

// ---------------- sockets ----------------
static bool net_ready() { return net.present && net.has_ip; }
static int sys_socket(u32 domain, u32 type, u32) {
    if (domain != 2) return -E_AFNOSUPPORT;
    u32 t = type & 0xF; if (t != 1 && t != 2) return -E_INVAL;
    int fd = fd_alloc(); if (fd < 0) return fd;
    if (t == 1 && sock_shared(-1, FK_TCP)) return -E_MFILE;      // so ha 1 conexao TCP no HollowOS
    if (t == 2 && sock_shared(-1, FK_UDP)) return -E_MFILE;
    Fd& f = fds[fd]; memset(&f, 0, sizeof f); f.kind = (u8)(t == 1 ? FK_TCP : FK_UDP); f.oflags = (type & 0x800) ? O_NONBLOCK : 0;
    return fd;
}
static int sys_connect(int fd, u32 addr, u32 len) {
    Fd* f = fd_get(fd); if (!f || (f->kind != FK_TCP && f->kind != FK_UDP)) return -E_NOTSOCK;
    if (len < 8 || !uok(addr, 8)) return -E_FAULT;
    const u8* a = (const u8*)addr; if (a[0] != 2) return -E_AFNOSUPPORT;
    u16 port = (u16)((a[2] << 8) | a[3]); u8 ip[4]; memcpy(ip, a + 4, 4);
    if (!net_ready()) return -E_NETUNREACH;
    if (f->kind == FK_UDP) { memcpy(f->peer_ip, ip, 4); f->peer_port = port; f->has_peer = true; if (!f->connected) { udp_open(0); f->connected = true; } return 0; }
    if (!tcp_connect(ip, port, 8000)) return -E_CONNREFUSED;
    f->connected = true; return 0;
}
static int sock_call(u32 call, const u32* a) {                  // a[0..5] ja validados e copiados
    switch (call) {
    case 1: return sys_socket(a[0], a[1], a[2]);
    case 2: {                                                    // bind
        Fd* f = fd_get((int)a[0]); if (!f) return -E_BADF;
        if (f->kind == FK_UDP) { u16 port = 0; if (a[2] >= 4 && uok(a[1], 4)) { const u8* s = (const u8*)a[1]; port = (u16)((s[2] << 8) | s[3]); } if (!f->connected && udp_open(port)) f->connected = true; return 0; }
        return 0;
    }
    case 3: return sys_connect((int)a[0], a[1], a[2]);
    case 4: case 5: return -E_OPNOTSUPP;                         // listen / accept
    case 6: case 7: { Fd* f = fd_get((int)a[0]); if (!f) return -E_BADF; if (uok(a[1], 16)) { u8* s = (u8*)a[1]; memset(s, 0, 16); s[0] = 2; if (call == 6) { s[2] = (u8)(udp_local_port() >> 8); s[3] = (u8)udp_local_port(); memcpy(s + 4, net.ip, 4); } else if (f->has_peer) { s[2] = (u8)(f->peer_port >> 8); s[3] = (u8)f->peer_port; memcpy(s + 4, f->peer_ip, 4); } if (uok(a[2], 4)) w32(a[2], 16); } return 0; }
    case 9: { Fd* f = fd_get((int)a[0]); if (!f || (f->kind != FK_TCP && f->kind != FK_UDP)) return -E_NOTSOCK; if (a[2] && !uok(a[1], a[2])) return -E_FAULT; return sock_send(*f, a[1], a[2], 0, 0); }
    case 11: {                                                   // sendto
        Fd* f = fd_get((int)a[0]); if (!f || (f->kind != FK_TCP && f->kind != FK_UDP)) return -E_NOTSOCK;
        if (a[2] && !uok(a[1], a[2])) return -E_FAULT;
        if (a[4] && a[5] >= 8 && uok(a[4], 8) && f->kind == FK_UDP) { const u8* s = (const u8*)a[4]; return sock_send(*f, a[1], a[2], s + 4, (u16)((s[2] << 8) | s[3])); }
        return sock_send(*f, a[1], a[2], 0, 0);
    }
    case 10: case 12: {                                          // recv / recvfrom
        Fd* f = fd_get((int)a[0]); if (!f || (f->kind != FK_TCP && f->kind != FK_UDP)) return -E_NOTSOCK;
        if (a[2] && !uok(a[1], a[2])) return -E_FAULT;
        int r = sock_recv(*f, a[1], a[2], call == 12 ? a[4] : 0);
        if (r >= 0 && call == 12 && a[4] && a[5] && uok(a[5], 4)) w32(a[5], 16);
        return r;
    }
    case 13: return 0;                                           // shutdown
    case 14: return 0;                                           // setsockopt
    case 15: if (a[3] && uok(a[3], 4)) w32(a[3], 0); if (a[4] && uok(a[4], 4)) w32(a[4], 4); return 0;   // getsockopt (SO_ERROR = 0)
    }
    return -E_NOSYS;
}

// ---------------- poll ----------------
static short poll_ready(const Fd* f, short ev) {
    short r = 0;
    if (f->kind == FK_TCP) { int av = tcp_avail(); if ((ev & 1) && av != 0) r |= 1; if (av < 0) r |= 0x10; if (ev & 4) r |= 4; }
    else if (f->kind == FK_UDP) { if ((ev & 1) && udp_avail() > 0) r |= 1; if (ev & 4) r |= 4; }
    else r = (short)(ev & 5);
    return r;
}
static int sys_poll(u32 ufds, u32 nfds, int timeout) {
    if (nfds > 64 || !uok(ufds, nfds * 8)) return -E_INVAL;
    u32 t0 = net_ms();
    for (;;) {
        int cnt = 0;
        for (u32 i = 0; i < nfds; i++) {
            u8* p = (u8*)(ufds + i * 8); int fd = (int)(p[0] | (p[1] << 8) | (p[2] << 16) | (p[3] << 24)); short ev = (short)(p[4] | (p[5] << 8)); short rv = 0;
            if (fd >= 0) { Fd* f = fd_get(fd); rv = f ? poll_ready(f, ev) : 0x20; }
            p[6] = (u8)rv; p[7] = (u8)(rv >> 8); if (rv) cnt++;
        }
        if (cnt || timeout == 0) return cnt;
        if (timeout > 0 && (int)(net_ms() - t0) >= timeout) return 0;
        k_yield(); if (k_abort()) leave_user(130);
    }
}

// ---------------- chamadas de sistema (ABI Linux i386) ----------------
static int sys_set_thread_area(u32 p) {
    if (!uok(p, 16)) return -E_FAULT;
    u32* d = (u32*)p;
    int e = (int)d[0];
    if (e == -1) { e = 6; }
    if (e < 6 || e > 8) return -E_INVAL;
    u32 fl = d[3];
    bool pages = (fl >> 4) & 1, big = fl & 1, absent = (fl >> 5) & 1;
    gdt_set(e, d[1], d[2], absent ? 0x00 : 0xF2, (u8)((pages ? 0x80 : 0) | (big ? 0x40 : 0)));
    d[0] = (u32)e;
    return 0;
}
static int sys_mmap(u32 addr, u32 len, u32 prot, u32 flags, int fd, u32 pgoff) {
    (void)prot;
    u32 n = (len + 4095) & ~4095u;
    if (len == 0 || n < len) return -E_INVAL;
    u32 p;
    if (flags & 0x10) {                                           // MAP_FIXED
        if ((addr & 4095) || addr < USER_LO || addr + n > USER_HI || addr + n < addr) return -E_INVAL;
        p = addr;
    } else {
        if (mmap_cur + n > MMAP_HI || mmap_cur + n < mmap_cur) return -E_NOMEM;
        p = mmap_cur; mmap_cur += n;
    }
    memset((void*)p, 0, n);
    if (!(flags & 0x20)) {                                        // arquivo: copia o conteudo (mapeamento privado)
        Fd* f = fd_get(fd); if (!f || f->kind != FK_FILE) return -E_BADF;
        int r = vfs_read(f->ino, pgoff * 4096, (void*)p, len); if (r < 0) return r;
    }
    return (int)p;
}
static int sys_munmap(u32 a, u32 len) {
    u32 n = (len + 4095) & ~4095u;
    if (a >= MMAP_LO && a + n == mmap_cur) mmap_cur = a;           // libera so o topo (alocador simples)
    return 0;
}
static void put_time32(u32 a, u32 sec, u32 sub) { if (uok(a, 8)) { w32(a, sec); w32(a + 4, sub); } }

static int syscall_dispatch(Regs* r) {
    u32 nr = r->eax, a = r->ebx, b = r->ecx, c = r->edx, d = r->esi, e = r->edi;
    if (k_abort()) leave_user(130);
    switch (nr) {
    case 1: case 252: leave_user((int)(a & 0xFF));
    case 3:   return fd_read((int)a, b, c);
    case 4:   return fd_write((int)a, b, c);
    case 5:   return sys_open(-100, a, b, c);
    case 295: return sys_open((int)a, b, c, d);
    case 8:   return sys_open(-100, a, O_CREAT | O_TRUNC | O_WRONLY, b);
    case 6:   { Fd* f = fd_get((int)a); if (!f) return -E_BADF; close_fd((int)a); return 0; }
    case 145: case 146: {                                          // readv / writev
        if (!uok(b, c * 8)) return -E_FAULT;
        int tot = 0; const u32* v = (const u32*)b;
        for (u32 i = 0; i < c; i++) {
            int w = nr == 146 ? fd_write((int)a, v[2*i], v[2*i+1]) : fd_read((int)a, v[2*i], v[2*i+1]);
            if (w < 0) return tot ? tot : w;
            tot += w; if ((u32)w < v[2*i+1]) break;
        }
        return tot;
    }
    case 180: case 181: {                                          // pread64 / pwrite64
        Fd* f = fd_get((int)a); if (!f || f->kind != FK_FILE) return -E_SPIPE;
        if (!uok(b, c)) return -E_FAULT;
        if (nr == 180) return vfs_read(f->ino, d, (void*)b, c);
        return vfs_write(f->ino, d, (const void*)b, c);
    }
    case 19: case 140: {                                           // lseek / _llseek
        int fd = (int)a; Fd* f = fd_get(fd); if (!f) return -E_BADF;
        if (f->kind != FK_FILE && f->kind != FK_DIR) return -E_SPIPE;
        long off; u32 wh;
        if (nr == 19) { off = (int)b; wh = c; } else { off = (int)c; wh = e; }
        long base = wh == 0 ? 0 : wh == 1 ? (long)f->off : (long)(f->kind == FK_FILE ? vfs_size(f->ino) : 0);
        long np = base + off; if (np < 0) return -E_INVAL;
        f->off = (u32)np;
        if (nr == 140) { if (!uok(d, 8)) return -E_FAULT; w32(d, (u32)np); w32(d + 4, 0); return 0; }
        return (int)np;
    }
    case 20: return 1;
    case 64: return 0;
    case 224: return 1;
    case 24: case 47: case 49: case 50: case 199: case 200: case 201: case 202: case 208: case 209: case 210: return 0;
    case 45: {                                                     // brk
        if (a == 0 || a < brk_start || a > BRK_END) return (int)brk_cur;
        if (a > brk_cur) memset((void*)brk_cur, 0, a - brk_cur);
        brk_cur = a; return (int)brk_cur;
    }
    case 192: return sys_mmap(a, b, c, d, (int)e, r->ebp);
    case 90: { if (!uok(a, 24)) return -E_FAULT; const u32* m = (const u32*)a; return sys_mmap(m[0], m[1], m[2], m[3], (int)m[4], m[5] / 4096); }
    case 91:  return sys_munmap(a, b);
    case 125: case 219: case 150: case 151: case 152: case 153: return 0;      // mprotect, madvise, mlock...
    case 163: return -E_NOMEM;                                     // mremap: a libc cai para mmap+copia
    case 33: case 307: { char p[256]; u32 up = nr == 33 ? a : b; if (!ustr(up, p, sizeof p)) return -E_FAULT; if (dev_kind(p) != FK_NONE) return 0; int i = resolve_at(nr == 33 ? -100 : (int)a, p); return i < 0 ? i : 0; }
    case 12: { char p[256]; if (!ustr(a, p, sizeof p)) return -E_FAULT; int i = vfs_resolve(p, cwd_ino); if (i < 0) return i; if (vfs_type(i) != VT_DIR) return -E_NOTDIR; cwd_ino = i; return 0; }
    case 183: { char p[256]; int n = vfs_path(cwd_ino, p, sizeof p); if (n < 0) return n; if ((u32)n + 1 > b) return -E_RANGE; if (!uok(a, n + 1)) return -E_FAULT; memcpy((void*)a, p, n + 1); return n + 1; }
    case 39: case 296: {                                           // mkdir / mkdirat
        char p[256]; u32 up = nr == 39 ? a : b; if (!ustr(up, p, sizeof p)) return -E_FAULT;
        char leaf[VFS_NAME + 1]; int dir = vfs_parent_of(p, cwd_ino, leaf); if (dir < 0) return dir;
        if (!leaf[0]) return -E_EXIST;
        int n = vfs_create(dir, leaf, VT_DIR); return n < 0 ? n : 0;
    }
    case 10: case 40: case 301: {                                  // unlink / rmdir / unlinkat
        char p[256]; u32 up = nr == 301 ? b : a; if (!ustr(up, p, sizeof p)) return -E_FAULT;
        int i = resolve_at(nr == 301 ? (int)a : -100, p); if (i < 0) return i;
        if (nr == 10 && vfs_type(i) == VT_DIR) return -E_ISDIR;
        if (nr == 40 && vfs_type(i) != VT_DIR) return -E_NOTDIR;
        return vfs_unlink(i);
    }
    case 38: {                                                     // rename
        char p1[256], p2[256]; if (!ustr(a, p1, sizeof p1) || !ustr(b, p2, sizeof p2)) return -E_FAULT;
        int src = vfs_resolve(p1, cwd_ino); if (src < 0) return src;
        char leaf[VFS_NAME + 1]; int dir = vfs_parent_of(p2, cwd_ino, leaf); if (dir < 0) return dir;
        int ex = vfs_lookup(dir, leaf); if (ex >= 0 && ex != src) { if (vfs_type(ex) == VT_DIR) return -E_ISDIR; vfs_unlink(ex); }
        return vfs_rename(src, dir, leaf);
    }
    case 85: case 305: return -E_INVAL;                            // readlink: nao ha links simbolicos
    case 15: case 94: case 182: case 212: case 60: case 61: return 0;   // chmod, fchmod, chown, umask...
    case 92: case 93: case 193: case 194: {                        // truncate / ftruncate
        int ino;
        if (nr == 93 || nr == 194) { Fd* f = fd_get((int)a); if (!f || f->kind != FK_FILE) return -E_BADF; ino = f->ino; }
        else { char p[256]; if (!ustr(a, p, sizeof p)) return -E_FAULT; ino = vfs_resolve(p, cwd_ino); if (ino < 0) return ino; }
        return vfs_truncate(ino, nr == 92 || nr == 93 ? b : b);
    }
    case 118: case 148: case 36: return 0;                         // fsync, fdatasync, sync
    case 106: case 107: case 195: case 196: return sys_stat(-100, a, b);
    case 197: case 108: { Fd* f = fd_get((int)a); if (!f) return -E_BADF; if (nr == 108) return -E_NOSYS; return fill_stat(b, f->kind, f->ino); }
    case 300: {                                                    // fstatat64
        if (d & 0x1000) { Fd* f = fd_get((int)a); if (!f) return -E_BADF; return fill_stat(c, f->kind, f->ino); }
        return sys_stat((int)a, b, c);
    }
    case 220: return sys_getdents64((int)a, b, c);
    case 41: { Fd* f = fd_get((int)a); if (!f) return -E_BADF; int n = fd_alloc(); if (n < 0) return n; fds[n] = *f; fds[n].oflags &= ~0x80000u; return n; }
    case 63: { Fd* f = fd_get((int)a); if (!f) return -E_BADF; if ((int)b < 0 || (int)b >= NFD) return -E_BADF; if (a == b) return (int)b; if (fds[b].kind) close_fd((int)b); fds[b] = *f; return (int)b; }
    case 55: case 221: {                                           // fcntl
        Fd* f = fd_get((int)a); if (!f) return -E_BADF;
        switch (b) {
        case 0: case 1030: { int n = fd_alloc((int)c); if (n < 0) return n; fds[n] = *f; return n; }
        case 1: return 0; case 2: return 0;
        case 3: return (int)f->oflags;
        case 4: f->oflags = (f->oflags & ~(u32)(O_NONBLOCK | O_APPEND)) | (c & (O_NONBLOCK | O_APPEND)); return 0;
        }
        return -E_INVAL;
    }
    case 54: {                                                     // ioctl
        Fd* f = fd_get((int)a); if (!f) return -E_BADF;
        if (f->kind == FK_CON) {
            if (b == 0x5413) { if (!uok(d, 0) || !uok(c, 8)) return -E_FAULT; u8* w = (u8*)c; w[0] = 34; w[1] = 0; w[2] = 78; w[3] = 0; w[4] = w[5] = w[6] = w[7] = 0; return 0; }
            if (b == 0x5401) { if (!uok(c, 36)) return -E_FAULT; u8* t = (u8*)c; memset(t, 0, 36); put_le32(t, 0x500); put_le32(t + 4, 5); put_le32(t + 8, 0xBF); put_le32(t + 12, 0x8A3B); t[17] = 3; t[18] = 0x1C; t[19] = 0x7F; t[20] = 0x15; t[21] = 4; return 0; }
            if (b == 0x5402 || b == 0x5403 || b == 0x5404) return 0;
            if (b == 0x540F) return 1;
            return -E_NOTTY;
        }
        if (b == 0x5421) { if (!uok(c, 4)) return -E_FAULT; if (*(int*)c) f->oflags |= O_NONBLOCK; else f->oflags &= ~(u32)O_NONBLOCK; return 0; }
        if (b == 0x541B) { if (!uok(c, 4)) return -E_FAULT; int av = (f->kind == FK_TCP) ? tcp_avail() : 0; w32(c, av > 0 ? (u32)av : 0); return 0; }
        return -E_NOTTY;
    }
    case 102: { if (!uok(b, 24)) {} u32 args[6] = {0,0,0,0,0,0}; if (b && uok(b, 4)) { for (int i = 0; i < 6 && uok(b + 4 * i, 4); i++) args[i] = *(u32*)(b + 4 * i); } return sock_call(a, args); }
    case 359: { u32 x[6] = {a, b, c, 0, 0, 0}; return sock_call(1, x); }
    case 361: { u32 x[6] = {a, b, c, 0, 0, 0}; return sock_call(2, x); }
    case 362: { u32 x[6] = {a, b, c, 0, 0, 0}; return sock_call(3, x); }
    case 366: { u32 x[6] = {a, b, c, d, e, 0}; return sock_call(14, x); }
    case 365: { u32 x[6] = {a, b, c, d, e, 0}; return sock_call(15, x); }
    case 367: { u32 x[6] = {a, b, c, 0, 0, 0}; return sock_call(6, x); }
    case 368: { u32 x[6] = {a, b, c, 0, 0, 0}; return sock_call(7, x); }
    case 369: { u32 x[6] = {a, b, c, d, e, r->ebp}; return sock_call(11, x); }
    case 371: { u32 x[6] = {a, b, c, d, e, r->ebp}; return sock_call(12, x); }
    case 373: return 0;
    case 168: return sys_poll(a, b, (int)c);
    case 142: return -E_NOSYS;                                     // select: musl/glibc usam poll quando preciso
    case 78: put_time32(a, now_unix(), (net_ms() % 1000) * 1000); return 0;
    case 13: if (a && uok(a, 4)) w32(a, now_unix()); return (int)now_unix();
    case 265: {                                                    // clock_gettime
        u32 ms = net_ms();
        if (a == 1 || a == 7) put_time32(b, ms / 1000, (ms % 1000) * 1000000); else put_time32(b, now_unix(), (ms % 1000) * 1000000);
        return 0;
    }
    case 266: put_time32(b, 0, 1000000); return 0;                 // clock_getres
    case 162: { if (!uok(a, 8)) return -E_FAULT; u32 sec = *(u32*)a, ns = *(u32*)(a + 4); sleep_ms(sec * 1000 + ns / 1000000); return 0; }
    case 267: { if (!uok(c, 8)) return -E_FAULT; u32 sec = *(u32*)c, ns = *(u32*)(c + 4); sleep_ms(sec * 1000 + ns / 1000000); return 0; }
    case 158: k_yield(); return 0;
    case 43: { if (a && uok(a, 16)) memset((void*)a, 0, 16); return (int)(net_ms() / 10); }
    case 77: if (uok(b, 72)) memset((void*)b, 0, 72); return 0;
    case 116: { if (!uok(a, 64)) return -E_FAULT; u8* s = (u8*)a; memset(s, 0, 64); put_le32(s, net_ms() / 1000); put_le32(s + 16, 224u << 20); put_le32(s + 20, 100u << 20); put_le32(s + 52, 1); return 0; }
    case 122: {                                                    // uname
        if (!uok(a, 390)) return -E_FAULT;
        char* u = (char*)a; memset(u, 0, 390);
        const char* f[5] = { "Linux", "hollow", "4.14.0-hollow", "#1 HollowOS", "i686" };
        for (int i = 0; i < 5; i++) { int k = 0; while (f[i][k]) { u[i * 65 + k] = f[i][k]; k++; } }
        return 0;
    }
    case 191: case 76: { if (!uok(b, 8)) return -E_FAULT; w32(b, a == 3 ? 8u << 20 : 0xFFFFFFFFu); w32(b + 4, 0xFFFFFFFFu); return 0; }
    case 340: { if (c && uok(c, 16)) { w32(c, 0xFFFFFFFFu); w32(c + 4, 0xFFFFFFFFu); w32(c + 8, 0xFFFFFFFFu); w32(c + 12, 0xFFFFFFFFu); } return 0; }
    case 243: return sys_set_thread_area(a);
    case 258: return 1;
    case 172: return 0;                                            // prctl
    case 174: case 175: case 186: case 311: case 73: case 72: return 0;       // sinais: aceitos e ignorados
    case 37: return 0;
    case 270: case 238: if (c == 6 || c == 9 || c == 11 || c == 15 || b == 6 || b == 9 || b == 11 || b == 15) leave_user(128 + (int)(nr == 270 ? c : b)); return 0;
    case 240: return 0;                                            // futex (1 thread: nunca espera de verdade)
    case 224 + 0x1000: return 0;
    case 355: { if (!uok(a, b)) return -E_FAULT; rng_bytes((u8*)a, b); return (int)b; }
    case 114: return -E_CHILD;                                     // wait4
    case 2: case 120: case 190: case 11: return -E_NOSYS;          // fork, clone, vfork, execve: ainda nao
    case 42: case 331: return -E_NOSYS;                            // pipe
    }
    if (unk_count < 12) { unk_count++; say("[syscall "); say_dec((int)nr); say(" ainda nao suportada]\n"); }
    return -E_NOSYS;
}

static const char* const EXC[] = {
    "divisao por zero", "debug", "NMI", "breakpoint", "overflow", "limite (bound)", "instrucao invalida",
    "FPU indisponivel", "falha dupla", "coprocessador", "TSS invalido", "segmento ausente", "falha de pilha",
    "protecao geral (GPF)", "falha de pagina", "reservado", "erro x87"
};

extern "C" void isr_handler(Regs* r) {
    if (r->vec == 0x80) { r->eax = (u32)syscall_dispatch(r); return; }
    if ((r->cs & 3) == 3) {
        say("\n[processo morto: excecao ");
        say_dec((int)r->vec);
        if (r->vec < 17) { say(" - "); say(EXC[r->vec]); }
        say(" em eip="); say_hex(r->eip); say("]\n");
        leave_user(-1000 - (int)r->vec);
    }
    for (;;) asm volatile("cli; hlt");
}

// ---------------- inicializacao ----------------
void user_init() {
    gdt_set(0, 0, 0, 0, 0);
    gdt_set(1, 0, 0xFFFFF, 0x9A, 0xCF);
    gdt_set(2, 0, 0xFFFFF, 0x92, 0xCF);
    gdt_set(3, 0, 0xFFFFF, 0xFA, 0xCF);
    gdt_set(4, 0, 0xFFFFF, 0xF2, 0xCF);
    memset(&tss, 0, sizeof tss);
    tss.ss0 = 0x10; tss.esp0 = (u32)(usize)(kstack + sizeof kstack); tss.iomap = sizeof(Tss);
    gdt_set(5, (u32)(usize)&tss, sizeof(Tss) - 1, 0x89, 0x00);
    for (int i = 6; i < 9; i++) gdt_set(i, 0, 0, 0, 0);

    DtPtr gp = { (u16)(sizeof(gdt) - 1), (u32)(usize)gdt };
    asm volatile("lgdt %0" :: "m"(gp));
    asm volatile("ljmp $0x08, $1f\n1:\n mov $0x10,%%ax\n mov %%ax,%%ds\n mov %%ax,%%es\n"
                 " mov %%ax,%%fs\n mov %%ax,%%gs\n mov %%ax,%%ss" ::: "ax", "memory");
    asm volatile("ltr %%ax" :: "a"((u16)0x28));

    for (int i = 0; i < 32; i++) {
        u32 a = isr_table[i];
        idt[i].off_lo = (u16)a; idt[i].sel = 0x08; idt[i].zero = 0; idt[i].attr = 0x8E; idt[i].off_hi = (u16)(a >> 16);
    }
    u32 a = (u32)(usize)isr128;
    idt[0x80].off_lo = (u16)a; idt[0x80].sel = 0x08; idt[0x80].attr = 0xEE; idt[0x80].off_hi = (u16)(a >> 16);
    DtPtr ip = { (u16)(sizeof(idt) - 1), (u32)(usize)idt };
    asm volatile("lidt %0" :: "m"(ip));

    // FPU (x87) e, se a CPU tiver, SSE: programas Linux compilados para i686 costumam usar
    u32 cr0; asm volatile("mov %%cr0,%0" : "=r"(cr0));
    cr0 &= ~((1u << 2) | (1u << 3)); cr0 |= (1u << 1);              // EM=0, TS=0, MP=1
    asm volatile("mov %0,%%cr0" :: "r"(cr0));
    asm volatile("fninit");
    u32 ea, eb, ec, ed; asm volatile("cpuid" : "=a"(ea), "=b"(eb), "=c"(ec), "=d"(ed) : "a"(1));
    if ((ed & (1u << 25)) && (ed & (1u << 24))) {                   // SSE + FXSR
        u32 cr4; asm volatile("mov %%cr4,%0" : "=r"(cr4));
        cr4 |= (1u << 9) | (1u << 10); asm volatile("mov %0,%%cr4" :: "r"(cr4));
    }
    g_boot_unix = k_unix_time(); g_boot_ms = net_ms();
}

// ---------------- carregador ELF32 ----------------
struct __attribute__((packed)) Ehdr {
    u8 ident[16]; u16 type, machine; u32 version, entry, phoff, shoff, flags;
    u16 ehsize, phentsize, phnum, shentsize, shnum, shstrndx;
};
struct __attribute__((packed)) Phdr { u32 type, offset, vaddr, paddr, filesz, memsz, flags, align; };

struct Loaded { u32 entry, phdr_va, phnum, bias, top; char interp[120]; bool has_interp; };

static int load_elf(int ino, bool is_interp, u32 bias_in, u32 lo_lim, u32 hi_lim, Loaded* L) {
    Ehdr h;
    if (vfs_read(ino, 0, &h, sizeof h) != (int)sizeof h) return USER_ERR_NOT_ELF;
    if (h.ident[0] != 0x7F || h.ident[1] != 'E' || h.ident[2] != 'L' || h.ident[3] != 'F') return USER_ERR_NOT_ELF;
    if (h.ident[4] != 1 || h.ident[5] != 1 || h.machine != 3) return USER_ERR_NOT_ELF;
    if (h.type != 2 && h.type != 3) return USER_ERR_UNSUPPORTED;
    if (h.phentsize != sizeof(Phdr) || h.phnum == 0 || h.phnum > 24) return USER_ERR_NOT_ELF;
    static Phdr ph[24];
    if (vfs_read(ino, h.phoff, ph, h.phnum * sizeof(Phdr)) != (int)(h.phnum * sizeof(Phdr))) return USER_ERR_NOT_ELF;
    u32 bias = (h.type == 3) ? bias_in : 0;
    u32 top = 0, lo = 0xFFFFFFFF, phdr_va = 0, fsize = vfs_size(ino);
    L->has_interp = false;
    for (int i = 0; i < h.phnum; i++) {
        if (ph[i].type == 3 && !is_interp) {
            u32 n = ph[i].filesz; if (n >= sizeof L->interp) return USER_ERR_NOT_ELF;
            if (vfs_read(ino, ph[i].offset, L->interp, n) != (int)n) return USER_ERR_NOT_ELF;
            L->interp[n] = 0; L->has_interp = true; continue;
        }
        if (ph[i].type != 1) continue;
        if (ph[i].filesz > ph[i].memsz || ph[i].offset + ph[i].filesz > fsize || ph[i].offset + ph[i].filesz < ph[i].offset) return USER_ERR_NOT_ELF;
        u32 va = ph[i].vaddr + bias;
        if (va < lo_lim || va + ph[i].memsz > hi_lim || va + ph[i].memsz < va) return USER_ERR_RANGE;
        if (va + ph[i].memsz > top) top = va + ph[i].memsz;
        if (va < lo) lo = va;
        if (h.phoff >= ph[i].offset && h.phoff + h.phnum * sizeof(Phdr) <= ph[i].offset + ph[i].filesz) phdr_va = va + (h.phoff - ph[i].offset);
    }
    if (top == 0 || h.entry + bias < lo || h.entry + bias >= top) return USER_ERR_NOT_ELF;
    for (int i = 0; i < h.phnum; i++) {
        if (ph[i].type != 1) continue;
        u32 va = ph[i].vaddr + bias;
        u32 pg = va & ~4095u;                                       // zera a partir do inicio da pagina (BSS e sobras)
        memset((void*)pg, 0, (va + ph[i].memsz) - pg);
        if (ph[i].filesz && vfs_read(ino, ph[i].offset, (void*)va, ph[i].filesz) != (int)ph[i].filesz) return USER_ERR_NOT_ELF;
    }
    L->entry = h.entry + bias; L->phdr_va = phdr_va; L->phnum = h.phnum; L->bias = bias; L->top = top;
    return 0;
}

int user_run(int ino, int argc, const char* const* argv, int cwd) {
    if (g_busy) return USER_ERR_BUSY;
    if (vfs_type(ino) != VT_FILE) return USER_ERR_NOFILE;
    Loaded L, I; int rc;
    rc = load_elf(ino, false, PIE_BASE, USER_LO, LOAD_END, &L);
    if (rc < 0) return rc;
    u32 entry = L.entry, base = 0, top = L.top;
    if (L.has_interp) {
        int ii = vfs_resolve(L.interp, 0);
        if (ii < 0 || vfs_type(ii) != VT_FILE) {
            int k = 0; const char* m = "falta o interpretador dinamico: "; while (m[k] && k < 60) { err_text[k] = m[k]; k++; }
            for (int j = 0; L.interp[j] && k < 150; j++) err_text[k++] = L.interp[j];
            err_text[k] = 0;
            return USER_ERR_NOINTERP;
        }
        rc = load_elf(ii, true, INTERP_BASE, INTERP_BASE, INTERP_END, &I);
        if (rc < 0) return rc;
        entry = I.entry; base = I.bias;
    }
    brk_start = brk_cur = (top + 4095) & ~4095u;
    mmap_cur = MMAP_LO; unk_count = 0; cwd_ino = (vfs_type(cwd) == VT_DIR) ? cwd : 0;
    memset(fds, 0, sizeof fds);
    for (int i = 0; i < 3; i++) { fds[i].kind = FK_CON; fds[i].oflags = i == 0 ? 0 : 1; }
    inpos = inlen = 0; in_eof = false;

    // pilha inicial no formato Linux: argc, argv, envp, auxv
    memset((void*)(STACK_TOP - 0x20000), 0, 0x20000);
    u32 sp = STACK_TOP;
    u32 argp[32]; int na = argc > 30 ? 30 : argc;
    for (int i = na - 1; i >= 0; i--) { int n = 0; while (argv[i][n]) n++; sp -= (u32)n + 1; memcpy((void*)sp, argv[i], n + 1); argp[i] = sp; }
    char pwd[200] = "PWD="; { char t[160]; vfs_path(cwd_ino, t, sizeof t); int k = 4; for (int i = 0; t[i] && k < 190; i++) pwd[k++] = t[i]; pwd[k] = 0; }
    const char* env[6] = { "PATH=/bin:/usr/bin:/usr/local/bin", "HOME=/home/hollow", "TERM=vt100", "USER=hollow", "LANG=C", pwd };
    u32 envp[6];
    for (int i = 5; i >= 0; i--) { int n = 0; while (env[i][n]) n++; sp -= (u32)n + 1; memcpy((void*)sp, env[i], n + 1); envp[i] = sp; }
    sp -= 16; u32 rnd = sp; rng_bytes((u8*)rnd, 16);
    sp -= 8; u32 plat = sp; memcpy((void*)plat, "i686", 5);
    u32 nwords = 1 + (u32)na + 1 + 6 + 1 + 2 * 14;
    sp = (sp - nwords * 4) & ~15u;
    u32 w = sp;
    #define PUSHW(v) do { *(u32*)w = (u32)(v); w += 4; } while (0)
    PUSHW(na);
    for (int i = 0; i < na; i++) PUSHW(argp[i]);
    PUSHW(0);
    for (int i = 0; i < 6; i++) PUSHW(envp[i]);
    PUSHW(0);
    PUSHW(3);  PUSHW(L.phdr_va);        // AT_PHDR
    PUSHW(4);  PUSHW(sizeof(Phdr));     // AT_PHENT
    PUSHW(5);  PUSHW(L.phnum);          // AT_PHNUM
    PUSHW(6);  PUSHW(4096);             // AT_PAGESZ
    PUSHW(7);  PUSHW(base);             // AT_BASE
    PUSHW(8);  PUSHW(0);                // AT_FLAGS
    PUSHW(9);  PUSHW(L.entry);          // AT_ENTRY
    PUSHW(11); PUSHW(0); PUSHW(12); PUSHW(0); PUSHW(13); PUSHW(0); PUSHW(14); PUSHW(0);   // UID/EUID/GID/EGID
    PUSHW(15); PUSHW(plat);             // AT_PLATFORM
    PUSHW(17); PUSHW(100);              // AT_CLKTCK
    PUSHW(23); PUSHW(0);                // AT_SECURE
    PUSHW(25); PUSHW(rnd);              // AT_RANDOM
    PUSHW(0);  PUSHW(0);                // AT_NULL
    #undef PUSHW

    tss.esp0 = (u32)(usize)(kstack + sizeof kstack);
    g_busy = true;
    int code = enter_user(entry, sp);
    g_busy = false;
    for (int i = 0; i < NFD; i++) if (fds[i].kind != FK_NONE) close_fd(i);
    udp_close();
    return code;
}

const char* user_err(int rc) {
    if (rc == USER_ERR_NOT_ELF)     return "nao e um ELF Linux i386 valido";
    if (rc == USER_ERR_UNSUPPORTED) return "tipo de ELF nao suportado (so executavel ou PIE de 32 bits)";
    if (rc == USER_ERR_RANGE)       return "o programa quer enderecos fora da area permitida (16 MB..160 MB)";
    if (rc == USER_ERR_NOFILE)      return "arquivo nao encontrado";
    if (rc == USER_ERR_NOINTERP)    return err_text;
    if (rc == USER_ERR_BUSY)        return "ja ha um programa Linux em execucao";
    return 0;
}

// web.h - HollowOS: cliente HTTP/HTTPS (GET/POST, redirecionamentos, chunked) e utilidades de URL
#pragma once
#include "net.h"

struct Url { bool https; u16 port; char host[80]; char path[600]; };

bool url_parse(const char* s, Url* u);                          // "host/x", "http://host:8080/x", "https://..."
void url_string(const Url& u, char* out, int max);              // volta a juntar em texto
void url_resolve(const Url& base, const char* ref, char* out, int max);   // link relativo -> absoluto
void url_encode(const char* s, char* out, int max);             // %XX, espaco = '+'
void url_decode(const char* s, int n, char* out, int max);      // %XX e '+'

struct WebResult {
    int  status;              // codigo HTTP (0 = sem resposta)
    char final_url[700];      // URL depois dos redirecionamentos
    char ctype[64];           // Content-Type
    int  redirects;
    u32  bytes;               // bytes de corpo entregues ao sink
    const char* error;        // texto do erro (ou 0)
};
// Recebe pedacos do corpo (ja sem cabecalhos e sem chunked). Retorne false para abortar.
typedef bool (*WebSink)(const u8* data, int n, void* ctx);

// method = "GET" ou "POST" (post_body so no POST, enviado como application/x-www-form-urlencoded).
// Retorna true se recebeu uma resposta HTTP completa (confira r->status). Segue ate 5 redirecionamentos.
bool web_request(const char* method, const char* url, const char* post_body, WebSink sink, void* ctx,
                 WebResult* r, int timeout_ms);

// tls.h - HollowOS: cliente TLS 1.2 (ECDHE com X25519 + AES-128-GCM) por cima do TCP do net.cpp
//
// AVISO DE SEGURANCA: a conexao e CRIPTOGRAFADA, mas o certificado do servidor NAO e validado
// (falta a lista de CAs e a verificacao RSA/ECDSA - veja ROADMAP.md). Isso protege contra quem so
// escuta a rede, mas NAO contra um atacante que se coloque no meio da conexao. Nao digite senhas.
#pragma once
#include "net.h"

bool        tls_connect(const char* host, const u8* ip, u16 port, int timeout_ms);  // TCP + handshake
int         tls_send(const u8* data, int len);                                        // len ou -1
int         tls_recv(u8* buf, int max, int timeout_ms);                               // >0, 0 = fechou, -1 = tempo
void        tls_close();
const char* tls_error();                                                              // motivo da ultima falha
